---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- generated_from_trainer
- dataset_size:4031
- loss:CosineSimilarityLoss
base_model: sentence-transformers/all-MiniLM-L6-v2
widget:
- source_sentence: '--T

    Perturbation Analyses for the Cholesky Downdating Problem.

    --A

    New perturbation analyses are presented for the block Cholesky downdating problem
    These show how changes in R and X alter the Cholesky factor U. There are two main
    cases for the perturbation matrix $\D R$ in R: (1) $\D R$ is a general matrix;
    (2)$\D R$ is an upper triangular matrix. For both cases, first-order perturbation
    bounds for the downdated Cholesky factor U are given using two approaches ---
    a detailed "matrix--vector equation" analysis which provides tight bounds and
    resulting true condition numbers, which unfortunately are costly to compute, and
    a simpler "matrix equation" analysis which provides results that are weaker but
    easier to compute or estimate. The analyses more accurately reflect the sensitivity
    of the problem than previous results. As $X\rightarrow 0$, the asymptotic values
    of the new condition numbers for case (1) have bounds that are independent of
    $\kappa_2(R)$ if $R$ was found using the standard pivoting strategy in the Cholesky
    factorization, and the asymptotic values of the new condition numbers for case
    (2) are unity. Simple reasoning shows this last result must be true for the sensitivity
    of the problem, but previous condition numbers did not exhibit this.}

    --B

    Introduction

    . Let A 2 R n\Thetan be a symmetric positive definite matrix. Then

    there exists a unique upper triangular matrix R 2 R n\Thetan with positive diagonal
    elements

    such that A = R T R. This factorization is called the Cholesky factorization,

    and R is called the Cholesky factor of A.

    In this paper we give perturbation analyses of the following problem: given an

    upper triangular matrix R 2 R n\Thetan and a matrix X 2 R k\Thetan such that R
    T

    is positive definite, find an upper triangular matrix U 2 R n\Thetan with positive
    diagonal

    elements such that

    This problem is called the block Cholesky downdating problem, and the matrix U

    is referred to as the downdated Cholesky factor. The block Cholesky downdating

    problem has many important applications, and the case for k=1 has been extensively

    studied in the literature (see [1, 2, 3, 8, 11, 12, 16, 17, 18]).

    Perturbation results for the single Cholesky downdating problem were presented

    by Stewart [18]. Eld''en and Park [10] made an analysis for block downdating.
    But

    these two papers just considered the case that only R or X is perturbed. More

    complete analyses, with both R and X being perturbed, were given by Pan [15] and

    Sun [20]. Pan [15] gave first order perturbation bounds for single downdating.
    Sun [20]

    gave strict, also first order perturbation bounds for single downdating and first
    order

    perturbation bounds for block downdating.

    The main purpose of this paper is to establish new first order perturbation results

    and present new condition numbers which more closely reflect the true sensitivity
    of

    This research was partially supported by NSERC of Canada Grant OGP0009236.

    y School of Computer Science, McGill University, Montreal, Quebec, Canada, H3A
    2A7,

    (chang@cs.mcgill.ca), (chris@cs.mcgill.ca).

    the problem. In Section 2 we will give the key result of Sun [20], and a new result
    using

    the approach of these earlier papers. In Section 3 we present new perturbation
    results,

    first by the straightforward matrix equation approach, then by the more detailed
    and

    tighter matrix-vector equation approach. The basic ideas behind these two approaches

    were discussed in Chang, Paige and Stewart [6, 7]. We give numerical results and

    suggest practical condition estimators in Section 4.

    Previous papers implied the change \DeltaR in R was upper triangular, and Sun
    [20]

    said this, but neither he nor the others made use of this. In fact a backward
    stable

    algorithm for computing U given R and X would produce the exact result U

    for nearby data R+ \DeltaR and X it is not clear that \DeltaR would be upper

    triangular - the form of the equivalent backward error \DeltaR would depend on
    the

    algorithm, and if it were upper triangular, it would require a rounding error
    analysis

    to show this. Thus for completeness it seems necessary to consider two separate
    cases

    - upper triangular \DeltaR and general \DeltaR. We do this throughout Sections
    3-4, and

    get stronger results for upper triangular \DeltaR than in the general case.

    In any perturbation analysis it is important to examine how good the results

    are. In Section 3.2 we produce provably tight bounds, leading to the true condition

    numbers (for the norms chosen). The numerical example in Section 4 indicates how

    much better the results of this new analysis can be compared with some earlier
    ones,

    but a theoretical understanding is also desirable. By considering the asymptotic
    case

    as 0, the results simplify, and are easily understandable. We show the new

    results have the correct properties as X ! 0, in contrast to earlier results.

    Before proceeding, let us introduce some notation. Let n\Thetan , then

    up(B), sut(B), slt(B) and diag(B) are defined by

    and

    2. Previous perturbation results, and an improvement. The condition

    number for downdating presented by Pan [15] involves the square of the condition

    number of R, - 2

    proposed new condition

    numbers which are simple and proportional to - 2 (R). The condition number for
    the

    block Cholesky downdating problem proposed in [20] is

    (\Gamma) is the smallest singular value

    of \Gamma. Notice that for fixed 1. Now we use a

    similar approach to derive a new bound, from which Sun''s bound follows.

    First we derive some relationships among U , R, X and \Gamma.

    From (1.1) obviously we have

    From (1.1) it follows that

    so that taking the 2-norm gives

    From (1.1) we have

    which, combined with (2.2), gives

    From (1.1) we have

    which, combined with (2.2), gives

    s

    By (2.2) we have

    Finally from (2.4) we see

    To derive first order perturbation results we consider the perturbed version of

    where U , U+ \DeltaU and R are upper triangular matrices with positive diagonal
    elements.

    when \DeltaR and \DeltaX are sufficiently small, (2.7) has a unique solution \DeltaU
    .

    Multiplying out the two sides of (2.7) and ignoring second order terms, we obtain
    a

    linear matrix equation for the first order approximation d

    \DeltaU to \DeltaU :

    U T d

    \DeltaU T

    In fact it is straightforward to show d

    U(0), the rate of change of U(-) at

    so d

    \DeltaU also has a precise meaning. From (2.8), we have

    d

    (R

    Notice since d

    \DeltaU U \Gamma1 is upper triangular, it follows, with (1.2), that

    d

    (R

    But for any symmetric matrix B,

    F \Gamma2 (b 2

    Thus from (2.9) we have

    \DeltaU

    pkU \GammaT (R T \DeltaR

    which, combined with (2.2) and (2.3), gives

    \DeltaU k F -

    resulting in the new perturbation bound for relative changes

    \DeltaU k F

    pp

    which leads to the condition numbers for the Cholesky downdating problem:

    pp

    for U with respect to relative changes in R and X, respectively. Notice from (2.1)

    . So we can define a new overall condition number

    Rewriting (2.10) as

    \DeltaU

    and combining it with (2.5) and (2.6), gives Sun''s bound

    \DeltaU k F

    We have seen the right hand side of (2.10) is never worse than that of (2.12),
    so

    Although fi 2 is a minor improvement on fi 1 , it is still not what we want. We
    can

    see this from the asymptotic behavior of these "condition numbers". The Cholesky

    factorization is unique, so as X ! 0, U ! R, and X T \DeltaX ! 0 in (2.8). Now
    for any

    upper triangular perturbation \DeltaR in R, \DeltaU ! \DeltaR, so the true condition
    number

    should approach unity. Here

    (R). The next section shows how we can

    overcome this inadequacy.

    3. New perturbation results. In Section 2 we saw the key to deriving first

    order perturbation bounds for U in the block Cholesky downdating problem is the

    equation (2.8). We will now analyze it in two new approaches. The two approaches

    have been used in the perturbation analyses of the Cholesky factorization, the
    QR factorization

    (see Chang, Paige and Stewart [6, 7]), and LU factorization (see Chang [4]

    and Stewart [19]). The first approach, the refined matrix equation approach, gives
    a

    clear improvement on the previous results, while the second, the matrix-vector
    equation

    approach, gives a further improvement still, which leads to the true condition

    numbers for the block Cholesky downdating problem.

    3.1. Refined matrix equation analysis. In the last section we used (2.8) to

    produce the matrix equation (2.9), and derived the bounds directly from this.
    We

    now look at this approach more closely.

    Let D n be the set of all n \Theta n real positive definite diagonal matrices.
    For any

    U . Note that for any matrix B we have

    First with no restriction on \DeltaR we have from (2.9)

    d

    U

    so taking the F-norm gives

    \DeltaU

    It is easy to show for any B 2 R n\Thetan (see Lemma 5.1 in [7])

    g. Thus from (3.1) we have

    \DeltaU

    (kU \GammaT R T \DeltaR -

    U

    (using (2:2); (2:3))

    which is an elegant result in the changes alone. It leads to the following perturbation

    bound in terms of relative changes

    \DeltaU

    Although here it would be simpler to just define an overall condition number,
    for later

    comparisons it is necessary for us to define the following two quantities as condition

    numbers for U with respect to relative changes in R and X, respectively (here
    subscript

    G refers to general \DeltaR, and later the subscript T will refer to upper triangular
    \DeltaR):

    c RG (R; X)

    where

    c RG (R; X;D) j

    Then an overall condition number can be defined as

    c G (R; X;D);

    where

    Obviously we have

    c G (R;

    Thus with these, we have from (3.3) that

    \DeltaU k F

    if we take become (2.10), and

    It is not difficult to give an example to show fi 2 can be arbitrarily larger
    than c G (R; X),

    as can be seen from the following asymptotic behaviour.

    It is shown in [7, x5.1, (5.14)] that with an appropriate choice of D,

    has a bound which is a function of n only, if R was found using the standard pivoting

    strategy in the Cholesky factorization, and in this case, we see the condition
    number

    c G (R; X) of the problem here is bounded independently of - 2 (R) as X ! 0, for
    general

    \DeltaR. At the end of this section we give an even stronger result when X ! 0
    for the

    case of upper triangular \DeltaR. Note in the case here that fi 2 in (2.11) can
    be made as

    large as we like, and thus arbitrarily larger than c G (R; X).

    In the case where \DeltaR is upper triangular , we can refine the analysis further.
    From

    we have

    d

    Notice with (1.3) and (1.4)

    U \GammaT R T \DeltaRU

    But for any upper triangular matrix T we have

    so that if we define T

    up[diag(U \GammaT R T

    Thus from (3.12), (3.13) and (3.14) we obtain

    d

    \DeltaU

    As before, let

    U , where . From (3.15) it follows that

    \DeltaU

    U \GammaT \DeltaR T

    Then, applying (3.2) to this, we get the following perturbation bound

    \DeltaU k F

    (3.

    Comparing (3.16) with (3.3) and noticing (2.3), we see the sensitivity of U with
    respect

    to changes in X does not change, so c X (R; X) defined in (3.4) can still be regarded
    as

    a condition number for U with respect to changes in X. But we now need to define

    a new condition number for U with respect to upper triangular changes in R, that
    is

    (subscript T indicates upper triangular \DeltaR)

    c RT (R; X)

    c RT (R; X;D);

    where

    Thus an overall condition number can be defined as

    where

    c T (R;

    Obviously we have

    With these, we have from (3.16) that

    \DeltaU k F

    What is the relationship between c T (R; X) and c G (R;

    n \Theta n upper triangular matrix observe the following two facts:

    are the eigenvalues of T , so that

    which gives

    (Note: In fact we can prove a slightly sharper inequality ksut(T

    Therefore

    c RT (R;

    n)

    n)

    using (2:2))

    n)c RG (R; X;D);

    so that

    c RT (R; X)

    n)c RG (R; X):

    Thus we have from (3.8) and (3.18)

    n)c G (R; X):

    On the other hand, c T (R; X) can be arbitrarily smaller than c G (R; X). This
    can be

    seen from the asymptotic behaviour, which is important in its own right. As

    since

    so for upper triangular changes in R, whether pivoting was used in finding R or
    not,

    Thus when X ! 0, the bound in (3.19) reflects the true sensitivity of the problem.

    For the case of general \DeltaR, if we do not use pivoting it is straightforward
    to make

    c G (R; X) in (3.7) arbitrarily large even with

    3.2. Matrix-vector equation analysis. In the last subsection, based on the

    structure of \DeltaR, we gave two perturbation bounds using the so called refined
    matrix

    equation approach. Also based on the structure of \DeltaR, we can now obtain provably

    sharp, but less intuitive results by viewing the matrix equation (2.8) as a large
    matrix-vector

    equation. For any matrix C n\Thetan , denote by c (i)

    j the

    vector of the first i elements of c j . With this, we define ("u" denotes "upper")

    c (1)c (2):

    c (n)

    It is the vector formed by stacking the columns of the upper triangular part of
    C into

    one long vector.

    First assume \DeltaR is a general real n \Theta n matrix. It is easy to show (2.8)
    can be

    rewritten into the following matrix-vector form (cf [7])

    WU uvec( d

    2 \Theta n(n+1)

    r 11

    and YX 2 R n(n+1)

    Since U is nonsingular, WU is also, and from (3.22)

    uvec( d

    U YX vec(\DeltaX);

    so taking the 2-norm gives

    \DeltaU

    resulting in the following perturbation bound

    \DeltaU k F

    -RG (R; X)

    where

    Now we would like to show

    Before showing this, we will prove a more general result. Suppose from (2.8) we
    are

    able to obtain a perturbation bound of the form

    \DeltaU

    - ff R

    (3.

    where ff R and ff X , two functions of R and X, are other measures of the sensitivity
    of

    the Cholesky downdating problem with respect to changes in R and X. Let

    Then from (3.23) and (3.28) we have

    U ZR vec(\DeltaR)k 2

    - ff R

    Notice \DeltaR can be any (sufficiently small) n \Theta n real matrix, so we must
    have

    which gives

    Similarly, we can show

    Notice since (3.9) is a particular case of (3.28), (3.27) follows. Thus we have
    from

    (3.8) and (3.26)

    The above analysis shows for general \DeltaR, -RG (R; X) and -X (R; X) are optimal

    measures of the sensitivity of U with respect to changes in R and X, respectively,
    and

    thus the bound (3.24) is optimal. So we propose -RG (R; X) and -X (R; X) as the
    true

    condition numbers for U with respect to general changes in R and X, respectively,

    and - CDG (R; X) as the true overall condition number of the problem in this case.

    It is easy to observe that if X ! 0, - CDG (R; X)

    just WU with each entry u ij replaced by r ij . If R was found using the standard

    pivoting strategy in the Cholesky factorization, then kW \Gamma1

    R ZR k 2 has a bound which

    is a function of n alone (see [5] for a proof). So in this case our condition
    number

    - CDG (R; X) also has a bound which is a function of n alone as

    Remark 1: Our numerical experiments suggest c G (R; X) is usually a good approximation

    to - CDG (R; X). But the following example shows c G (R; X) can sometimes be

    arbitrarily larger than - CDG (R; X).

    where ffl is a small positive number. It is not difficult to show

    But c G (R; X) has an advantage over - CDG (R; X) - it can be quite easy to estimate

    - all we need do is choose a suitable D in c G (R; X;D). We consider how to do
    this

    in the next section. In contrast - CDG (R; X) is, as far as we can see, unreasonably

    expensive to compute or estimate.

    Now we consider the case where \DeltaR is upper triangular. (2.8) can now be rewritten

    as the following matrix-vector form

    WU uvec( d

    2 \Theta n(n+1)

    2 and YX 2 R n(n+1)

    2 \Thetakn are defined as before, and WR 2

    R n(n+1)

    2 \Theta n(n+1)

    2 is just WU with each entry u ij replaced by r ij . Since U is nonsingular,

    WU is also, and from (3.30)

    uvec( d

    U YX vec(\DeltaX);

    so taking the 2-norm gives

    \DeltaU

    which leads to the following perturbation bound

    \DeltaU k F

    where

    Note -X (R; X) is the same as that defined in (3.25).

    As before, we can show that for the case where \DeltaR is upper triangular, -
    RT (R; X)

    and -X (R; X) are optimal measures of the sensitivity of U with respect to changes
    in

    R and X, respectively, and thus the bound (3.32) is optimal. In particular, we
    have

    In fact - RT (R; X) -RG (R; X) can also be proved directly by the fact that the
    columns

    of WR form a proper subset of the columns of ZR , and the second inequality has
    been

    proved before. Thus we have from (3.8), (3.18), (3.26) and (3.33)

    By the above analysis, we propose - RT (R; X) and -X (R; X) as the true condition

    numbers for U with respect to changes in R and X, respectively, and - CDT (R;
    X) as

    the true overall condition number, in the case that \DeltaR is upper triangular.

    If as well X ! 0, then since U ! R, W \Gamma1

    So in this case the Cholesky downdating problem becomes very well conditioned
    no

    matter how ill conditioned R or U is.

    Remark 2: Numerical experiments also suggest c T (R; X) is usually a good approximation

    to - CDT (R; X). But sometimes c T (R; X) can be arbitrarily larger than

    - CDT (R; X). This can also be seen from the example in Remark 1. In fact, it
    is not

    difficult to obtain

    Like - CDG (R; X), - CDT (R; X) is difficult to compute or estimate. But c T (R;
    X) is easy

    to estimate, which is discussed in the next section.

    4. Numerical tests and condition estimators. In Section 3 we presented new

    first order perturbation bounds for the the downdated Cholesky factor U using
    first

    the refined matrix equation approach, and then the matrix vector equation approach.

    We defined - CDG (R; X) for general \DeltaR, and - CDT (R; X) for upper triangular
    \DeltaR, as

    the true overall condition numbers of the problem. Also we gave two corresponding

    practical but weaker condition numbers c G (R; X) and c T (R; X) for the two \DeltaR
    cases.

    We would like to choose D such that c G (R; X;D) and c T (R; X;D) are good approximations

    to c G (R; X) and c T (R; X), respectively. We see from (3.5), (3.6) and

    (3.17) that we want to find D such that

    its infimum.

    By a well known result of van der Sluis [21], - 2 (D \Gamma1 U) will be nearly
    minimal when

    the rows of D \Gamma1 U are equilibrated. But this could lead to a large i D .
    So a reasonable

    compromise is to choose D to equilibrate U as far as possible while keeping i
    D - 1.

    Specifically, take

    we use a standard condition estimator to estimate

    Notice from (2.4) we have oe n

    2 . Usually k, the number of

    rows of X, is much smaller than n, so oe n (\Gamma) can be computed in O(n 2 ).
    If k is not

    much smaller than n, then we use a standard norm estimator to estimate kXR

    in O(n 2 ). Similarly kUk 2 and kRk 2 can be estimated in O(n 2 ). So finally
    c G (R; X;D)

    can be estimated in O(n 2 ). Estimating c T (R; X;D) is not as easy as estimating

    c G (R; X;D). The part kdiag(RU (R; X;D) can easily be computed in

    O(n), since diag(RU

    c RT (R; X;D) can roughly be estimated in O(n 2 ), based onp

    F

    and the fact that kRU \Gamma1 k F can be estimated by a standard norm estimator
    in O(n 2 ).

    The value of kXU (R; X;D) can be calculated (if k !! n) or estimated

    by a standard estimator in O(n 2 ). All the remaining values kRk 2 , kXk 2 and
    kUk 2

    can also be estimated by a standard norm estimator in O(n 2 ). Hence c RT (R;
    X;D),

    c X (R; X;D), and thus c T (R; X;D) can be estimated in O(n 2 ). For standard
    condition

    estimators and norm estimators, see Chapter 14 of [14].

    The relationships among the various overall condition numbers for the Cholesky

    downdating problem presented in Section 2 and Section 3 are as follows.

    n)c G (R; X)

    Now we give one numerical example to illustrate these. The example, quoted from

    Sun [20], is as follows.

    0:240

    2:390C C C C C A

    . The results obtained using MATLAB are shown in


    Table


    4.1 for various values of - :


    Table

    c G (R; X;D) 3.60e+03 3.61e+02 3.79e+01 1.79e+01 1.78e+01 1.78e+01

    c T (R; X;D) 2.12e+03 2.12e+02 1.79e+01 1.07e+00 1.00e+00 1.00e+00

    Note in Table 4.1 how fi 1 and fi 2 can be far worse than the true condition numbers

    - CDG (R; X) and - CDT (R; X), although fi 2 is not as bad as fi 1 . Also we observe

    that c G (R; X;D) and c T (R; X;D) are very good approximations to - CDG (R; X)

    and - CDT (R; X), respectively. When X become small, all of the condition numbers

    decrease. The asymptotic behavior of c G (R; X;D), c T (R; X;D), - CDG (R; X)
    and

    our theoretical results - when

    - CDG (R; X) will be bounded in terms of n since here R corresponds to the Cholesky

    factor of a correctly pivoted A, and c T (R; X); - CDT (R; X) ! 1.


    Acknowledgement


    . We would like to thank Ji-guang Sun for suggesting to us

    that the approach describe in (a draft version of) [6] might apply to the Cholesky

    downdating problem.




    --R


    Analysis of a recursive least squares hyperbolic rotation algorithm for signal
    processing

    Accurate downdating of least squares solutions

    A note on downdating the Cholesky factorization

    PhD Thesis

    A perturbation analysis for R in the QR factorization

    New perturbation analyses for the Cholesky factorization

    Perturbation analyses for the QR factorization


    Block downdating of least squares solutions

    Perturbation analysis for block downdating of a Cholesky decomposition

    Numerical computations for univariate linear models

    Methods for modifying matrix factor- izations

    Matrix computations

    Accuracy and Stability of Numerical Algorithms

    A perturbation analysis of the problem of downdating a Cholesky factorization

    Least squares modification with inverse factorizations: parallel implications


    The effects of rounding error on an algorithm for downdating a Cholesky factor-
    ization

    On the Perturbation of LU and Cholesky Factors

    Perturbation analysis of the Cholesky downdating and QR updating problems

    Condition numbers and equilibration of matrices

    --TR'
  sentences:
  - software inspection
  - sensitivity
  - hierarchical partitioning
- source_sentence: '--T

    Stability of Perturbed Delay Differential Equations and Stabilization of Nonlinear
    Cascade Systems.

    --A

    In this paper  the effect of bounded input perturbations on the stability of nonlinear
    globally asymptotically stable delay  differential equations is analyzed. We investigate
    under which conditions global stability is preserved and if not, whether semiglobal
    stabilization is possible by controlling the size or shape of the perturbation.
    These results are used to study the stabilization of partially linear cascade
    systems with partial state feedback.

    --B

    Introduction

    The stability analysis of the series (cascade) interconnection of two stable

    nonlinear systems described by ordinary differential equations is a classical

    subject in system theory ([13], [14], [17]).

    stable stable

    Contrary to the linear case, the zero input global asymptotic stability of

    each subsystem does not imply the zero input global asymptotic stability of

    the interconnection. The output of the first subsystem acts as a transient

    input disturbance which can be sufficient to destabilize the second subsys-

    tem. In the ODE case, such destabilizing mechanisms are well understood.

    they can be subtle but are almost invariably associated to a finite escape

    time in the second subsystem (Some states blow up to infinity in a finite

    time). The present paper explores similar instability mechanisms generated

    by the series interconnection of nonlinear DDEs. In particular we consider

    the situation where the destabilizing effect of the interconnection is delayed

    and examine the difference with the ODE situation.

    In the first part of the paper we study the effect of external (affine)

    perturbations w on the stability of nonlinear time delay systems

    whereby we assume that

    globally asymptotically stable.

    We consider perturbations which belong to both L 1 and L1 and

    investigate the region in the space of initial conditions which give rise to

    bounded solutions under various assumptions on the system and the perturbation


    First, we consider global results: in the ODE-case, an obstruction is

    formed by the fact that arbitrary small input perturbations can cause the

    state to escape to infinity in a finite time, for instance when the interconnection

    term \Psi(z) is nonlinear in z. This is studied extensively in the literature

    in the context of stability of cascades, i.e. when the perturbation in (1)

    is generated by another ODE, see e.g. [15] [13] and the references therein.

    Even though delayed perturbations do not cause a finite escape time, we

    explain a similar mechanism giving rise to unbounded solutions, caused by

    nonlinear delayed interconnection terms.

    In a second part, we allow situations whereby unbounded solutions are

    inevitable and we investigate under which conditions trajectories can be

    bounded semi-globally in the space of initial conditions, in case the perturbation

    is parametrized, i.e. a). Hereby we let the parameter a

    regulate the L 1 or L1 norm of the perturbation. We also consider the effect

    of concentrating the perturbation in an arbitrary small time-interval.

    As an application, we consider the special case whereby the perturbation

    is generated by a globally asymptotically stable ODE. This allows us

    to strengthen the previous results by the application of a generalization of

    LaSalle''s theorem [7] to the DDE-case: the convergence to zero of a solution

    is implied by its boundedness. We also show that the origin of the

    cascade is stable. We will concentrate on the following synthesis problem:

    the stabilization of a partial linear cascade,!

    with the SISO-system (A; B; C) controllable, using only partial state feed-back

    laws of the form which allows to influence the shape and size

    of the input ''perturbation'' y to the nonlinear delay equation.

    In the ODE-case this stabilization problem is extensively studied in the

    literature, for instance in [16][1][15][8]. Without any structural assumption

    on the interconnection term, achieving global stabilization is generally

    not possible because the output of the linear subsystem, which acts as a

    destabilizing disturbance to the nonlinear subsystem, can cause trajectories

    to escape to infinity in a finite time. Therefore one concentrates on semi-global

    stabilization, i.e. the problem of finding feedback laws making the

    origin asymptotically stable with a domain of attraction containing any pre-set

    compact region in the state space. An instructive way to do so is to drive

    the ''perturbation'' y fast to zero. However, a high-gain control, placing all

    observable eigenvalues far into the LHP, will not necessarily result in large

    stability regions, because of the fast peaking obstacle [15] [13]. Peaking is

    a structural property of the -subsystem whereby achieving faster convergence

    implies larger overshoots which can in turn destabilize the cascade.

    Semi-global stability results are obtained when imposing structural assumptions

    on the -subsystem (a nonpeaking system) or by imposing conditions

    on the z-subsystem and the interconnection term \Psi: for example in [15] one

    imposes a linear growth restriction on the interconnection term and requires

    global exponential stability of the z-subsystem.

    In this paper the classical cascade results are obtained and analysed in

    the more general framework of bounded input perturbations and generalized

    to the time-delay case.

    Preliminaries The state of the delay equation (1) at time t can be described

    as a vector z(t) 2 R n or as a function segment z t defined by

    z

    Therefore delay equations form a special class of functional differential equations

    [3][5][6].

    We assume that the right-hand side of (1) is continuous in all of its

    arguments and Lipschitz in z and z(t \Gamma  ). Then a solution is uniquely

    defined by specifying as initial condition a function segment z 0 whereby z 0
    2

    C([\Gamma; 0]; R n ), the Banach space of continuous bounded functions mapping

    the delay-interval [\Gamma; 0] into R n and equipped with the supremum-norm

    k:k s .

    Sufficient conditions for stability of a functional differential equation are

    provided by the theory of Lyapunov functionals [3] [6], a generalization of

    the classical Lyapunov theory for ODEs: for functional differential equations

    of the form

    a mapping R is called a Lyapunov functional on a set G if V is

    continuous on G and

    0 on G. Here

    V is the upper-right-hand derivative

    of V along the solutions of (2), i.e.

    The following theorem, taken from [3], provides sufficient conditions for

    stability:

    Theorem 1.1 Suppose z = 0 is a solution of (2) and

    and there exist nonnegative functions a(r) and b(r) such that a(r) !1

    as r !1 and

    Then the zero solution is stable and every solution is bounded. If in addition,

    b(r) is positive definite, then every solution approaches zero as t !1.

    Instead of working with functionals, it is also possible to use classical Lyapunov

    functions when relaxing the condition

    This approach, leading

    to the so-called Razumikhin-type theorems [6], is not considered in this paper


    In most of the theorems of the paper, the condition of global asymptotic

    stability for the unperturbed system (equation (1) with

    cient. When the dimension of the system is higher than one, we sometimes

    need precise information about the interaction of different components of

    the state z(t). This information is captured in the Lyapunov functional, associated

    with the unperturbed system. Therefore, when necessary, we will

    restrict ourself to a specific class of functionals, with the following assumption


    Assumption 1.2 The unperturbed system

    delay-independent

    globally asymptotically stable (i.e. GAS for all values of the delay) with a

    Lyapunov-functional of the form

    radially unbounded and such that the

    conditions of theorem 1.1 (with b(r) positive definite) are satisfied.

    This particular choice is motivated by the fact that such functionals are used

    for a class of linear systems [3][6] and, since we assume delay-independent

    stability, the time-derivative of the functional should not depend explicitly

    on  . Choosing a delay-independent stable unperturbed system also allows

    us to investigate whether the results obtained in the presence of perturbations

    are still global in the delay. Note that in the ODE-case (3) reduces to

    hardly forms any restriction because under mild conditions

    its existence is guaranteed by converse theorems.

    The perturbation j(t) 2 L p ([0; 1)) when 9M such that kjk

    We assume j in (1) to be continuous and to belong to both L 1 and L1 .

    When the perturbation is generated by an autonomous ODE,

    b() with a and b continuous and locally Lipschitz, with

    is globally asymptotically and locally exponentially stable (GAS and LES),

    these assumptions are satisfied.

    In the paper we show that when the unperturbed system is delay-independent

    stable with a functional of the form (3) and the initial condition is bounded

    (i.e. kz 0 k s  R ! 1), arbitrary small perturbations can cause unbounded

    trajectories provided the delay is large enough. Therefore it is instructive to

    treat the delay as the (n + 1)-th state variable when considering semi-global

    results: with a parametrized perturbation j(t; a), we say for instance that

    the trajectories of (1) can be bounded semi-globally in z and semi-globally

    in the delay if for each compact

    region\Omega ae R n , and 8

    a positive number  a such that all initial conditions z

    with z 0 ('')

    , give rise to bounded trajectories when

    a   a.

    belongs to class , if it is strictly increasing

    and The symbol k:k is used for the Euclidean norm in R n and by

    kx; yk we mean

    .

    2 The mechanism of destabilizing perturbations

    In contrast to linear systems, small perturbations (in the L 1 or L1 sense) are

    sufficient to destabilize nonlinear differential equations. In the ODE-case,

    the nonlinear mechanism for instability is well known: small perturbations

    suffice to make solutions escape to infinity in a finite time, for instance when

    the interconnection term \Psi is nonlinear in z. This is illustrated with the

    following example:

    which can be solved analytically for z to give

    ds

    escapes to infinity in a finite time t e which is given by

    log

    This last expression shows that the escape time becomes smaller as the

    initial conditions are chosen larger, and, as a consequence, however fast j(t)

    would be driven to zero in the first equation of (4), z(0) could always be

    chosen large enough for the solution to escape to infinity in finite time.

    In the simple example (4), the perturbation is the output of a stable

    linear system. Its initial condition j(0) dictates the L1-norm of the per-

    turbation, while the parameter a controls its L 1 -norm. Making these norms

    arbitrary small does not result in global stability. This is due to the nonlinear

    growth of the interconnection term.

    One may wonder whether the instability mechanism encountered in the

    ODE situation (4) will persist in the DDE situation

    ae

    In contrast to (4), system (7) exhibits no finite escape time. This can be

    proven by application of the method of steps, i.e. from the boundedness of

    of

    and thus of z(''). Nevertheless the exponentially decaying input j still causes

    unbounded solutions in (7): this particular system is easily seen to have an

    exponential solution z e

    at . The instability mechanism can be

    explained by the superlinear divergence of the solutions of

    Theorem 2.1

    has solutions which diverge faster than any exponential function.

    Proof 2.1 Take as initial condition a strictly positive solution segment z 0

    over [\Gamma; 0] with z(0) ? 1. For t  0, the trajectory is monotonically

    increasing. This means that in the interval [k;

    z

    The solution at point k; k  1 is bounded below by the sequence satisfying

    z

    which has limit +1. The ratio R

    z

    satisfies

    R

    and consequently (R tends to infinity. However for an exponential

    function e at , R = e a and (R \Gamma 1)R is constant.

    As a consequence, for the system (7), arbitrarily fast exponential decay of

    cannot counter the blow-up caused by the nonlinearity in z(t \Gamma  ), and

    hence the system is not globally asymptotically stable.

    The instability mechanism illustrated by (4) and (7) can be avoided by

    imposing suitable growth restrictions on the interconnection term \Psi. When

    the unperturbed system is scalar, it is sufficient to restrict the interconnection

    term to have linear growth in both of its arguments, i.e.

    This linearity condition is by itself not sufficient however, if the unperturbed

    system has dimension greater than one. In that case, the interaction of the

    different components of the state z(t) can still cause "nonlinear" effects

    leading to unbounded solutions. An illustration of this phenomenon is given

    by the following system!

    which was shown in [13] to have unbounded solutions, despite the linearity

    of the interconnection. The instability is caused by the mutual interaction

    between z 1 and z 2 when j 6= 0.

    The following theorem, inspired by theorem 4.7 in [13], provides sufficient

    conditions for bounded solutions. To prevent the instability mechanism due

    to interacting states, conditions are put on the Lyapunov functional of the

    unperturbed system.

    Theorem 2.2 Assume that the system

    satisfies Assumption 1.2 and that the interconnection term \Psi(z;

    grows linearly in its arguments, i.e. satisfies (8). Furthermore if the perturbation

    (ii) jj dk

    dz jj jjzjj  ck(z),

    then all trajectories of the perturbed system are bounded, for all values of

    the time delay.

    Condition (ii) is sometimes called a polynomial growth condition because it

    is satisfied if k(z) is polynomial in z.

    Proof 2.2 Along a trajectory z(t) we have:

    dz

    kzk

    cff 1=fl

    r

    ff 2=fl''

    cff 1=fli

    cff 1=fli

    For cannot escape to infinity because k(z(t\Gamma )) is bounded

    (calculated from the initial condition) and the above estimate can be integrated

    over the interval since the right hand side is linear in V and j 2 L 1 .

    For t   we can use the estimate k(z(t \Gamma

    Because this estimate for

    V is increasing in both of its argument, an upper

    bound for V (t) along the trajectory is described by

    with as initial condition W (z  the method of steps, it is clear

    that W cannot escape to infinity in a finite time. From

    monotonically increasing. As a consequence, for t  2 , W (t)  W

    and

    and this estimate can be integrated leading to boundedness of lim t!1 sup V (t)

    because Hence the trajectory z(t) is bounded.

    Remark: When the interconnection term \Psi is undelayed, i.e. \Psi(z), condition

    (i) in theorem 2.2 can be dropped [13].

    3 Semi-global results for parametrized perturbation


    Although no global results can be guaranteed in the absence of growth con-

    ditions, the examples in the previous section suggest that one should be

    able to bound the solutions semi-globally in the space of initial conditions

    by decreasing the size of the perturbation. Therefore we assume that the

    perturbation is parametrized,

    We will consider two cases: a) parameter a controls the L 1 - or the L1-norm

    of j and b) a regulates the shape of a perturbation with fixed L 1 -norm.

    3.1 Modifying the L 1 and the L1 norm of the perturbation

    We first assume that the L 1 -norm of j is parametrized. We have the following

    result:

    Theorem 3.1 Consider the system

    and suppose that the unperturbed system is GAS with the Lyapunov functional

    Assumption 1.2. If furthermore kj(t;

    a !1, then the trajectories can be bounded semi-globally both in z and the

    delay  , by increasing a.

    Proof 3.1 Let   0 be fixed and denote

    by\Omega the desired stability domain in

    R n , i.e. such that all trajectories starting in z 0 with z 0 ('')

    2\Omega for '' 2 [\Gamma; 0]

    are bounded. Let V c , sup z0

    As long as V (t)  2V c , z(t) and belong to a compact set. Hence

    When a ! 1, the increase of V tends to zero. As a consequence the assumption

    is valid for 8t  0. Hence the trajectories with initial

    condition

    in\Omega are bounded.

    Note that for a fixed

    region\Omega increases with  and this influences

    both the value M in the estimation of jk 0 (z)\Psi(z; z(t \Gamma )j and the

    critical value

    a of a in order to bound the trajectories. However when

    belongs to a compact interval [0;   ], we can take a  sup 2[0;

    hence bound the trajectories semi-globally in both the state and the delay.

    The result given above is natural because for a given initial condition, a

    certain amount of energy is needed for destabilization, expressed mathematically

    by kjk 1 . However global stability in the state is not possible because

    the required energy can become arbitrary small provided the initial condition

    is large enough, see for instance example (4). Later we will discuss why

    the trajectories cannot be bounded globally in the delay.

    Now we consider the case whereby the L1-norm of the perturbation is

    parametrized.

    Theorem 3.2 Consider the system

    Suppose that the unperturbed system is GAS with the Lyapunov functional

    Assumption 1.2. If kj(t; a)k trajectories

    of the perturbed system can be bounded semi-globally in both z and the

    delay  .

    Proof 3.2 As in the proof of Theorem 3.1, it is sufficient to prove semi-global

    stability in the state for a fixed   0.

    Let\Omega and V c be defined as in

    Theorem 3.1.

    \Omega , with ffl ? 0 small.

    The time derivative of V satisfies

    When z(t)

    n\Omega ffl we have, since b is positive definite,

    Mkjk1  \GammaN for some number N ? 0 provided kjk 1 is small enough.

    Only when z(t)

    the value of V can increase with the estimate

    Mkjk1 .

    Now we prove by contradiction that all trajectories with initial condition

    in\Omega are bounded for small suppose that a solution starting

    in\Omega

    (with it has to cross the level set 2V c . Assume

    that this happens for the first time at t   . Note that for small kjk 1 , t   is

    large. During the interval [t  increase and decrease, but

    increases, z(t)

    2\Omega ffl and the increase \DeltaV is

    limited: \DeltaV  Mkjk1  . When z(t) would be

    outside\Omega ffl for a time-interval

    Hence by reducing kj(t; a)k 1 we can make the time-interval \Deltat arbitrary

    small. On the other hand (for large a),

    dz

    when z t is

    inside\Omega 2 , because f and \Psi map bounded sets into bounded sets.

    Hence with jt \Deltat we have L\Deltat. Because of (12)

    we can increase a (reduce kj(t; a)k 1 ) such that L\Deltat  ffl and consequently

    we have:

    If ffl was chosen such

    lies

    inside\Omega , we have a contradiction because

    this implies W (t   )  W c . Hence a trajectory can never cross the level set

    2W c and is bounded.

    The results of Theorems 3.1 and 3.2 are not global in the delay, although

    the unperturbed system is delay-independent stable. Global results in the

    delay are generally not possible: we give an example whereby it is impossible

    to bound the trajectories semi-globally in the state and globally in the delay,

    even if we make the size of the perturbation arbitrary small w.r.t. the L 1

    and L1 -norm.

    Example 3.1 Consider the following system:

    z

    The unperturbed system, i.e. (13) with delay-independent stable.

    This is proven with the Lyapunov functional

    Its time derivative

    \Gammaz 2(z 1

    z 2+1

    z 2+1

    is negative definite: when z 1 62 [1; 3], both terms are negative and in the

    other case the second term is dominated, because it saturates in z 2 . From

    this it follows that the conditions of Assumption 1.2 are satisfied.

    With the perturbation

    whereby increasing a leads to a reduction of both kjk 1 and kjk 1 , we can not

    bound the trajectories semi-globally in the state and globally in  : for each

    value of a we can find a bounded initial condition (upper bound independent

    of a), leading to a diverging solution, provided  is large enough: the first

    equation of (13) has a solution z \Gammaff is the real

    solution of equation

    boundedness in  of this solution over the interval [\Gamma; 0] (initial condition)

    is guaranteed. Choose z 2

    The above solution for z 1 satisfies:

    when

    ff log 5

    3 ] and thus

    A rather lengthy calculation shows that with z 2 and the perturbation

    (14), the solution of (15) always escapes to infinity in a finite time t f (a).

    Hence this also holds for the solution of the original system when the delay

    is large enough such

    log 5

    This result is not in contradiction with the intuition that a perturbation

    with small L 1 -norm can only cause escape in a finite time when the initial

    condition is far away from the origin, as illustrated with example (4): in

    the system (13) with driven away from the origin as long as

    By increasing the delay in the first equation, we can keep

    z 1 in this interval as long as desired. Thus the diverging transient of the

    unperturbed system is used to drive the state away from the origin, far

    enough to make the perturbation cause escape.

    3.2 Modifying the shape of the perturbation

    We assume that the shape of a perturbation with a fixed L 1 -norm can be

    controlled and consider the influence of an energy concentration near the

    origin. In the ODE case this does not allow to improve stability proper-

    ties. This is illustrated with the first equation of example (4): instability

    occurs when z(0)  1

    R te \Gammas j(s)ds

    and by concentrating the perburbation the

    stability domain may even shrink, because the beneficial influence of damping

    is reduced. In the DDE-case however, when the interconnection term is

    linear in the undelayed argument, it behaves as linear during one delay interval

    preventing escape. Moreover, starting from a compact region of initial

    conditions, the reachable set after one delay interval can be bounded independently

    of the shape of the perturbation (because of the fixed L 1 -norm).

    After one delay interval we are in the situation treated in Theorem 3.1. This

    is expressed in the following theorem. As in Theorem 2.2 the polynomial

    growth condition prevents hidden nonlinearities due to interacting states.

    Theorem 3.3 Consider

    and suppose that the unperturbed system is GAS with the Lyapunov functional

    Assumption 1.2. Let k(z)

    satisfy the polynomial growth condition k dk

    dz kkzk  ck(z). Assume that \Psi has

    linear growth in z(t), kj(t; a)k independent of a and lim a!1

    the trajectories of (16) can be bounded semi-globally in z

    and for all

    Proof 3.3 Consider a fixed

    let\Omega be the desired stability

    domain in R n and let R be such that z 0 ('')

    The interconnection term has linear growth in z, i.e. there exist two

    class- functions fl 1 and fl 2 such that

    The time-derivative of the Lyapunov function V satisfies

    dz

    jj(t; a)j

    cV (z t )jj(t; a)j

    During the interval [0;

    to\Omega . Therefore, when kzk  R,

    one can bound

    by a factor c 2 independent of

    a. Thus

    and when a trajectory leaves the set fz : kzk  Rg at t   , because

    t   jj(s;a)jds

    for some constant M , independently of a. In the above expression, V

    As a consequence, also k(z) and kz(t)k can be bounded, uniformly in

    a. Hence at time  the state z  , i.e. z(t); t 2 [0;  ] belongs to

    a compact

    region\Omega 2 independently of a.

    Now we can translate the original problem over one delay interval: at

    time  the initial conditions belong to the bounded

    region\Omega 2 and with t

    jj(s; a)jds

    Because of Theorem 3.1, we can increase a such that all solutions starting

    in\Omega 2 are bounded.

    Until now we assumed a fixed  . But because is compact, we can

    take the largest threshold of a for bounded solutions over this interval.

    Applications: stability of cascades and partial

    state feedback

    In this section we use the results given above to study the stability of cascade

    systems:

    whereby the subsystem

    with a functional of

    the form (3),

    globally asymptotically and locally exponentially

    stabilizable, h() is continuous and locally Lipschitz,

    partial state feedback laws investigate in which situations the

    equilibrum (z; can be made semiglobally asymptotically stable.

    4.1 LaSalle''s theorem

    Because the ''perturbation'' y in (17) is generated by a GAS ODE, we can

    strengthen the boundedness results in the previous section to asymptotic

    stability results, by applying a generalization to the time-delay case of the

    classical LaSalle''s theorem [7]:

    Theorem 4.1 (LaSalle Invariance Principle)

    Let\Omega be a positively invariant

    set of an autonomous ODE, and suppose that every solution starting

    in\Omega converges to a set E

    2\Omega . Let M be the largest invariant set contained

    in E, then every bounded solution starting

    in\Omega converges to M as t !1.

    This theorem is generalized to functional differential equations by Hale

    [3]: with the following definition of an invariant set,

    Definition 4.1 Let fT (t); t  0g be the solution semigroup associated to

    the functional differential equation , then a set Q ae C is called invariant if

    LaSalle''s theorem can be generalized to:

    Theorem 4.2 If V is a Lyapunov functional on G and x t is a bounded

    solution that remains in G, then x t converges to the largest invariant set in

    We will now outline its use in the context of stability of cascades. Suppose

    that in the cascade (17)-(18), with a particular feedback law the

    -subsystem is GAS. Hence there exists a Lyapunov function V () such that

    we use this Lyapunov function as a

    Lyapunov functional for the whole cascade, we can conclude from Theorem

    4.2 that every solution that remains bounded converges to the largest invariant

    set where and by the GAS of

    this is

    the equilibrium point (z; solutions are either unbounded or

    converge to the origin.

    By means of a local version of Theorem 3.1 one can show that the origin

    of (17)-(18) is stable.

    Hence the theorems of the previous section are strengthened to asymptotic

    stability theorems. For example under the conditions of Theorem 3.1,

    one can achieve semi-global asymptotic stability in both the state and the

    delay.

    4.2 Stabilization of partially linear cascades

    In the rest of this paper we assume a SISO linear driving system (the -

    with controllable and consider linear partial state feedback control

    laws . From the previous sections it is clear that the input y of the

    z-subsystem can act as a destabilizing disturbance. However, the control

    can drive the output of the linear system fast to zero. We will investigate

    under which conditions this is sufficient to stabilize the whole cascade. An

    important issue in this context is the so-called fast peaking phenomenon

    [15]. This is a structural property of the -system whereby imposing faster

    convergence of the output to zero implies larger overshoots which can in

    turn destabilize the cascade and may form an obstacle to both global and

    semi-global stabilizability. We start with a short description of the peaking

    phenomenon, based on [15], and then apply the results of the previous

    section to the stabilization of the cascade system.

    4.2.1 The peaking phenomenon

    When in the system,

    the pair (A; B) is controllable, one can always find state feedback laws

    F  resulting in an exponential decay rate with exponent \Gammaa. Then the

    output of the closed loop system satisfies

    where fl depends on the choice of the feedback gain. We are interested

    in the lowest achievable value of fl among different feedback laws and its

    dependence upon a.

    Denote by F(a) the collection of all stabilizing feedback laws

    with the additional property that all observable 1 eigenvalues  of (C; A F ),

    with A \Gammaa. For a given a and F 2 F(a), define

    the smallest value of fl in (22) as

    ky(t)ke at

    where the supremum is taken over all t  0 and all initial conditions satisfying

    k(0)k  1. Now denote by (a) = inf F2F(a)  F . The output of system

    (21) is said to have peaking exponent s when there exists constants ff

    such that

    In [15] one places all eigenvalues to the left of the line

    for large a. When the output is said to be nonpeaking.

    The peaking exponent s is a structural property related to the zero-

    dynamics: when the system has relative degree r, it can be transformed (in-

    cluding a preliminary feedback transformation) into the normal form [4][1]:

    ae

    which can be interpreted as an integrator chain linearly coupled with the

    zero-dynamics subsystem

    . Using state feedback the output of an

    integrator chain can be forced to zero rapidly without peaking [13]. Because

    of the linear interconnection term, stability of the zero-dynamics subsystem

    implies stability of the whole cascade. On the contrary, when the zero

    dynamics are unstable, some amount of energy, expressed by

    is needed for its stabilization and therefore the output must peak. More

    precisely we have the following theorem, proven in the appendix.

    Theorem 4.3 The peaking exponent s equals the number of eigenvalues in

    the closed RHP of the zero-dynamics subsystem.

    The definition of the peaking exponent (23) is based on an upper bound of

    the exponentially weighted output, while its L 1 -norm is important in most

    of the theorems of section 3. But because the overshoots related to peaking

    occur in a fast time-scale ( at), there is a connection. For instance we have

    the following theorem, based on a result of Braslavsky and Middleton [10]:

    Theorem 4.4 When the output y of system (21) is peaking (s  1), ky(t)k 1

    can not be reduced arbitrarily.

    Proof 4.1 Denote by z 0 an unstable eigenvalue of the zero-dynamics of

    (21). When a feedback is stabilizing the relation between y and

    in the Laplace-domain is given by

    with

    . The first term vanishes at z 0 because the eigenvalues of the

    zero dynamics appear as zeros in the corresponding transfer function H(s)

    and since the feedback F is stabilizing, no unstable pole-zero cancellation

    occurs at z 0 . Hence

    4.2.2 Nonpeaking cascades

    When the -subsystem is minimum-phase and thus nonpeaking, one can find

    state feedback laws resulting in

    and the L 1 -norm of the output can be made arbitrary small. So by Theorem

    3.1, the cascade (20) can be stabilized semi-globally in the state and in the

    delay.

    4.2.3 Peaking cascades

    When the -subsystem is nonminimum phase, the peaking phenomenon

    forms an obstacle to semi-global stabilizability, because the L 1 -norm of the

    output cannot be reduced (Theorem 4.4).

    For ODE-cascades, we illustrate the peaking obstruction with the following

    example:

    Example 4.1 In the cascade,

    the peaking exponent of the -subsystem is 1 (zero dynamics

    cascade cannot be stabilized semi-globally since the explicit solution of the

    first equation is given by

    whereby

    Hence the solution reaches infinity in a

    For DDE-cascades, we consider two cases:

    Case 1: Peaking exponent=1 We can apply theorem 3.3 and obtain

    semi-global stabilizability in the state and in the delay, when the interconnection

    term is linear in the undelayed argument: besides (25) the L 1 -norm

    of y can also be bounded from above since there exists feedback laws

    such that

    and because of the fast time-scale property, the energy can be concentrated

    since 8t ? 0:

    jy(s)jds

    ds ! 0 as a !1:

    Case 2: Peaking exponent ? 1 In this case, we expect the L 1 -norm of

    y to grow unbounded with a, as suggested by the following example:

    Example 4.2 When  k is considered as the output of the integrator chain,

    the peaking exponent is

    be reduced arbitrarily by achieving a faster exponential decay rate. In Proposition

    4.32 of [13], it is shown that with the feedback-law

    k=1 a n\Gammak+1 q solutions of

    there exists a constant c independent of a such that

    hence the particular feedback gain is able to achieve an upper

    bound which corresponds to definition (23), for each choice of the output

    . It is also shown in [13] that with the same feedback and with as

    initial condition  1

    d such that s such that

    As a consequence,

    while the peaking exponent of output

    With the two following examples, we show that when the energy of an

    exponentially decaying input perturbation ( e \Gammaat ) grows unbounded with

    a, an interconnection term which is linear in the undelayed argument, is

    not sufficient to bound the solutions semi-globally in the state. Because it

    is hard to deal in general with outputs generated by a linear system with

    peaking exponent s ? 1, we use an artificial perturbation a s e \Gammaat , which
    has

    both the fast time-scale property and the suitable growth-rate of the energy

    (a

    Example 4.3 The solutions of equation

    can not be bounded semi-globally in z by increasing a, for any  ? 0, if the

    ''peaking exponent'' s is larger than one. \Sigma

    Proof: Equation (26) has an exponential solution z e (t),

    z e

    ( a

    a s

    ff

    e a

    Consider the solution z(t) with initial condition z 0 j L ? 0 on [\Gamma; 0].
    For

    and consequently coincides on [o;  ] with

    For large a, expression (27) describes a decreasing lower bound on [; 2 ],

    since y(t) reaches its maximum in t   (a) with t   ! 0 as a ! 1. Thus

    imposing and from this

    one can argue 2 that z(t)  z e (t); t   . Thus the trajectory starting with

    initial condition L on [\Gamma; 0] is unbounded when

    Le L ff a

    a

    a s

    ff

    e 3a

    When s ? 2, for each value of L, the solution is unstable for large a, thus the

    attraction domain of the stable zero solution shrinks to zero. When

    a solution starting from L ?

    \Theta 3

    ffff is unstable for large a.


    Even when the interconnection term contains no terms in z(t), but only

    delayed terms of z, semi-global results are still not possible in general, as

    shown with the following example.

    2 Intersection at t   would imply

    Example 4.4 The solutions of the system

    with otherwise, can not be

    bounded semi-globally in z by increasing a, for any  ? 0, when the ''peaking

    exponent'' s is greater than one. \Sigma

    Proof: When z  1, equation (28) reduces to:

    which has the following explicit solution,

    z l (t) = at

    When the initial condition of (28) is L on [\Gamma; 0], during one delay-interval,

    one can find an lower bound of the solution by integrating

    with solution

    z

    When a is chosen such that b  1, the expression for z l (t) is valid for

    t  0. When z u (2) ? z l (2 ), one can argue that for large a, z u (t) ?

    z l (t); t 2 [; 2 ] and z u (t) describes a lower bound for the solution starting

    in L for reaches is maximum in t   (a) with t   ! 0 as

    1). Consequently, the trajectory with initial condition L on [\Gamma; 0],

    is unbounded when


    4.2.4 Zero dynamics with eigenvalues on the imaginary axis

    The situation where the zero dynamics possess eigenvalues on the imaginary

    axis but no eigenvalues in the open RHP deserves special attention. According

    to Theorem 4.3, the system is peaking, that is, the L 1 norm of the output

    cannot be reduced arbitrarily. However this energy can be ''spread out'' over

    a long time interval: it is indeed well known that a system with all its ei-

    genalues in the closed LHP can be stabilized with a low-gain feedback, as

    expressed by the following theorem, taken from [13]:

    Theorem 4.5 If a system

    stabilizable and the eigenvalues

    of A 0 are in the closed left half plane, then it can be stabilized with a

    low-gain control law which for large a satisfies:

    a

    The infinity-norm of such a low-gain control signal can be arbitrary reduced,

    which results, by theorem 3.2, in satisfactory stabilizability results when

    it also acts as an input disturbance of a nonlinear system. This suggests

    not to force the output of (21) exponentially fast ( e \Gammaat ) to zero, which

    results in peaking, but to drive it rapidly without peaking to the manifold

    on which the dynamics are controlled by the low-gain control

    action. Mathematically, with and a feedback transformation

    the normal form of the -subsystem is transformed into

    Using a high-gain feedback driving e(t) to zero without peaking, as proven

    in [13], proposition 4.37, one can always force the output to satisfy the

    constraint

    a

    with fl independent of a. A systematic treatment of such high-low gain

    control laws can be found in [8].

    For instance the system,

    ae

    is weakly minimum-phase (zero-dynamics

    0). With the high-low gain

    feedback the explicit solution of (30) for large a can be

    approximated by:

    a

    a

    a

    Perturbations satisfying constraint (29) can be decomposed in signals

    with vanishing L 1 and L1 -norm. This suggests the combination of theorems

    3.1 and 3.2 to:

    Theorem 4.6 Consider the interconnected system

    Suppose that the z-subsystem is GAS with the Lyapunov functional V (z t )

    satisfying Assumption 1.2 and the zeros of the -subsystem are in the closed

    LHP. Then the interconnected system can be made semi-globally asymptotically

    stable in both [z; ] and the delay, using only partial-state feedback.

    Proof 4.2 As argumented in the beginning of section 4, the origin (z;

    (0;

    Let\Omega be the desired region of attraction in the (z; )-

    space and choose R such that for all (z

    R. Because of the

    assumption on the -subsystem, there exist partial-state feedback laws such

    that

    with fl independent of a.

    Consider the time-interval [0; 1]. Because

    lim

    a

    one can show, as in the proof of theorem 3.1, that by taking a large, the

    increase of V can be limited arbitrary. Hence for t  1, the trajectories can

    be bounded inside a compact

    region\Omega 2 . We can now translate the original

    problem over one time-unit and since

    sup

    flR(e \Gammaat +a

    we can, by theorem 3.2, increase a until the stability domain

    Hence all trajectories starting

    in\Omega are bounded and converge to the origin,

    because of LaSalle''s theorem.

    Conclusions

    We studied the effect of bounded input-perturbations on the stability of

    nonlinear delay equations of the form (1).

    Global stability results are generally not possible without structural assumptions

    on the interconnection term because arbitrary small perturbations

    can lead to unbounded trajectories, even when they are exponentially

    decaying. In the ODE-case this is caused by the fact that superlinear

    destabilizing terms can drive the state to infinity in a finite time. Superlinear

    delayed terms cannot cause finite-escape but can still make trajectories

    diverge faster than any exponential function.

    In a second part we dropped most of the structural assumptions on

    the unperturbed system and the interconnection term and considered semi-global

    results when the size of the perturbation can be reduced arbitrary.

    Here we assumed that the unperturbed system is delay-independent stable.

    When the L 1 or the L1 norm of the perturbations is brought to zero,

    trajectories can be bounded semi-globally in both the state and the delay.

    By means of examples we explained mechanisms prohibiting global results in

    the delay. We also considered the effect of concentrating a perturbation with

    a fixed L 1 -norm near the origin. This leads to semi-global stabilizability in

    the state and compact delay-intervals not containing the origin, when the

    interconnection term is linear in its undelayed arguments.

    As an application, we studied the stabilizability of partial linear cascades

    using partial state feedback. When the interconnection term

    is nonlinear, output peaking of the linear system can form an obstruction

    to semi-global stabilizability because the L 1 -norm of the output cannot be

    reduced by achieving a faster exponential decay rate. If we assume that

    the interconnection term is linear in the undelayed argument and the peaking

    exponent is one, we have semi-global stabilizability results, because the

    of the output can be bounded from above while concentrating its

    energy. Even with the above assumption on the interconnection term, higher

    peaking exponents may form an obstruction. When the zeros of the linear

    driving system are in the closed left half plane, we have satisfactory stability

    results when using a high-low gain feedback, where the output of the

    linear subsystem can be decomposed in two signals with vanishing L 1 and

    L1 norm respectively.

    The main contribution of this paper lies in placing the classical cascade

    results in the more general framework of bounded input perturbations and

    its generalization to a class of functional differential equations.


    Acknowledgements


    The authors thank W.Aernouts for fruitful discussions on the results presented

    in the paper. This paper presents research results of the Belgian programme

    on Interuniversity Poles of Attraction, initiated by the Belgian

    State, Prime Minister''s Office for Science, Technology and Culture (IUAP

    P4/02). The scientific responsibility rests with its authors.




    --R


    Asymptotic stability of minimum phase non-linear systems

    Sufficient conditions for stability and instability of autonomous functional-differential
    equations


    Nonlinear control systems.

    Introduction to the theory and application of functional differential equations

    Stability of Functional Differential Equations

    Stability theory of ordinary differential equations.


    Robustness of nonlinear delay equations w.


    How violent are fast controls?

    Slow peaking and low-gain design for global stabilization of nonlinear systems

    Constructive Nonlinear Control.

    On the input-to-state stability properties

    The peaking phenomenon and the global stabilization of nonlinear systems.

    Tools for semiglobal stabilization by partial state and output feedback.

    nonlinear small gain theorem for the analysis of control systems with saturation.


    --TR'
  sentences:
  - cascade systems
  - approximate probabilistic inference
  - curve centers
- source_sentence: '--T

    Inversion of Analytic Matrix Functions That are Singular at the Origin.

    --A

    In this paper we study the inversion of an analytic matrix valued function A(z).
    This problem can also be viewed as an analytic perturbation of the matrix A0=A(0).
    We are mainly interested in the case where A0 is singular but A(z) has an inverse
    in some punctured disc around z=0. It is known that A-1(z) can be expanded as
    a Laurent series at the origin. The main purpose of this paper is to provide efficient
    computational procedures for the coefficients of this series. We demonstrate that
    the proposed algorithms are computationally superior to symbolic algebra when
    the order of the pole is small.

    --B

    Introduction

    Let fA k g k=0;1;::: '' R n\Thetan be a sequence of matrices that de-nes the analytic
    matrix valued

    function

    The above series is assumed to converge in some non-empty neighbourhood of z =
    0. We will

    also say that A(z) is an analytic perturbation of the matrix A Assume the inverse

    matrices A \Gamma1 (z) exist in some (possibly punctured) disc centred at In particular,
    we

    are primarily interested in the case where A 0 is singular. In this case it is
    known that A \Gamma1 (z)

    can be expanded as a Laurent series in the form

    A

    and s is a natural number, known as the order of the pole at z = 0. The main

    purpose of this paper is to provide eOEcient computational procedures for the
    Laurent series

    coeOEcients As one can see from the following literature review, few computational

    methods have been considered in the past.

    This work was supported in part by Australian Research Council Grant #A49532206.

    y INRIA Sophia Antipolis, 2004 route des Lucioles, B.P.93, 06902, Sophia Antipolis
    Cedex, France, e-mail:

    k.avrachenkov@sophia.inria.fr

    z Department of Statistics, The Hebrew University, 91905 Jerusalem, Israel and
    Department of Economet-

    rics, The University of Sydney, Sydney, NSW 2006, Australia, e-mail: haviv@mscc.huji.ac.il

    x CIAM, School of Mathematics, The University of South Australia, The Levels,
    SA 5095, Australia, e-mail:

    The inversion of nearly singular operator valued functions was probably -rst studied
    in

    the paper by Keldysh [22]. In that paper he studied the case of a polynomial perturbation

    are compact operators on Hilbert space. In particular, he showed that

    the principal part of the Laurent series expansion for the inverse operator A
    \Gamma1 (z) can be

    given in terms of generalized Jordan chains. The generalized Jordan chains were
    initially

    developed in the context of matrix and operator polynomials (see [13, 26, 30]
    and numerous

    references therein). However, the concept can be easily generalized to the case
    of an analytic

    perturbation (1).

    Following Gohberg and Sigal [15] and Gohberg and Rodman [14], we say that the
    vectors

    Jordan chain of the perturbed matrix A(z) at

    for each 0 - k - r \Gamma 1. Note that '' 0 is an eigenvector of the unperturbed
    matrix A 0

    corresponding to the zero eigenvalue. The number r is called the length of the
    Jordan chain

    and '' 0 is the initial vector. Let f'' (j)

    j=1 be a system of linearly independent eigenvectors,

    which span the null space of A 0 . Then one can construct Jordan chains initializing
    at each

    of the eigenvectors '' (j)

    0 . This generalized Jordan set plays a crucial role in the analysis of

    analytic matrix valued functions A(z).

    Gantmacher [11] analysed the polynomial matrix (3) by using the canonical Smith
    form.

    Vishik and Lyusternik [37] studied the case of a linear perturbation

    showed that one can express A \Gamma1 (z) as a Laurent series as long as A(z)
    is invertible in some

    punctured neighbourhood of the origin. In addition, an undetermined coeOEcient
    method for

    the calculation of Laurent series terms was given in [37]. Langenhop [25] showed
    that the

    coeOEcients of the regular part of the Laurent series for the inverse of a linear
    perturbation

    form a geometric sequence. The proof of this fact was re-ned later in Schweitzer
    [33, 34] and

    Schweitzer and Stewart [35]. In particular, the paper [35] proposed a method for
    computing

    the Laurent series coeOEcients. However the method of [35] cannot be applied (at
    least imme-

    diately) to the general case of an analytic perturbation. Many authors have obtained
    existence

    results for operator valued analytic and meromorphic functions [3, 15, 23, 27,
    29, 36]. In par-

    ticular, Gohberg and Sigal [15], used a local Smith form to elaborate on the structure
    of the

    principal part of the Laurent series in terms of generalized Jordan chains. Recently,
    Gohberg,

    Kaashoek and Van Schagen [12] have re-ned the results of [15]. Furthermore, Bart,
    Kaashoek

    and Lay [5] used their results on the stability of the null and range spaces [4]
    to prove the

    existence of meromorphic relative inverses of -nite meromorphic operator valued
    functions.

    The ordinary inverse operator is a particular case of the relative inverse. For
    the applications

    of the inversion of analytic matrix functions see for example [8, 9, 20, 23, 24,
    28, 31, 32, 36].

    Howlett [20] provided a computational procedure for the Laurent series coeOEcients
    based

    on a sequence of row and column operations on the coeOEcients of the original
    power series

    (1). Howlett used the rank test of Sain and Massey [32] to determine s, the order
    of the pole.

    He also showed that the coeOEcients of the Laurent series satisfy a -nite linear
    recurrence

    relation in the case of a polynomial perturbation. The method of [20] can be considered
    as a

    starting point for our research. The algebraic reduction technique which is used
    in the present

    paper was introduced by Haviv and Ritov [17, 18] in the special case of stochastic
    matrices.

    Haviv, Ritov and Rothblum [19] also applied this approach to the perturbation
    analysis of

    semi-simple eigenvalues.

    In this paper we provide three related methods for computing the coeOEcients of
    the Laurent

    series (2). The -rst method uses generalized inverse matrices to solve a set of
    linear

    equations and extends the work in [17] and [20]. The other two methods use results
    that

    appear in [2, 17, 18, 19] and are based on a reduction technique [6, 10, 21, 23].
    All three

    methods depend in a fundamental way on equating coeOEcients for various powers
    of z. By

    substituting the series (1) and (2) into the identity A(z)A I and collecting coeOE-

    cients of the same power of z, one obtains the following system which we will
    refer to as the

    fundamental equations:

    A similar system can written when considering the identity A I but of course

    the set of fundamental equations (4:0); suOEcient. Finally, for matrix operators

    each in-nite system of linear equations uniquely determines the coeOEcients of
    the Laurent

    series (2). This fact has been noted in [3, 20, 23, 37, 36].

    Main results

    Let us de-ne the following augmented matrix A (t) 2 R (t+1)n\Theta(t+1)n

    A (t) =6 6 6 6 6 4

    A t A

    and prove the following basic lemma.

    s be the order of the pole at the origin for the inverse function A \Gamma1 (z).
    Any

    eigenvector \Phi 2 R (s+1)n of A (s) corresponding to the zero eigenvalue possesses
    the property

    that its -rst n elements are zero.

    Proof: Suppose on the contrary that there exists an eigenvector \Phi 2 R (s+1)n
    such that

    A

    and not all of its -rst n entries are zero. Then, partition the vector \Phi into
    s blocks and

    rewrite (5) in the form

    with '' 0 6= 0. This means that we have found a generalized Jordan chain of length
    s + 1.

    However, from the results of Gohberg and Sigal [15], we conclude that the maximal
    length

    of a generalized Jordan chain of A(z) at z = 0 is s. Hence, we came to a contradiction
    and,

    consequently,

    direct proof of Lemma 1 is given in Appendix 1.

    vectors \Phi 2 R (s+j+1)n in the null space of the augmented matrix A (s+j) ,
    j - 0,

    possess the property that the -rst (j + 1)n elements are zero.

    The following theorem provides a theoretical basis for the recursive solution
    of the in-nite

    system of fundamental equations (4).

    Theorem 1 Each coeOEcient X k , k - 0 is uniquely determined by the previous coeOEcients

    and the set of s fundamental equations

    Proof: It is obvious that the sequence of Laurent series coeOEcients fX i

    i=0 is a solution

    to the fundamental equations (4). Suppose the coeOEcients X i ,

    determined. Next we show that the set of fundamental equations (4.k)-(4.k+s) uniquely

    determines the next coeOEcient X k . Indeed, suppose there exists another solution
    ~

    are both solutions, we can write

    A (s)6 4

    ~

    ~

    and

    A (s)6 4

    where the matrix J i is de-ned as follows:

    ae

    and where ~

    X k+s are any particular solutions of the nonhomogenous linear system

    (4.k)-(4.k+s). Note that (6) and (7) have identical righthand sides. Of course,
    the dioeerence

    between these two righthand sides, [ ~

    is in the right null space of

    A Invoking Lemma 1, the -rst n rows of [ ~

    are hence zero. In

    other words, ~

    which proves the theorem.Using the above theoretical background, in the next section
    we provide three recursive

    computational schemes which are based on the generalized inverses and on a reduction
    tech-

    nique. The reduction technique is based on the following result. A weaker version
    of this

    result was utilized in [17] and in [19].

    Theorem 2 Let fC k g t

    suppose that the

    system of t equations

    is feasible. Then the general solution is given by

    (R

    where C y

    0 is the Moore-Penrose generalized inverse of C 0 and Q 2 R m\Thetap is any matrix
    whose

    columns form a basis for the right null space of C 0 . Furthermore, the sequence
    of matrices

    solves a reduced -nite set of t matrix equations

    where the matrices D k 2 R p\Thetap and S k 2 R p\Thetan , are computed by the
    following

    recursion. Set U

    Then,

    where M 2 R p\Thetam is any matrix whose rows form a basis for the left null space
    of C 0 .

    Proof: The general solution to the matrix equation (7.0) can be written in the
    form

    arbitrary matrix.

    In order for the equation

    to be feasible, we need that the right hand side R belongs to R(C 0

    is

    where the rows of M form a basis for N(C T

    Substituting expression (13) for the general

    solution into the above feasibility condition, one -nds that W 0 satis-es the
    equation

    which can be rewritten as

    Thus we have obtained the -rst reduced fundamental equation (9.0) with

    Next we observe that the general solution of equation (7.1) is represented by

    the formula

    (R

    with . Moving on and applying the feasibility condition to equation (7.2), we

    obtain

    and again the substitution of expressions (13) and (14) into the above condition
    yields

    (R

    which is rearranged to give

    The last equation is the reduced equation (9.1) with

    . Note that this equation imposes restrictions on W 1 as well as on

    By proceeding in the same way, we eventually obtain the complete system of equations

    with coeOEcients given by formulas (11) and (12) each of which can be proved by
    induction

    in a straightforward way.Remark 3 In the above theorem it is important to observe
    that the reduced system has the

    same form as the original but the number of matrix equations is decreased by one
    and the

    coeOEcients are reduced in size to matrices in R p\Thetap , where p is the dimension
    of N(C 0 ) or,

    equivalently, the number of redundant equations de-ned by the coeOEcient C 0 .

    In the next section we use this reduction process to solve the system of fundamental

    equations. Note that the reduction process can be employed to solve any appropriate
    -nite

    subset of the fundamental equations.

    3 Solution methods

    In this section we discuss three methods for solving the fundamental equations.
    The -rst

    method is based on the direct application of Moore-Penrose generalized inverses.
    The second

    method involves the replacement of the original system of the fundamental equations
    by

    a system of equations with a reduced dimension. In the third method we show that
    the

    reduction process can be applied recursively to reduce the problem to a non-singular
    system.

    Since all methods depend to some extent on the prior knowledge of s, we begin
    by discussing

    a procedure for the determination of s. A special procedure for determining this
    order for the

    case where the matrices A(z) are stochastic and the perturbation series is -nite
    is given in [16].

    It is based on combinatorial properties (actually, network representation) of
    the processes and

    hence it is a stable procedure. However, as will be seen in Section 3.4, it is
    possible to use

    the third method without prior knowledge of s. Actually, the full reduction version
    of our

    procedure determines s as well. Of course, as in any computational method which
    is used to

    determine indices which have discrete values, using our procedures in order to
    compute the

    order of singularity might lack stability.

    3.1 The determination of the order of the pole

    The rank test on the matrix A (t) proposed by Sain and Massey in [32] is likely
    to be the

    most eoeective procedure for determining the value of s. The calculation of rank
    is essentially

    equivalent to the reduction of A (t) to a row echelon normal form and it can be
    argued that

    row operations can be used successively in order to calculate the rank of A (0)
    ,A (1) ,A (2)

    and -nd the minimum value of t for which rankA (t\Gamma1) +n. This minimum value
    of t equals s,

    the order of the pole. Note that previous row operations for reducing A (t\Gamma1)
    to row echelon

    form are replicated in the reduction of A (t) and do not need to be repeated.
    For example,

    if a certain combination of row operations reduces A 0 to row echelon form, then
    the same

    operations are used again as part of the reduction of

    to row echelon form.

    3.2 Basic generalized inverse method

    In this section we obtain a recursive formula for the Laurent series coeOEcients
    X k , k - 0 by

    using the Moore-Penrose generalized inverse of the augmented matrix A (s) .

    y be the Moore-Penrose generalized inverse of A (s) and de-ne the matrices

    G

    G

    G

    0s

    G

    Furthemore, we would like to note that in fact we use only the -rst n rows of
    the generalized

    namely, [G

    Proposition 1 The coeOEcients of the Laurent series (2) can be calculated by the
    following

    recursive formula

    s

    G

    0s and the matrix J i is de-ned by

    ae

    Proof: According to Theorem 1, once the coeOEcients X i , are determined, the

    next coeOEcient X k can be obtained from the (4.k)-(4.k+s) fundamental equations.

    A (s)6 4

    The general solution to the above system is given in the form6 6 6 4

    ~

    ~

    G

    0s

    G

    1s

    G

    where the -rst block of matrix \Phi is equal to zero according to Lemma 1. Thus,
    we immediately

    obtain the recursive expression (15). In particular, applying the same arguments
    as above to

    the -rst s we obtain that

    0s .Note that the matrices J j+k in the expression (15) disappear when the regular
    coeOEcients

    are computed.

    Remark 4 The formula (15) is a generalization of the recursive formula for the
    case where

    A 0 is invertible. In this case,

    while initializing with

    Remark 5 Probably from the computational point of view it is better not to compute
    the

    generalized inverse G (s) beforehand, but rather to -nd the SVD or LU decomposition
    of A

    and then use these decompositions for solving the fundamental equations (3:k)-(3:k
    + s). This

    is the standard approach for solving linear systems with various righthand sides.

    3.3 The one step reduction process

    In this section we describe an alternative scheme that can be used in the case
    where it is

    relatively easy to compute the bases for the right and for the left null spaces
    of A 0 . Speci-cally,

    be the dimension of the null space of A 0 , let Q 2 IR n\Thetap be a matrix whose

    columns form a basis for the right null space of A 0 and let M 2 IR p\Thetan be
    a matrix whose p

    rows form a basis for the left null space of A 0 . Of course, although

    possible, we are interested in the singular case where p - 1.

    Again, as before, we suppose that the coeOEcients X i ,

    determined. Then, by Theorem 1, the next coeOEcient X k is the unique solution
    to the

    subsystem of fundamental equations

    The above system is like the one given in (9) with C and with R

    Therefore, we can apply the reduction process described

    in Theorem 2. This results in the system

    where the coeOEcients D i and S i , can be calculated by the recursive formulae

    (11) and (12).

    Remark 6 Note that in many practical applications p is much less than n and hence
    the

    above system (17) with D i 2 IR p\Thetap is much smaller than the original system
    (16).

    Now we have two options. We can either apply the reduction technique again (see
    the

    next subsection for more details) or we can solve the reduced system directly
    by using the

    generalized inverse approach. In the latter case, we de-ne

    and

    0t

    Then, by carrying out a similar computation to the one presented in the proof
    of Proposition 1,

    we obtain

    Once W 0 is determined it is possible to obtain X k from the formula

    Furthermore, substituting for S i , 0 - i - s\Gamma1, from (12) and changing the
    order of summation

    gives

    A y

    s

    Note that by convention the sum disappears when the lower limit is greater than
    the upper

    limit. Now, substituting R

    into the expression (18), we

    obtain the explicit recursive formula for the Laurent series coeOEcients

    A y

    s

    A (J k+j \Gamma

    for all k - 1. In particular, the coeOEcient of the -rst singular term in (2)
    can be given by the

    3.4 The complete reduction process

    As was pointed out in the previous section, the reduced system has essentially
    the same

    structure as the original one and hence one can apply again the reduction step
    described in

    Theorem 2. Note that each time the reduction step is carried out, the number of
    matrix

    equations is reduced by one. Therefore one can perform up to s reduction steps.
    We now

    outline how these steps can be executed. We start by introducing the sequence
    of reduced

    systems. The fundamental matrix equations for the l-th reduction step are

    A (l)

    A (l)

    A (l)

    s\Gammal X (l)

    s\Gammal

    one gets the original system of fundamental equations and with gets the

    reduced system for the -rst reduction step described in the previous subsection.
    Initializing

    with R (0)

    I and with A (0)

    s, the matrices A (l)

    and R (l)

    for each reduction step 1 - l - s, can be computed successively by a

    recursion similar to (11) and (12). In general we have

    U (l)

    A (l\Gamma1)

    A (l)

    R (l)

    U (l)

    where Q (l) and M (l) are the basis matrices for the right and left null spaces
    respectively of

    the matrix A (l\Gamma1)

    0 and where A (l\Gamma1)y

    0 is the Moore-Penrose generalized inverse of A (l\Gamma1)

    . After

    s reduction steps, one gets the -nal system of reduced equations

    A

    is a unique solution to the subsystem of fundamental equations (4.0)-(4.s) and

    Theorem 2 states the equivalence of the l-th and (l 1)-st systems of reduced equations,
    the

    system (22) possesses a unique solution, and hence matrix A

    0 is invertible. Thus,

    The original solution X

    0 can be now retrieved by the backwards recursive relationship

    Now by taking R (0)

    one gets the algorithm for computing

    the Laurent series coeOEcients recursive formulae similar to (15) and (19)

    can be obtained, but they are quite complicated in the general case.

    The order s of the pole can also be obtained from the reduction process by continuing
    the

    process until A (l)

    becomes non-singular. The number of reduction steps equals the order of

    the pole. Note also that the sequence of matrices A (l)

    can be computed irrespectively

    of the right hand sides. Once s is determined, one can compute R (l)

    Computational complexity and comparison with symbolic algebr


    In this section we compare the computational complexity of the one-step-reduction
    process

    when applied to compute X 0 with the complexity of symbolic algebra. In particular,
    we show

    that the former comes with a reduced complexity in the case where the pole has
    a relatively

    small order. The computational complexity of the other two procedures can be determined

    similarly.

    To compute the coeOEcients D i , of the reduced fundamental system (17),

    one needs to perform O(s 2 n 3 ) operations. The total number of reduced equations
    is sp

    (recall that p is the dimension of the null space of A 0 ). Hence, the computational
    complexity

    for determining X 0 by the one-step-reduction process is O(maxfs 2 g). The Laurent

    series (2) in general, and the coeOEcient X 0 in particular, can also be computed
    by using

    symbolic algebra. This for example can be executed by MATLAB symbolic toolbox
    and is

    done as follows. Since X 0 is uniquely determined by the -rst s equations

    one needs to do in order to compute X 0 is it to invert symbolically the

    following matrix polynomial

    Symbolic computations here mean performing operations, such as multiplication
    and division,

    over the -eld of rational functions (and not over the -eld of the reals). In particular,
    if the

    degrees of numerators and of denominators of rational functions do not exceed
    q, then each

    operation (multiplication or division) which is performed in the -eld of rational
    functions

    translates into qlog(q) operations in the -eld of real numbers [1]. Note that
    during the

    symbolic inversion of the polynomial matrix (25), the degree of rational functions
    does not

    exceed sn. The latter fact follows from Cramer''s rule. Thus, the complexity of
    the symbolic

    inversion of (25) equals O(n 3 ) \Theta log(sn)). As a result, one gets a matrix

    A \Gamma1 (z) whose elements are rational functions of z. The elements of the
    matrix X 0 can then be

    immediately calculated by dividing the leading coe-cients of the numerator and
    denominator.

    Finally, one can see that if s !! n and p !! n, which is typically the case, then
    our method

    comes with a reduced computational burden.

    Concluding remarks

    In this paper we have shown that the Laurent series for the inversion of an analytic
    matrix

    valued function can be computed by solving a system of fundamental linear equations.

    Furthermore, we demonstrated that the system of fundamental equations can be solved
    recur-

    sively. In particular, the coeOEcient X k is determined by the previous coeOEcients
    X

    and the next s is the order of the pole. We suggest three

    basic methods, one without any reduction (see (15)), one with a single reduction
    step (see

    and (20)), and one using a complete reduction process with s steps (see (23) and
    (24)).

    Of course, an intermediate process with the number of reductions between 1 and
    s could be

    used too. We note that when the complete reduction process is used the order of
    the pole

    can be determined through the execution of the algorithm. When s !! n and p !!
    n, the

    proposed algorithms by far outperform the method based on symbolic algebra.


    Acknowledgement


    The authors are grateful to Prof. Jerzy A. Filar for his helpful advice. Also
    the authors would

    like to thank anonymous referees for their valuable suggestions and for directing
    us to some

    existing literature.

    Apendix 1: Another proof of Lemma 1

    A direct proof of Lemma 1 can be carried out using augmented matrices. Speci-cally,
    de-ne

    are the coeOEcients of the Laurent series (2). Then it follows from

    the fundamental systems (4) and (5) that the augmented matrices A (t) and X (t)
    satisfy the

    relationship

    where the augmented matrix E (t) 2 R (t+1)n\Theta(t+1)n is de-ned by setting

    p;q=0 where

    n\Thetan and

    ae

    I for

    s:

    Now, as before, let \Phi 2 R (s+1)n satisfy the equation

    A

    If we multiply equation (27) from the left by X reduces to

    The vector E (s) \Phi has '' 0 as the (s 1)-st block, which gives the required
    result.

    Apendix 2: A Numerical example

    Let us consider the matrix valued function

    where 2. Construct the augmented matrices

    and note that which is the dimension of the original

    coeOEcients A 0 and A 1 . Therefore, according to the test of Sain and Massey
    [32], the Laurent

    expansion for A \Gamma1 (z) has a simple pole. Alternatively, we can compute a
    basis for

    which in this particular example consists of only one vector

    \Theta

    The -rst three zero elements in q (1) con-rm that the Laurent series has a simple
    pole. Next

    we compute the generalized inverse of A (1) given by

    G (1)

    1=3 \Gamma5=12 \Gamma1=12 1=8 1=8 \Gamma1=8

    1=3 \Gamma5=12 \Gamma1=12 \Gamma3=8 \Gamma3=8 3=8

    Consequently,

    \Gamma3 \Gamma3

    Alternatively, we know that X 0 is uniquely determined by the fundamental equations

    After one reduction step these equations reduce to

    where

    \Theta


    and

    \Theta

    Hence,

    \Theta


    and


    \Gamma3 \Gamma3

    The latter expression is identical with (28) and coincides with the one computed
    by expanding

    A \Gamma1 (z) with the help of the MATLAB symbolic toolbox. Note that even for
    this three

    dimensional example the direct symbolic calculation of the Laurent series takes
    a relatively

    long time.




    --R


    The design and analysis of computer algorithms

    The fundamental matrix of singularly perturbed Markov chains

    Meromorphic operator valued functions.

    Stability properties of

    Relative inverses of meromorphic operator functions and associated holomorphic
    projection functions


    Generalized Inverses of Linear Transformation

    iSingular systems of dioeerential equationsj

    iSingular systems of dioeerential equations IIj

    A reduction process for perturbed Markov chains

    The theory of matrices

    On the local theory of regular analytic matrix functions

    Matrix Polynomials

    Analytic matrix functions with prescribed local data

    An operator generalization of the logarithmic residue theorem and the theorem
    of Rouch

    Mean passage times and nearly uncoupled Markov chains

    Series expansions for

    Matrix Anal.

    iTaylor expansions of eigenvalues of perturbed matrices with applications to spectal
    radii of nonnegative matrices

    Input retrieval in

    Perturbation theory for linear operators

    On the characteristic values and characteristic functions of certain classes of
    non-selfadjoint equations

    Mathematical foundations of the state lumping of large systems

    iInversion of lambda-matrices and application to the theory of linear vibrationsj

    The Laurent expansion for a nearly singular matrix

    Introduction to the spectral theory of polynomial operator pencils

    iSpectral properties of a polynomial op- eratorj

    Theory of Suboptimal Decisions


    An introduction to operator polynomials

    The Laurent expansion of a generalized resolvent with some applications

    Invertibility of linear time invariant dynamical systems

    The Laurent expansion for a nearly singular pencil

    Perturbation series expansions for nearly completely-decomposable Markov chains

    The Laurent expansion of pencils that are singular at the origin

    Theory of branching of solutions of non-linear equations

    The solution of some perturbation problems in the case of matrices and self-adjoint
    and non-self-adjoint dioeerential equations

    --TR


    --CTR

    Jerzy A. Filar, Controlled Markov chains, graphs, and Hamiltonicity, Foundations
    and Trends in Stochastic Systems, v.1 n.2, p.77-162, January 2006'
  sentences:
  - isosurface extraction
  - sparse linear systems
  - array bounds check
- source_sentence: '--T

    Accelerating filtering techniques for numeric CSPs.

    --A

    Search algorithms for solving Numeric CSPs (Constraint Satisfaction Problems)
    make an extensive use of filtering techniques. In this paper we show how those
    filtering techniques can be accelerated by discovering and exploiting some regularities
    during the filtering process. Two kinds of regularities are discussed, cyclic
    phenomena in the propagation queue and numeric regularities of the domains of
    the variables. We also present in this paper an attempt to unify numeric CSPs
    solving methods from two distinct communities, that of CSP in artificial intelligence,
    and that of interval analysis.

    --B

    Introduction

    In several fields of human activity, like engineering, science or business, people
    are

    able to express their problems as constraint problems. The CSP (Constraint Satisfaction

    Problem) schema is an abstract framework to study algorithms for solving such
    constraint

    problems. A CSP is defined by a set of variables, each with an associated domain
    of

    possible values and a set of constraints on the variables. This paper deals more
    specifically

    with CSPs where the constraints are numeric nonlinear relations and where the
    domains

    are continuous domains (numeric CSPs).

    * Corresponding author.

    E-mail addresses: ylebbah@univ-oran.dz (Y. Lebbah), olhomme@ilog.fr (O. Lhomme).

    This paper is an extended version of [31].

    see front matter  2002 Elsevier Science B.V. All rights reserved.

    In general, numeric CSPs cannot be tackled with computer algebra systems: there
    is no

    algorithm for general nonlinear constraint systems. And most numeric algorithms
    cannot

    guarantee completeness: some solutions may be missed, a global optimum may never
    be

    found, and, sometimes a numeric algorithm even does not converge at all. The only
    numeric

    algorithms that can guarantee completeness-even when floating-point computations
    are

    used-are coming either from the interval analysis community or from the AI community

    (CSP). Unfortunately, those safe constraint-solving algorithms are often less
    efficient than

    non-safe numeric methods, and the challenge is to improve their efficiency.

    The safe constraint-solving algorithms are typically a search-tree exploration
    where a

    filtering technique is applied at each node. Improvement in efficiency is possible
    by finding

    the best compromise between a filtering technique that achieves a strong pruning
    at a high

    computational cost and another one that achieves less pruning at a lower computational

    cost. And thus, a lot of filtering techniques have been developed. Some filtering
    techniques

    take their roots from numerical analysis: the main filtering technique used in
    interval

    analysis [37] is an interval variation of Newton iterations. (See [24,28] for
    an overview

    of such methods.) Other filtering techniques originate from artificial intelligence:
    the basic

    filtering technique is a kind of arc-consistency filtering [36] adapted to numeric
    CSPs [17,

    26,32]. Higher-order consistencies similar to k-consistency [21] have also been
    defined

    for numeric CSPs [25,32]. Another technique from artificial intelligence [19,20]
    is to

    merge the constraints concerning the same variables, giving one "total" constraint
    (thanks

    to numerical analysis techniques) and to perform arc-consistency on the total
    constraints.

    Finally, [6,45] aim at expressing interval analysis pruning as partial consistencies,
    bridging

    the gap between the two families of filtering techniques.

    All the above works address the issue of finding a new partial consistency property
    that

    can be computed by an associated filtering algorithm with a good efficiency (with
    respect

    to the domain reductions performed). Another direction, in the search of efficient
    safe

    algorithms, is to try to optimize the computation of already existing consistency
    techniques.

    Indeed, the aim of this paper is to study general methods for accelerating consistency

    techniques. The main idea is to identify some kinds of regularity in the dynamic
    behavior

    of a filtering algorithm, and then to exploit those regularities. A first kind
    of regularities

    we exploit is the existence of cyclic phenomena in the propagation queue of a
    filtering

    algorithm. A second kind of regularities is a numeric regularity: when the filtering
    process

    converges asymptotically, its fixed point often can be extrapolated. As we will
    see in the

    paper, such ideas, although quite general, may lead to drastic improvements in
    efficiency

    for solving numeric CSPs. The paper focus on numeric continuous problems, but
    the ideas

    are more general and may be of interest also for mixed discrete and continuous
    problems,

    or even for pure discrete problems.

    The paper is organized in two main parts. The first part (Section 2) presents
    an

    overview of numeric CSPs; artificial intelligence works and interval analysis
    works

    are presented through a unifying framework. The second part consists of the next
    two

    sections, and presents the contribution of the paper. Section 3 introduces the
    concept of

    reliable transformation, and presents two reliable transformations that exploit
    two kinds

    of regularities occurring during the filtering process: cyclic phenomena in the
    propagation

    queue and numeric regularities of the domains of the variables. Section 4 discusses
    related

    works.

    2. Numeric CSPs

    This section presents numeric CSPs in a slightly non-standard form, which will
    be

    convenient for our purposes, and will unify works from interval analysis and constraint

    satisfaction communities.

    A numeric CSP is a triplet #X , D,C# where:

    . X is a set of n variables x 1 , . , x n .

    . denotes a vector of domains. The ith component of D, D i , is the

    domain containing all acceptable values for x i .

    . denotes a set of numeric constraints.

    denotes the variables

    appearing in C j .

    This paper focuses on CSPs where the domains are intervals: D #

    {[a,

    The following notation is used throughout the paper. An interval [a,

    b] such that a > b

    is an empty interval. A vector of domains D such that a component D i is an empty

    interval will be denoted by #. The lower bound, the upper bound and the midpoint
    of an

    interval D i (respectively interval vector D) are respectively denoted by D i
    , D i , and

    (respectively D, D, and

    m( D)). The lower bound, the upper bound, the midpoint, the

    inclusion relation, the union operator and the intersection operator are defined
    over interval

    vectors; they have to be interpreted componentwise. For instance D means #D 1
    , . , D n #;

    D #D means D # i #D i for all i # 1, . , n; D #D # means #D #

    A k-ary constraint C

    k-ary relation over the real numbers, that

    is, a subset of R k .

    2.1. Approximation of projection functions

    The algorithms used over numeric CSPs typically work by narrowing domains and

    need to compute the projection-denoted #C j ,x

    i( D) or also #

    j,i( D)-of a constraint

    over the variable x i in the space delimited by D . The

    projection #

    j,i( D) is defined as follows.

    . If x i /

    . If x i #

    the projection is defined by the set of all elements

    we can find elements for the k - 1 remaining variables of

    # . (1)

    Usually, such a projection cannot be computed exactly due to several reasons,
    such as:

    (1) the machine numbers are floating point numbers and not real numbers so round-off

    errors occur; (2) the projection may not be representable as floating-point numbers;
    (3) the

    computations needed to have a close approximation of the projection of only one
    given

    constraint may be very expensive; (4) the projection may be discontinuous whereas
    it is

    much easier to handle only closed intervals for the domains of the variables.

    Thus, what is usually done is that the projection of a constraint over a variable
    is

    approximated. Let #C j ,x

    i( D) or also #

    j,i( D) denote such an approximation. In order to

    guarantee that all solutions of a numeric CSP can be found, a solving algorithm
    that uses

    D) needs that #

    D) includes the exact projection. We will also assume in the rest

    of the paper that #

    j,i( D) satisfies a contractance property. Thus we have:

    D) hides all the problems seen above. In particular, it allows us not to go into
    the

    details of the relationships between floating point and real numbers (see for
    example [2]

    for those relationships) and to consider only real numbers. It only remains to
    build such a

    # j,i . Interval analysis [37] makes it possible.

    2.1.1. Interval arithmetic

    Interval arithmetic [37], on which interval analysis is built, is an extension
    of real

    arithmetic. It defines the arithmetic functions {+,-,#,/} over the intervals with
    simple

    set extension semantics.

    Notation. To present interval arithmetic, we will use the following convention
    to help the

    reading: x, y will denote real variables or vectors of real variables and X,Y
    will denote

    interval variables or vectors of interval variables. Distinction between a scalar
    variable and

    a vector of variables will be clear from the context.

    With this notation, an arithmetic function #,/} over the intervals is defined

    by:

    Thanks to the monotonicity property of arithmetic operators # , X#Y can be computed

    by considering the bounds of the intervals only. Let X,Y #

    X,X] , and

    Y] , the arithmetic operators are computed on intervals as follows:

    # Y.

    2.1.2. Interval extension of a real function

    For an arbitrary function over the real numbers, it is not possible in general
    to compute

    the exact enclosure of the range of the function [29]. The concept of interval
    extension

    has been introduced by Moore: the interval extension of a function is an interval
    function

    that computes outer approximations on the range of the function over a domain.
    Different

    interval extensions exist. Let f be a function over the real numbers defined over
    the

    variables x 1 , . , x n , the following interval extensions are frequently used:

    the natural interval extension of a real function f is defined by replacing each

    real operator by its interval counterpart. It is easy to see that

    contains

    the range of f , and is thus an interval extension.

    Example 1 (Natural extension of x 2

    The natural extension of x 2

    2.

    The natural extension of x 2

    the Taylor interval extension of a real function f , over the interval vector
    X,

    is defined by the natural extension of a first-order Taylor development of f [42]:

    f

    nat #f

    # . (2)

    The intuition why

    is an interval extension is given in a footnote. 2

    Example 2 (Taylor extension of x - x 2 ). Let

    The Taylor extension of

    The Taylor extension gives generally a better enclosure than the natural extension
    on

    small intervals. 3 Nevertheless, in general neither

    give the exact range of

    f . For example, let

    2] , we have:

    [-1,3] ,

    whereas the range of f over X= [0,

    is [3/4,

    3] .

    2 The Taylor interval extension comes from a direct application of the mean value
    theorem: Let f be a real

    function defined over [a,

    be continuous and with a continuous derivative over [a,

    be two

    points in [a,

    . Then, there exists # between x 1 and x 2 such that

    #)

    # is unknown, but what can be done is to replace it by an interval that contains
    it, and to evaluate the natural

    extension of the resulting expression. Thus we know that

    #( [a,

    As this is true

    for every x 1 and x 2 in [a,

    , we can replace x 1 by the midpoint of [a,

    by an interval that contains it.

    This leads to

    #( [a,

    #( [a,

    (2) is the generalization for vectors of the above result.

    3 The Taylor extension has a quadratic convergence, whereas the natural extension
    has a linear convergence;

    see for example [42].

    2.1.3. Solution function of a constraint

    To compute the projection #

    j,i( D) of the constraint C j on the variable x i , we need to

    introduce the concept of solution function that expresses the variable x i in
    terms of the

    other variables of the constraint. For example, for the constraint x z, the solution

    functions are: y, f

    Assume a solution function is known that expresses the variable x i in terms of
    the other

    variables of the constraint. Thus an approximation of the projection of the constraint
    over

    x i given a domain D can be computed thanks to any interval extension of this
    solution

    function. Thus we have a way to compute #

    D).

    Nevertheless, for complex constraints, there may not exist such an analytic solution

    for example, consider x

    log( The interest of numeric methods as

    presented in this paper is precisely for those constraints that cannot be solved
    algebraically.

    Three main approaches have been proposed:

    . The first one exploits the fact that analytic functions always exist when the
    variable to

    express in terms of the others appears only one time in the constraint. This approach

    simply considers that each occurrence of a variable is a different new variable.
    In

    the previous example this would give:

    log( x( That way, it is trivial to

    compute a solution function: it suffices to know the inverse of basic operators.
    In our

    example, we obtain f

    log( x( 2) ) and f

    An approximation of the projection of the constraint over x i can be computed
    by

    intersecting the natural interval extensions of the solution functions for all
    occurrences

    of x i in C j . For the last example, we could take #

    log( X)#exp -X .

    Projection functions obtained by this way will be called # nat in this paper.

    . The second idea uses the Taylor extension to transform the constraint into an
    interval

    linear constraint. The nonlinear equation

    nat #f

    m( X). Now consider that the derivatives are evaluated over a box D that

    contains X. D is considered as constant, and let c

    D). The equation becomes:

    nat #f

    #( D)

    This is an interval linear equation in X, which does not contain multiple occurrences.

    The solution functions could be extracted easily. But, instead of computing the
    solution

    functions of the constraint without taking into account the other constraints,
    we may

    prefer to group together several linear equations in a squared system. Solving
    the

    squared interval linear system allows much more precise approximations of projections

    to be computed. (See the following section.) Projection functions obtained by
    this way

    are called # Tay . For example, consider the constraint x

    log( by using the

    Taylor form on the box D, we obtain the following interval linear equation

    log( c)

    that is:

    log( c) - c/D. The unique solution function of this 1-

    dimensional linear equation is straightforward: X =-B/A.

    . A third approach [6] does not use any analytical solution function. Instead,
    it

    transforms the constraint C

    1, . , k. The mono-variable constraint C j,l on variable x

    is obtained by substituting

    their intervals for the other variables. The projection # j,j l

    is computed thanks to C j,l .

    The smallest zero of C j,l in the interval under consideration is a lower bound
    for the

    projection of C j over x j . And the greatest zero of C j,l is an upper bound
    for that

    projection. Hence, an interval with those two zeros as bounds gives an approximation

    of the projection. Projection functions computed in that way are called # box
    .

    In [6], the two extremal zeros of C j,l are found by a mono-variable version of
    the

    interval Newton method. 4

    Another problem is that the inverse of a nonmonotonic function is not a function
    over the

    intervals. For example the range of the inverse of the function

    for an interval

    Y is the union of

    Y ). It is possible to extend interval arithmetic

    in order to handle unions of intervals. A few systems have taken this approach
    [26,44].

    Nevertheless, this approach may lead to a highly increasing number of intervals.
    The

    two other approaches more commonly used consist of computing the smallest interval

    encompassing a union of

    or to split the problem in several sub-problems in which only intervals appear.

    2.2. Filtering algorithm as fixed point algorithms

    A filtering algorithm can generally be seen as a fixed point algorithm. In the
    following,

    an abstraction of filtering algorithms will be used: the sequence {D k } of domains
    generated

    by the iterative application of an operator Op :

    -#

    I( R) n (see Fig. 1).

    The operator Op of a filtering algorithm generally satisfies the following three
    properties


    Op( D) #D (contractance).

    . Op is conservative; that is, it cannot remove solutions.

    . D #

    #Op( D) (monotonicity).

    Under those conditions, the limit of the sequence {D k }, which corresponds to
    the greatest

    fixed point of the operator Op, exists and is called a closure. We denote it by

    #Op( D).

    A fixed point for Op may be characterized by a property lc-consistency, called
    a local

    consistency, and alternatively

    #Op( D) will be denoted by #

    lc( D). The algorithm achieving

    filtering by lc-consistency is denoted lc-filtering. A CSP is said to be lc-satisfiable
    if lc-

    filtering of this CSP does not produce an empty domain.

    4 The general (multi-variable) interval Newton method is briefly presented in
    Section 2.3.

    Fig. 1. Filtering algorithms as fixed point algorithms.

    Consistencies used in numeric CSPs solvers can be categorized in two main classes:

    arc-consistency-like consistencies and strong consistencies.

    2.3. Arc-consistency-like consistencies

    Most of the numeric CSP systems (e.g., BNR-prolog [40], Interlog [13,16], CLP(BNR)

    [5], PrologIV [15], UniCalc [3], Ilog Solver [27] and Numerica [46] compute an

    approximation of arc-consistency [36] which will be named 2B-consistency in this
    paper. 5

    2B-consistency states a local property on a constraint and on the bounds of the
    domains of

    its variables (B of 2B-consistency stands for bound). Roughly speaking, a constraint
    C j is

    2B-consistent if for any variable x i in

    the bounds D i and D i have a support in the

    domains of all other variables of C j (w.r.t. the approximation given by # ).
    2B-consistency

    can be defined in our notation as:

    2B-consistent if and only if

    A filtering algorithm that achieves 2B-consistency can be derived from Fig. 1
    by

    instantiating Op as in Operator 1. Note the operator Op 2B applies on the same
    vector D all

    the #

    j,i( D) operators.

    Operator 1 (2B-consistency filtering operator).

    Op

    j,1( D), . , #

    Fig. 2 shows how projection functions are used by a 2B-consistency filtering algorithm

    to reduce the domains of the variables.

    Depending on the projection functions used, we obtain different 2B-filtering algorithms


    Op nat The operator Op nat will denote Op 2B with # nat . It abstracts the filtering
    algorithm

    presented in [5,17,32]. There are two main differences between our abstraction

    and the implementations.

    (1) In classic implementations, projection functions are applied sequentially

    and not all on the same domain. In the abstraction (and in our non-classic

    5 We have a lot of freedom to choose #

    j,i( D), so the definition of 2B-consistency here abstracts both 2B-

    consistency in [32] and box-consistency in [6].

    Fig. 2. 2B-filtering on the constraint system {x 2

    implementations) they are applied on the same domain. This has the drawback

    of increasing the upper bound of the complexity, but has the advantage of

    generating much more "regular" sequences of domains. (See Section 3.2.)

    (2) Implementations always applied an AC3-like optimization [36]. It consists
    of

    applying at each iteration only those projection functions that may reduce a

    domain: only the projection functions that have in their parameters a variable

    whose domain has changed are applied. For the sake of simplicity, AC3-like

    optimization does not appear explicitly in this algorithm schema.

    Op box This operator denotes Op 2B that uses # box . It abstracts the filtering
    algorithm

    presented in [6,45]. Differences with our abstraction are the same as above.

    Op Tay This operator denotes Op 2B that uses # Tay . It abstracts the interval
    Newton

    method [2,37]. The interval Newton method controls in a precise way the order
    in

    which projection functions are computed. It is used for solving squared nonlinear

    equation systems such as

    0}. The

    interval Newton method replaces the solving of the nonlinear squared system by

    the solving of a sequence of interval linear squared systems. Each linear system

    is obtained by evaluating the interval Jacobi matrix over the current domains,

    and by considering the first-order Taylor approximation of the nonlinear system.

    The resulting interval linear system is typically solved by the interval Gauss-Seidel

    method. The Gauss-Seidel method associates each constraint C i with the

    variable x i (after a possible renaming of variables), and loops while applying
    only

    the projection functions # i,i .

    To summarize, the main differences with our abstraction are that, in an

    implementation, the partial derivatives are recomputed periodically and not at

    each step, and that the Gauss-Seidel method does not apply all the projection

    functions. A more realistic implementation of the Interval Newton method would

    correspond to Operator 2 as follows. 6

    Operator 2 (Interval Newton operator).

    Op

    A i,i

    endfor

    Note also that, in general, the Gauss-Seidel method does not converge towards

    the solution of the interval linear system, but it has good convergence properties

    for diagonally-dominant matrices. So, in practice, before solving the linear

    system, a preconditioning step is achieved that transforms the Jacobi matrix

    into a diagonally dominant matrix. Preconditioning consists of multiplying the

    interval linear equation A # by a matrix M , giving the new linear system

    . The matrix M is typically the inverse

    of the midpoint matrix of A.

    A nice property of the interval Newton operator is that in some cases, it is

    able to prove the existence of a solution. When Op

    Tay( D) is a strict subset of

    D, Brouwer''s fixed-point theorem applies and states existence and unicity of
    a

    solution in D (cf. [38]).

    2.4. Strong consistencies

    The idea of constraint satisfaction is to tackle difficult problems by solving
    easy-to-

    solve sub-problems: the constraints taken individually. It is often worth to have
    a more

    global view, which generally leads to a better enclosure of the domains. This
    is why strong

    consistencies have been proposed for solving CSP [21,22]. Their adaptation to
    numeric

    CSPs is summarized in this section. Interval analysis methods such as Op Tay extensively

    use another kind of global view: the preconditioning of the Jacobi matrix. Nevertheless,

    the need for strong consistencies, although less crucial with interval analysis
    methods,

    may appear for very hard problems such as [43].

    Strong consistencies have first been introduced over discrete CSPs (e.g., path-

    consistency, k-consistency [21]

    )-consistency [22]), and then over numeric CSPs

    6 The for-loop corresponds to only one iteration of the Gauss-Seidel method and
    not to the complete solving

    of the interval linear system, which in practice is not useful [24].

    (3B-consistency [32] and kB-consistency [33]). kB-consistency is the adaptation

    consistency over numeric CSP. Filtering

    k)-consistency is done by removing from

    each domain values that can not be extended to k variables. kB-consistency ensures
    that

    when a variable is instantiated to one of its two bounds, then the CSP is |k -1|B-satisfiable.

    we refer to Operator 1. More generally, as given in Definition 2,

    consistency ensures that when a variable is forced to be close to one of its two
    bounds

    (more precisely, at a distance less than w), then the CSP is |k -

    1|B( w)-satisfiable. For

    simplest presentation,

    w)-consistency refers to 2B-consistency.

    (kB( w)-consistency). We say that a CSP #X , D,C# is

    w)-consistent if

    and only if:

    #( D, i, w) is |k -

    1|B( w)-satisfiable, and

    #( D, i, w) is |k -

    1|B( w)-satisfiable,

    where

    #( D, i, w) (respectively

    #( D, i, w)) denotes #X , D # , C# where D # is the same

    domain as D except that D i is replaced by D

    (respectively D i is replaced

    by D

    The direct filtering operator Op

    kB( w) underlying the

    w)-consistency uses a kind of

    proof by contradiction: the algorithm tries to increase the lower bound D i by
    proving that

    the closure by |k -

    1|B( w)-consistency of #D 1 , . , [

    +w] , . , D n # is not empty

    and tries to decrease the upper bound in a symmetric way.

    3B-consistency filtering algorithms, used for example in Interlog, Ilog Solver
    or

    Numerica, can be derived from Fig. 1 by instantiating operator Op to Op 3B as
    defined

    in Operator 3.

    Operator 3

    w)-consistency filtering operator: Op

    the

    filtering operator Op

    kB( w)( P), with k # 3, is defined as follows:

    Op

    being computed as follows:

    do

    while D #

    do

    while D #

    do

    endfor

    Fig. 3 shows how

    w)-filtering uses 2B-filtering.

    Fig. 3.

    3B( w)-filtering on the constraint system {x 2

    Implementations using this schema may be optimized considerably, but we do not

    need to go into details here. The reader is referred to [32] for the initial algorithm,

    and to [12] which studies the complexity of an unpublished implementation we used

    for years (see for example [30]) and that is more efficient than the algorithm
    published

    in [32].

    The algorithm that achieves box-consistency is closely related to 3B-consistency.

    Indeed, box-consistency can be seen as a kind of one-way 3B-consistency limited
    to one

    constraint. The reader can found in [14] a theoretical comparison between box-consistency

    and 3B-consistency.

    3. Acceleration of filtering techniques

    The question of choosing the best filtering algorithm for a given constraint system
    is an

    open problem. Some preliminary answers may come from the observation that the
    above

    fixed point algorithms suffer from two main drawbacks, which are tightly related:

    . the existence of "slow convergences", leading to unacceptable response times
    for

    certain constraint systems;

    . "early quiescence" [17], i.e., the algorithm stops before reaching a good approximation

    of the set of possible values.

    The focus of this paper is on the first drawback. Its acuteness varies according
    to the Op

    operator:

    Op nat Due to its local view of constraints, Op nat often suffers from early quiescence,
    but

    its simplicity makes it the most efficient operator to compute, and many problems

    are best solved by this filtering operator (e.g., Moreaux problem [46]). At first

    sight, one could think that slow convergence phenomena do not occur very often

    with Op nat . It is true that early quiescence of Op nat is far more frequent
    than

    slow convergence. However, Op nat is typically interleaved with a tree search

    (or is called from inside another higher-order filtering algorithm). During this

    interleaved process, slow convergence phenomena may occur and considerably

    increase the required computing time.

    Op box The comments above remain true for Op box , although it may take more time
    to be

    computed and may perform some stronger pruning in some cases.

    Op Tay The interval Newton operator, on the one hand, may have a very efficient
    behavior.

    It may have an asymptotically quadratic convergence when it is used near the

    solution. In our experience, quadratic convergence is essential to compute precise

    roots of nonlinear systems of equations.

    On the other hand, far from the solution, the Jacobi matrix has a great chance

    of being singular, which typically leads to the "early quiescence" problem. Hence

    Op Tay does not have really slow convergence problems, but it needs expensive

    computation since the preconditioning of the Jacobi matrix needs to compute an

    inversion of its midpoint matrix. On some problems like Moreaux problem [46]

    with huge dimension n # 320, Op Tay is very expensive, whereas by Op nat the

    solution is found quickly.

    Op

    w)-consistency filtering algorithms may perform a very strong pruning,

    making the tree-search almost useless for many problems.

    For example, we have tried

    w)-filtering over the transistor problem [41,43].

    It finds the unique solution, without search, in the same cpu time as the

    filtering search method used in [41]. We have also tried

    w)-filtering over

    the benchmarks listed in [45]. They are all solved without search (only p choice

    points are made when the system has Unfortunately,

    most of the time slow convergence phenomena occur during a

    w)-filtering.

    The different filtering algorithms are thus complementary and the more robust
    way to

    solve a problem is probably to use several of them together. In the fixed point
    schema of

    Fig. 1, the operator Op would be the result of the composition of some operators
    above. In

    the remainder of this section, we focus on the problem of slow convergence that
    occurs in

    Op nat and Op

    kB( w) .

    The observation of many slow convergences of those algorithms led us to notice

    that some kinds of "regularity" often exist in a slow convergence phenomenon.
    Our

    intuition was that such regularities in the behavior of algorithms could be exploited
    to

    optimize their convergence. As seen in Section 2, the filtering algorithms are
    abstracted

    through a sequence of interval vectors. Accelerating a filtering algorithm thus
    consists in

    transforming that sequence into another sequence, hoping it converges faster.
    In numerical

    analysis, engineers use such transformation methods. Unfortunately, they cannot
    be sure of

    the reliability of their results. But this does not change the essence of usual
    floating-point

    computation: unreliability is everywhere! For filtering techniques, the completeness
    of the

    results must be guaranteed, or in other words, no solution of the CSP can be lost.
    Thus the

    question of reliability becomes crucial. This leads us to define a reliable transformation.

    Definition 3 (Reliable transformation). Let {S n } be a sequence that is complete
    for a set

    of solutions Sol: #k,Sol # S k . Let A be a transformation and let {T n

    A( {S n }). A is a

    reliable transformation for {S n } w.r.t. Sol if and only if

    The practical interest of a reliable transformation is directly related to its
    ability to

    accelerate the greatest number of sequences. Acceleration of a sequence is traditionally

    defined in terms of improvement of the convergence order of the sequence. Convergence

    order characterizes the asymptotic behavior of the sequences. (See Section 3.2
    for a formal

    definition of the convergence order.) In addition to convergence order, some practical

    criteria may be of importance, like, for example, the time needed to compute a
    term of

    a sequence.

    To build a reliable transformation that accelerates the original sequence, we
    will exploit

    some regularities in the sequence. When we detect a regularity in the filtering
    sequence, the

    general idea is to assume that this regularity will continue to appear in the
    following part of

    the sequence. The regularities that we are looking for are those which allow computations

    to be saved. A first kind of regularity that we may want to exploit is cyclicity.
    Section 3.1

    summarizes a previous work based on that idea. Another kind of regularity, that
    can be

    caught by extrapolation methods, is then developed in Section 3.2.

    3.1. A previous work: dynamic cycle simplification

    This subsection summarizes a previous work [34,35], built on the idea that there
    is

    a strong connection between the existence of cyclic phenomena and slow convergence.

    More precisely, slow convergence phenomena move very often into cyclic phenomena
    after

    a transient period (a kind of stabilization step). The main goal is to dynamically
    identify

    cyclic phenomena while executing a filtering algorithm and then to simplify them
    in order

    to improve performance.

    This subsection is more especially dedicated to the acceleration of Op nat and
    Op box

    algorithms,

    . a direct use of those accelerated algorithms also leads to significant gain
    in speed

    for

    w)-filtering algorithms since they typically require numerous computations of

    . this approach could be generalized to identify cyclic phenomena in

    w)-filtering

    algorithms.

    Considering the application of Op 2B over D i , there may exist several projection

    functions that perform a reduction of the domain of a given variable. As Op 2B
    performs an

    intersection, and since domains are intervals, there may be 0, 1 or 2 projection
    functions

    of interest for each variable. (One that gives the greatest lower bound, one that
    gives the

    lowest upper bound.) Call these projection functions relevant for D i , and denote
    by R i the

    set of those relevant projection functions for D i .

    Thus we have

    2B( D i ); that is, if we know in advance all the R i , we

    can compute #

    2B( D) more efficiently by applying only relevant projection functions. This

    is precisely the case in a cyclic phenomenon.

    We will say we have a cyclic phenomenon of period p when:

    #i <N, R i+p =R i ,

    where N is a "big" number.

    Now, consider R i and R i+1 . If a projection function is in R i+1 , this is due
    to the

    reduction of domains performed by some projection functions in R i . We will say
    that

    f # R j depends on g # R i , where j > i , denoted by g # f if and only if g #=
    f and g

    computes the projection over a variable that belongs to

    The dependency graph is the graph whose vertices are pairs #f, i#, where f # R
    i ,

    and arcs are dependency links. (See Fig. 4(a).) If we assume that we are in a
    cyclic

    phenomenon, then the graph is cyclic. (See Fig. 4(b) where -

    denotes all the steps i

    such that i mod According to this assumption, two types of simplification can
    be

    performed:

    . Avoid the application of non-relevant projection functions.

    . Postpone some projection functions: a vertex #f, i# which does not have any
    successor

    in the dynamic dependency graph corresponds to a projection function that can
    be

    postponed. Such a vertex can be removed from the dynamic dependency graph.

    Applying this principle recursively will remove all non-cyclic paths from the
    graph.

    For instance, in graph (b) of Fig. 4, all white arrows will be pruned.

    When a vertex is removed, the corresponding projection function is pushed onto
    a

    stack. (The removing order must be preserved.) Then, it suffices to iterate on
    the

    simplified cycle until a fixed point is reached, and, when the fixed point has
    been

    reached, to evaluate the stacked projection functions.

    The transformation that corresponds to the above two simplifications together
    is clearly

    a reliable transformation. It does not change the convergence order, but is in
    general

    an accelerating transformation. In [34] first experimental results are reported,
    gains in

    Fig. 4. Dynamic dependency graphs.

    efficiency range from 6 to 20 times faster for 2B-filtering and

    w)-filtering. More

    complete experiments have been performed in [23], but, for the sake of simplicity,
    only the

    first simplification (applying only relevant projection functions) has been tried.
    Different

    combinations of several improvements of 2B-filtering are tested. For all problems,
    the

    fastest combination uses cycle simplification. Ratio in CPU time varies from 1
    to 20

    compared with the same combination without cycle simplification.

    3.2. Extrapolation

    The previous section aims at exploiting cyclicity in the way projection functions
    are

    applied. The gain is in the computation of each term of {D n }, but the speed
    of convergence

    of D n is unchanged. Now we address how to accelerate the convergence of {D n
    }.

    {D n } is a sequence of intervals. Numerical analysis provides different mathematical

    tools for accelerating the convergence of sequences of real numbers. Extrapolation
    methods

    are especially interesting for our purposes, but {D n } is a sequence of interval
    vectors and

    there does not exist any extrapolation method to accelerate interval sequences.
    Nevertheless

    an interval can be seen as two reals and D can be seen as a 2-column matrix of
    reals. The

    first column is the lower bounds, and the second the upper bounds. Thus we can
    apply

    the existing extrapolation methods. The field of extrapolation methods, for real
    number

    sequences, is first summarized; for a deeper overview see [10]. Then we will show
    how to

    use extrapolation methods for accelerating filtering algorithms.

    3.2.1. Extrapolation methods

    Let {S n }

    .) be a sequence of real numbers. A sequence {S n } converges if

    and only if it has a limit S: lim n# S We say that the numeric sequence {S n }
    has

    the order r # 1 if there exist two finite constants A and B such that 7

    A# lim

    # B.

    A quadratic sequence is a sequence which has the order 2. We say that a sequence
    is linear

    if

    lim

    The convergence order enables us to know exactly the convergence speed of the
    sequence.

    For example [8], for linear sequences with we obtain a significant number

    every 2500 iterations. Whereas, for sequences of order 1.01, the number of significant

    numbers doubles every 70 iterations. These examples show the interest of using
    sequences

    of order r > 1.

    Accelerating the convergence of a sequence {S n } amounts of applying a transformation

    A which produces a new sequence {T n }: {T n }

    7 For more details, see [10].

    As given in [10], in order to present some practical interest, the new sequence
    {T n } must

    exhibit, at least for some particular classes of convergent sequences {S n },
    the following

    properties:

    (1) {T n } converges to the same limit as {S n }: lim n# T

    (2) {T n } converges faster than {S n }: lim

    These properties do not hold for all converging sequences. Particularly, a universal

    transformation A accelerating all converging sequences cannot exist [18]. Thus
    any

    transformation can accelerate a limited class of sequences. This leads us to a
    so-called

    kernel 8 of the transformation which is the set of convergent

    A well-known transformation is the iterated # 2 process from Aitken [1]

    which gives a sequence {T n } of nth term

    The kernel of # 2 process is the set of the converging sequences which have the
    form

    Aitken''s transformation has a nice property [10]: it

    transforms sequences with linear convergence into sequences with quadratic convergence.

    We can apply the transformation several times, leading to a new transformation.
    For

    example, we can apply # 2 twice, giving #

    2( {S n })). Many acceleration transformations

    (G-algorithm, #-algorithm, # -algorithm, overholt-process, .) are multiple application

    of transformations. See [11] and [9] for attempts to build a unifying framework
    of

    transformation. Scalar transformations have been generalized to the vectoral and
    matrix

    cases.

    Two kinds of optimization for filtering algorithms are now given. The first one
    makes

    a direct use of extrapolation methods and leads to a transformation which is not
    reliable.

    The second one is a reliable transformation.

    3.2.2. Applying extrapolation directly

    Let {D n } be a sequence generated by a filtering algorithm. We can naively apply

    extrapolation method directly on the main sequence {D n }. The experimental results
    given

    in the rest of the paper are for scalar extrapolations, which consider each element
    of the

    matrix-each bound of a domain- independently of the others. For example, the scalar

    process uses for each bound of domain the last three different values to extrapolate
    a

    value.

    8 The definition of the kernel given here considers only converging sequences.

    Accelerating directly the convergence of {D n } can dramatically boost the convergence,

    as illustrated in the following problem:

    1000] , y # [0,

    1000] , z # [0,

    #] .

    The following table shows the domain of the variable t in the 278th, 279th, 280th
    and 281st

    iterations of 3B-filtering (after a few seconds on a Sun Sparc 5). The precision
    obtained is

    it t

    278 [3.14133342842583 . , 3.14159265358979 .

    .] By applying Aitken''s process on the domains of the iterations 278, 279 and
    280,

    we obtain the domain below. The precision of this extrapolated domain is 10 -14
    . Such

    precision has not been obtained after 5 hours of the 3B-filtering algorithm without

    extrapolation.

    [3.14159265358977 . , 3.14159265358979 .

    .] Let''s take another example:


    Table


    1 shows the domain of the variables x and y in the first, second and third iterations

    of

    5B( w)-filtering. The precision obtained is about 10 -6 .


    Table

    5B( w)-filtering on the problem above

    Iteration domains for x and y

    By applying the # 2 process on the domain of the iterations 1, 2 and 3, we obtain
    the

    domains below. The precision of this extrapolated domain is 10 -19 . Such a precision
    has

    not been obtained after many hours of the

    w)-filtering algorithm without extrapolation.

    [-8.93e-19,-8.85e-19] This result is not surprising since we have the following
    proposition:

    Theorem 1 (Convergence property of Aitken''s process [7]). If we apply # 2 on
    some

    which converges to S and if we have:

    lim

    then the sequence #

    converges to S, and more quickly

    Note that, in the solution provided by Aitken''s process, we have a valid result
    for x ,

    but not for y . This example shows that extrapolation methods can lose solutions.
    The

    extrapolated sequence may or may not converge to the same limit as the initial
    sequence.

    This anomaly can be explained by the kernel of the transformation: when the initial

    sequence belongs to the kernel, then we are sure that the extrapolated sequence
    converges

    to the same limit. Furthermore, intuition suggests that, if the initial sequence
    is "close" to

    the kernel then there are good hopes to get the same limit. However, it may be
    the case that

    the limits are quite different. This is cumbersome for the filtering algorithms
    which must

    ensure that no solution is lost.

    We propose below a reliable transformation that makes use of extrapolation.

    3.2.3. Reliable transformation by extrapolation

    The reliable transformation presented in this section is related to the domain
    sequences

    generated by

    w)-filtering algorithms. For the sake of simplicity, we will only deal with

    3B( w)-filtering, but generalisation is straightforward.

    This transformation is reliable thanks to the proof-by-contradiction mechanism
    used in

    3B( w)-algorithm: it tries to prove-with a 2B-filtering-that no solution exists
    in a subpart

    of a domain. If such a proof is found, then the subpart is removed from the domain,
    else

    the subpart is not removed. The point is that we may waste a lot of time trying
    to find

    a proof that does not exist. If we could predict with good probability that such
    a proof

    does not exist, we could save time in not trying to find it. Extrapolation methods
    can do

    the job. The idea is simply that if an extrapolated sequence converges to a 2B-satisfiable

    CSP (which can be quickly known), then it is probably a good idea not to try to
    prove

    the 2B-unsatisfiability. This can be done by defining a new consistency, called

    consistency, that is built upon the existence of a predicate

    2B-predict( D) that predicts

    2B-satisfiability. (P2B stands for 2B based on Prediction.)

    Definition 4 (P2B-consistency). A CSP #X , D,C# is P2B-consistent if and only
    if it is

    2B-consistent or 2B-predict(D) is true.

    Op

    Op

    Fig. 5. P 2B-consistency filtering schema.

    may use extrapolation methods, for example the # 2 process. Thus,

    the prediction 2B-predict(D) may be wrong, but from the Proposition 1 we know
    that

    a filtering algorithm by P2B-consistency cannot lose any solutions.

    Proposition 1. #

    D).

    The proof is straightforward from the definition.

    A filtering algorithm that achieves P2B-consistency can be a fixed point algorithm

    where Op is as defined in Fig. 5. The main difference with Op 2B is, before testing
    for 2B-

    satisfiability, to try in the function 2B-predict, to predict 2B-satisfiability
    by extrapolation

    methods. Following that idea, the algorithm schema for

    Fast-3B( w)-consistency can be

    modified, as given in Operator 4. (We may obtain in the same way the algorithm
    schema

    for

    Fast-kB( w)-consistency. It needs a P -kB operator that applies an extrapolator
    over the

    domains generated by the kB operator.)

    Operator 4. Let the filtering operator Op

    Fast-3B( w) is defined as follows:

    Op

    being computed as follows:

    do

    while D #

    do

    while D #

    do

    endfor

    The following proposition means that this algorithm schema allows acceleration

    methods to be applied while keeping the completeness property of filtering algorithms.

    We thus have a reliable transformation.

    Proposition 2 (Completeness).

    Fast-kB( w)-algorithm does not lose any solutions.

    The proof is built on the fact that a domain is reduced only when we have a proof-

    by |k -

    1|B( w)-satisfiability and without extrapolation-that no solution exists for the

    removed part.

    Table

    w)-filtering results over some benchmarks

    Problem

    nbr-#( Fast-kB)

    nbr-#( kB)

    time( Fast-kB)

    time( kB)

    brown

    caprasse 0.46 0.60

    chemistry 0.61 0.69

    neuro-100 0.53 0.66

    The counterpart of this result is that improvements in efficiency of

    w)-filtering

    compared with

    w)-filtering may be less satisfactory than improvement provided

    by direct use of extrapolation. Another counterpart is that the greatest fixed
    point of

    Op

    Fast-kB( w) is generally greater than the greatest fixed point of Op

    kB( w) .

    In practice the overhead in time has always been negligible and the improvement
    in

    efficiency may vary from 1 to 10. Table 2 compares Fast-3B-filtering with 3B-filtering

    over some problems taken from [23,46]. It gives the ratios in time (

    time( Fast-kB)

    time( kB)

    ) and in

    number of projection function calls (

    nbr-#( Fast-kB)

    nbr-#( kB) ) for the two algorithms.

    4. Related works

    Two methods commonly used for solving numeric CSPs can be seen as reliable

    transformations: preconditioning and adding redundant constraints.

    4.1. Preconditioning in the interval Newton operator

    Numeric CSPs allow general numeric problems to be expressed, without any limitation

    on the form of the constraints. In numerical analysis, many specific cases of
    numeric CSPs

    have been studied. The preconditioning of squared linear systems of equations
    is among

    the most interesting results for its practical importance.

    We say that a linear system of equation

    is near 1.

    In practice, a well conditioned system is better solved than an ill conditioned
    one.

    Preconditioning methods transform the system to a new system A #

    has the same solution but is better conditioned than the first system. Solving
    A #

    better precision and more reliable computations than solving the original system.
    A classic

    preconditioning method consists of multiplying the two sides of the system by
    an

    approximate inverse M of A. Thus we have A # =MA and b # =Mb.

    In interval analysis, the interest of preconditioning is not reliability, which
    already exists

    in interval methods, but precision and convergence. As already presented in Section
    2.3,

    preconditioning is a key component of the interval Newton method. Experimental
    results

    (for example see [28,45]) show the effectiveness of preconditioning for solving
    squared

    nonlinear systems of equations. Many theoretical results can be found in [2,28,38,39].

    4.2. Redundant constraints

    A classic reliable transformation is the adding of some redundant constraints
    to the

    original constraint system. This approach is very often used for discrete CSPs
    to accelerate

    the algorithms. It is not the case for interval analysis methods over numeric
    CSPs, since

    they exploit the fact that the system is square. For artificial intelligence methods
    over

    numeric CSPs, Benhamou and Granvilliers [4] propose to add some redundant polynomial

    constraints that are automatically generated by a depth-bounded Groebner bases
    algorithm.

    5. Conclusion and perspectives

    Our aim in this paper was to accelerate existing filtering algorithms. That led
    us

    to the concept of reliable transformation over the filtering algorithms, which
    preserves

    completeness of the filtering algorithms. Two kinds of reliable transformation
    have been

    proposed. They exploit some regularities in the behavior of the filtering algorithms.
    The

    first one is based on cyclic phenomena in the propagation queue. The second one
    is an

    extrapolation method: it tries to find a numeric equation satisfied by the propagation
    queue

    and then solves it.

    A first perspective is to detect other kinds of regularities and to exploit them.

    A reliable transformation always has some intrinsic limitations; for example,
    logarithmic

    sequences cannot be accelerated by extrapolation methods. However, in that case,
    the

    cyclic phenomena simplification may improve the running time. Thus, combining
    different

    reliable transformations to try to accumulate the advantages of each transformation
    may

    be of high interest. Finally, a direction of research that could be fruitful comes
    from the

    remark that algorithms are designed with efficiency and simplicity in mind only.
    Regularity

    is never considered as an issue. Perhaps it is time to consider it as an issue,
    and to try to

    make more regular the existing algorithms in order to exploit their new regularities.


    Acknowledgements


    We would like to thank Christian Bliek, Michel Rueher and Patrick Taillibert for
    their

    constructive comments on an early draft of the paper, and Kathleen Callaway for
    a lot

    of English corrections. This work has been partly supported by the Ecole des Mines
    de

    Nantes.




    --R


    On Bernoulli''s numerical solution of algebraic equations

    Introduction to Interval Computations


    Automatic generation of numerical redundancies for non-linear constraint solving

    Applying interval arithmetic to real

    CLP(intervals) revisited

    Algorithmes d''Acc-l-ration de la Convergence: -tude Num-riques


    Derivation of extrapolation algorithms based on error estimates

    Extrapolation Methods

    A general extrapolation procedure revisited

    Improved bounds on the complexity of kB-consistency

    Constraint logic programming on numeric intervals

    A note on partial consistencies over continuous domains solving techniques


    Interlog 1.0: Guide d''utilisation

    Constraint propagation with interval labels


    Arc consistency for continuous variables

    Local consistency for ternary numeric constraints


    A sufficient condition for backtrack-bounded search

    Consistances locales et transformations symboliques de contraintes d''intervalles

    Global Optimization Using Interval Analysis

    Consistency techniques for continuous constraints

    Constraint reasoning based on interval arithmetic: The tolerance propagation approach

    ILOG Solver 4.0

    Continuous Problems

    Computational Complexity and Feasibility of Data Processing and Interval Computations


    Acceleration methods for numeric CSPs

    Consistency techniques for numeric CSPs


    Dynamic optimization of interval narrowing algorithms

    Boosting the interval narrowing algorithm

    Consistency in networks of relations

    Interval Analysis

    Interval Methods for Systems of Equations

    A simple derivation of the Hansen-Bliek-Rohn-Ning-Kearfott enclosure for linear
    interval equations

    Extending prolog with constraint arithmetic on real intervals

    A constraints satisfaction approach to a circuit design problem

    Computer Methods for the Range of Functions

    Experiments using interval analysis for solving a circuit design problem

    Hierarchical arc consistency applied to numeric constraint processing in logic
    programming

    Solving polynomial systems using branch and prune approach

    Modeling Language for Global Optimization

    --TR

    A sufficient condition for backtrack-bounded search

    Constraint propagation with interval labels

    Constraint reasoning based on interval arithmetic

    Arc-consistency for continuous variables

    CLP(intervals) revisited

    A derivation of extrapolation algorithms based on error estimates

    Solving Polynomial Systems Using a Branch and Prune Approach

    Acceleration methods of numeric CSPc

    Synthesizing constraint expressions

    A Constraint Satisfaction Approach to a Circuit Design Problem

    A Note on Partial Consistencies over Continuous Domains


    --CTR

    Yahia Lebbah , Claude Michel , Michel Rueher, Using constraint techniques for
    a safe and fast implementation of optimality-based reduction, Proceedings of the
    2007 ACM symposium on Applied computing, March 11-15, 2007, Seoul, Korea

    Yahia Lebbah , Claude Michel , Michel Rueher, A Rigorous Global Filtering Algorithm
    for Quadratic Constraints, Constraints, v.10 n.1, p.47-65, January   2005'
  sentences:
  - text classification
  - Markov Chain Monte Carlo
  - peak power
- source_sentence: '--T

    A framework for combining analysis and verification.

    --A

    We present a general framework for combining program verification and program
    analysis. This framework enhances program analysis because it takes advantage
    of user assertions, and it enhances program verification because assertions can
    be refined using automatic program analysis. Both enhancements in general produce
    a better way of reasoning about programs than using verification techniques alone
    or analysis techniques alone. More importantly, the combination is better than
    simply running the verification and analysis in isolation and then combining the
    results at the last step. In other words, our framework explores synergistic interaction
    between verification and analysis.

    In this paper, we start with a representation of a program, user assertions, and
    a given analyzer for the program. The framework we describe induces an algorithm
    which exploits the assertions and the analyzer to produce a generally more accurate
    analysis. Further, it has some important features:


    it is flexible: any number of assertions can be used anywhere;

    it is open: it can employ an arbitrary analyzer;

    it is modular: we reason with conditional correctness of assertions;

    it is incremental: it can be tuned for the accuracy/efficiency tradeoff.

    --B

    Introduction

    abstraction [9] is a successful method of abstract

    interpretation. The abstract domain, constructed from

    a given finite set of predicates over program variables, is

    intuitive and easily, though not necessarily efficiently, computable

    within a traversal method of the program''s control

    flow structure. More recently, the success of predicate abstraction

    has been enhanced by a process of discovery of the

    [copyright notice will appear here]

    abstract domain, generally known as CEGAR or "counterex-

    ample guided abstraction refinement".

    One major disadvantage of predicate abstraction, as is

    true for many other realizations of abstract interpretation, is

    that in principle, the process of abstraction is performed at

    every step of the traversal phase. Indeed, the survey section

    in [19] states that "abstractions are often defined over small

    parts of the program", and that "abstractions for model-checking

    often over-approximate".

    While it is generally easy to optimize somewhat by performing

    abstraction here and there (eg: several consecutive

    asignments may be compressed and abstraction performed

    according one composite assignment, such as in the BLAST

    system [11]), there has not been a systematic way of doing

    this. Another disadvantage, arising partly because the abstract

    description is limited to a fixed number of variables,

    is that this ad-hoc method would not be compositional. For

    example, [2] required an elaborate extension of predicate abstraction

    which essentially considers a second set of variables

    (called "symbolic constants"), in order to describe the

    behaviour of a function, in the language of predicate abstrac-

    tion. This provided a limited form of compositionality.

    In this paper, we present a general proof method of program

    reasoning based on predicate abstraction in which the

    process of abstraction is intermittent, that is, approximation

    is performed only at selected program points, if at all. There

    is no restriction of when abstraction is performed, even

    though termination issues will usually restrict the choices.

    The key advantages are that (a) the abstract domain required

    to ensure convergence of the algorithm can be minimized,

    and (b) the cost of performing abstractions, now being inter-

    mittent, is reduced.

    For example, to reason that executing x :=

    one needs to know that

    the final assignment. Also, consider proving for the

    following program snippet:

    #1# while (i < n) do

    A textbook Hoare-style loop invariant for the loop is

    2i. Having this proposition in predicate abstraction would,

    however, not suffice; one in fact needs to know that

    holds in between the two increments to c. Thus in general, a

    proper loop invariant is useful only if we could propagate its

    information exactly.

    A main challenge to having exact propagation is that reasoning

    will be required about the strongest-postcondition operator

    associated with an arbitrarily long program fragment.

    This essentially means dealing with constraints over an unbounded

    number of variables describing the states between

    the start and end of the program fragment at hand. The advantages

    in terms of efficiency, however, are significant: less

    predicates needed in the abstract domain, and also, less frequent

    execution of the abstraction operation.

    An important additional feature of our proof method is

    that it is compositional. We represent a proof as a Hoare-style

    triple which, for a given program fragment, relates the

    input values of the variables to the output values. This is represented

    as a formula, and in general, such a formula must

    contain auxiliary variables in addition to the program vari-

    ables. This is because it is generally impossible to represent

    the projection of a formula using a predefined set of vari-

    ables, or equivalently, it is not possible to perform quantifier

    elimination. Consequently, in order to have unrestricted

    composition of such proofs, it is (again) necessary to deal

    with an unbounded number of variables.

    The latter part of this paper will introduce the technology

    of Constraint Logic Programming (CLP) as a basis for efficient

    implementation. Briefly, the advantages of CLP are (a)

    handles terms containing anonynous primary variables and

    constraints on these variables and also an arbitrary number

    of auxiliary variables, (b) efficiently represents the projection

    of such terms, and (c) handles backtracking.

    In summary, we show that our method provides a flexible

    combination of abstraction and Hoare-style reasoning with

    predicate transformers and loop-invariants, that is composi-

    tional, and that its practical implementation is feasible.

    1.1 Further Related Work

    An important category of tools that use program verification

    technology have been developed within the framework of

    the Java Modelling Language (JML) project. JML allows

    to specify a Java method''s pre- and post-conditions, and

    class invariants. Examples of such program verification tools

    are: Jack [4], ESC/Java2 [7], and Krakatoa [15]. All these

    tools employ weakest precondition/strongest postcondition

    calculi to generate proof obligations which reflect whether

    the given post-conditions and class invariants hold at the

    end of a method, whenever the corresponding pre-conditions

    are valid at the procedure''s entry point. The resulting proof

    obligations are subsequently discharged by theorem provers

    such as Simplify [7], Coq [3], PVS [17], or HOL light [10].

    While these systems perform exact propagation, they depend

    on user-provided loop invariants, as opposed to an abstract

    domain.

    Recently there have emerged systems based on abstract

    interpretation, and in particular, on predicate abstraction.

    Some examples are BLAST [11], SLAM [1], MAGIC [5],

    and Murphi- [8], amongst others. While abstract interpretation

    is central, these systems employ a further technique of

    automatically determining the abstract domain needed for

    a given assertion. This technique is called CEGAR, see eg.

    the description in [6], based on an iteratively refining the abstract

    domain from the failure of the abstract domain in the

    previous iteration. These systems do not perform exact propagation

    in a systematic way.

    2. Preliminaries

    Apart from a program counter k, whose values are program

    points, let there be n system variables -

    domains respectively. In this paper, we shall

    use just two example domains, that of integers, and that of

    integer arrays. We assume the number of system variables is

    larger than the number of variables required by any program

    fragment or procedure.

    DEFINITION 1 (States and Transitions). A system state (or

    simply state) is of the form (k,d 1 , - , d n ) where pc is a

    program point and d i # D i , 1 # i # n, are values for the

    system variables. A transition is a pair of states.

    In what follows, we define a language of first-order for-

    mulas. Let V denote an infinite set of variables, each of

    which has a type in D 1 , - , D n , let S denote a set of func-

    tors, and P denote a set of constraint symbols. A term

    is either a constant (0-ary functor) in S or of the form

    and each t i is a term,

    primitive constraint is of the form f(t 1 , -

    where f is a m-ary constraint symbol and each t i is a term,

    A constraint is constructed from primitive constraints

    using logical connectives in the usual manner. Where Y is a

    constraint, we write Y( -

    X) to denote that Y possibly refers to

    variables in -

    X , and we write -

    X) to denote the existential

    closure of Y( -

    away from -

    X .

    An substitution is a mapping which simultaneously replaces

    each variable in a term or constraint into some ex-

    pression. Where e is a term or constraint, we write eq to

    denote the result of applying q to e. A special kind of substitution

    is a renaming, which maps each variable in a given

    sequence, say -

    into the corresponding variable in another

    given sequence, say -

    Y . We write [ -

    Y ] to denote such a

    mapping.

    Another special kind of substitution is a grounding of an

    this maps each variable in the expression into a

    value in its respective domain. Thus the effect of applying a

    grounding substitution q to an expression e is to obtain a set

    eq of its ground instances under q. We write to denote

    the set of all possible groundings of e.

    3. Constraint Transition Systems

    A key concept is that a program fragment p operates on a

    sequence of anonymous variables, each corresponding to a

    system variable at various points in the computation of p.

    In particular, we consider two sequences -

    n of anonymous variables to denote the system

    values before executing p and at the "target" point(s) of p,

    respectively. Typically, but not always, the target point is the

    terminal point of p. Our proof obligation or assertion is then

    of the form

    where Y and Y 1 are constraints over the said variables, and

    possibly including new variables. Like the Hoare-triple, this

    states that if p is executed in a state satisfying Y, then all

    states at the target points (if any) satisfy Y 1 . Note that, unlike

    the Hoare-triple, p may be nonterminating and Y 1 may refer

    to the states of a point that is reached infinitely often. We

    will formalize all this below.

    For example, let there be just one system variable x, let

    p be <0> x let the target point be <1>.

    meaning p is the successor

    function on x. Similarly, if p were the (perpetual) program

    <0> while (true) x

    if <1> were the target point, then {true}p{x

    that is, any state (1,x) at point <1> satisfies #z(x

    This shows, amongst other things, that the parity of x always

    remains unchanged.

    Our proof method accomodates concurrent programs of a

    fixed number of processes. Where we have n processes, we

    shall use as a program point, a sequence of n program points

    so that the i th program point is one which comes from the i th

    process,

    We next represent the program fragment p as a transition

    system which can be executed symbolically. The following

    definition serves two main purposes. First, it is a high

    level representation of the operational semantics of p, and in

    fact, it represents the exact trace semantics of p. Second, it

    is an executable specification against which an assertion can

    be checked.

    DEFINITION 2 (Constraint Transition System). A constraint

    transition of p is a formula

    where k and k 1 are variables over program points, each of

    x and -

    x 1 is a sequence of variables representing a system

    even(5,

    even(5,


    Figure


    1. Even counts

    Process 1:

    while (true) do

    Process 2:

    while (true) do


    Figure


    2. Two Process Bakery


    Figure


    3. CTS of Two Process Bakery

    state, and Y is a constraint over -

    x and -

    possibly some

    additional auxiliary variables.

    A constraint transition system (CTS) of p is a finite set of

    constraint transitions of p.

    Consider for example the program in Section 1; call it

    even.


    Figure


    1 contains a CTS for even.

    Consider another example: the Bakery algorithm with

    two processes in Figure 2. A CTS for this program, call it

    bak, is given in Figure 3. Note that we use the first and

    second arguments of the term bub to denote the program

    points of the first and second process respectively.

    Clearly the variables in a constraint transition may be re-named

    freely because their scope is local to the transition.

    We thus say that a constraint transition is a variant of another

    if one is identical to the other when a renaming subsitution is

    performed. Further, we may simplify a constraint transition

    by renaming any one of its variables x by an expression y

    provided that all groundings of the constraint tran-

    sition. For example, we may simply state the last constraint

    transition in Figure 3 into

    by replacing the variable y 1 in the original transition with 0.

    The above formulation of program transitions is familiar

    in the literature for the purpose of defining a set of transi-

    tions. What is new, however, is how we use a CTS to define

    a symbolic transition sequences, and thereon, the notion of a

    proof.

    By similarity with logic programming, we use the term

    goal to deonote a literal that can be subjected to an unfolding

    process in order to infer a logical consequence.

    DEFINITION 3 (Goal). A query or goal of a CTS is of the

    where k is a program point, Y is a sequence of variables

    over system states, and Y is a constraint over some or all

    of the variables -

    x, and possibly some additional variables.

    The variables -

    x are called the primary variables of this goal,

    while any additional variable in Y is called an auxiliary

    variable of the goal.

    Thus a goal is just like the conclusion of a constraint

    transition. We say the goal is a start goal if k is the start

    program point. Similarly, a goal is a target goal is k is the

    target program point. Running a start goal is tantamount to

    asking the question: which values of -

    x which satisfy -

    will lead to a goal at the target point(s)? The idea is that we

    successively reduce one goal to another until the resulting

    goal is at a target point, and then inspect the results.

    Next we define it means for a CTS to prove a goal.

    DEFINITION 4 (Proof Step, Sequence and Tree). Let there

    be a CTS for p, and let

    x),Y be a goal for this. A

    proof step from G is obtained via a variant p(k, -

    of a transition in the CTS in which all the variables are fresh.

    The result is a goal G # of the form

    y, Y 1

    providing the constraints Y, -

    y, Y 1 are satisfiable.

    A proof sequence is a finite or infinite sequence of proof

    steps. A proof tree is defined from proof sequences in the

    obvious way. A tree is complete if every internal node representing

    a goal G is succeeded by nodes representing every

    goal obtainable in a proof step from G .


    Figure


    5. Proof Tree of Even Counts Program

    Consider again the CTS in Figure 1, and we wish to prove

    There is in fact only one proof sequence

    from the start goal

    or equivalently, even(0, i, 1,0). This proof sequence is shown

    in


    Figure


    5, and note that the counter,represented in the last

    goal by the variable c 2 , has the value 2.

    Hereafter we shall consider that a program and its CTS

    are synonymous. Given a program p, we say that

    x are the

    start variables of p to denote that -

    x are the variables in the

    first constraint transition of p.

    DEFINITION 5 (Assertion). Let p be a program with start

    variables -

    x, and let Y be a constraint. Let -

    x t denotes a sequence

    of variables representing system states not appearing

    in p or Y. (These represent the target values of the system

    An assertion for p wrt to -

    x t is of the form

    In particular, when k is the start program point, we may

    abberviate the assertion using the notation:

    It is intuitively clear what it means for an assertion to

    hold. That is, execution from every instance q of p(k, -

    cannot lead to a target state where the property Y 1 ( -

    violated.

    In the example above, we could prove the assertion

    it is understood that the final

    variable c t corresponds to the start variable c. Note that the

    last occurrence of n in the assertion means that we are comparing

    c t with the initial and not final value of n (though in

    this example, the two are in fact the same).

    We now state the essential property of proof sequences:

    THEOREM 1. Let a CTS for p have the start point k and target

    x and -

    x 1 each be sequences of variables


    Figure


    4. Proof Tree of 2-Process Bakery Algorithm (Partially Shown)

    over system states. The assertion {Y( -

    holds if for any goal of the form p(k t , -

    appearing

    in a proof sequence from the goal p(k, -

    x), the following

    holds:

    The above theorem provides the basis of a search method,

    and what remains is to provide a means to ensure termination

    of the search. Toward this end, we next define the concepts

    of subsumption and coinduction and which allow the

    (successful) termination of proof sequences. However, these

    are generally insufficient. In the next section, we present our

    version of abstraction whose purpose is to transform a proof

    sequence so that it is applicable to the termination criteria of

    subsumption and coinduction.

    3.1 Subsumption

    Consider a finite and complete proof tree from some start

    goal. A goal G in the tree is subsumed if there is a different

    path in the tree containing a goal G # such that [[G

    The principle here is simply memoization: one may terminate

    the expansion of a proof sequence while constructing

    a proof tree when encountering a subsumed goal.

    3.2 Coinduction

    The principle here is that, within one proof sequence, the

    proof obligation associated with the final goal may assume

    that the proof obligation of an ancestor goal has already

    been met. This can be formally explained as a principle of

    coinduction (see eg: Appendix B of [16]). Importantly, this

    simple form of coinduction does not require a base case nor

    a well-founded ordering.

    We shall simply demonstrate this principle by example.

    Suppose we had the transition p(0,x) # p(0,x #

    and we wished to prove the assertion p(0,x) |= even(x t

    -x),

    that is, the difference between x and its final value is even.

    Consider the derivation step:

    We may use, in the latter goal, the fact that the earlier goal

    satisfies the assertion. That is, we may reduce the obligaton

    of the latter goal to

    It is now a simple matter of inferring whether this formula

    holds.

    In general practice, the application of coinduction testing

    is largely equivalent to testing if one goal is simply an instance

    of another.

    3.3 Compostionality

    It is intuitively clear that since our proof obligation relates

    the start and final values of a program, or equivalently, it

    obeys the "assume-guarantee" paradigm [18], that the proof

    method is sequentially compositional. We thus omit a formal

    treatment of CTS where programs directly invoke other

    programs. Instead, in the next section, we provide a simple

    example.

    4. Abstraction

    In the literature on predicate abstraction, the abstract description

    is a specialized data structure (monomial?), and

    the abstraction operation serves to propagate such a structure

    though a small program fragment (a contiguous group

    of assignments, or a test), and then obtaining another struc-

    ture. The strength of this method is in the simplicity of using

    a finite set of predicates over the fixed number of program

    variables as a basis for the abstract description.

    We choose to follow this method. However, our abstract

    description shall not be a distinguished data structure. In

    our abstract description of a goal is itself a goal.

    DEFINITION 6 (Abstraction). An abstraction A is applied

    to a goal. It is specified by a program point pc(A), a sequence

    of variables var(A) corresponding to a subset of

    the system variables, and finally, a finite set of constraints

    pred(A) over var(A), called the "predicates" of A .

    Let A be an abstraction and G be a goal p(k, -

    x),Y where

    x denote the subsequence of -

    x corresponding

    to the system variables var(A). Let -

    x denote the remaining

    subsequence of -

    x. Without losing generality, we assume

    that -

    x 1 is an initial subsequence of -

    x, that is, -

    x.

    Then the abstraction A(G) of G by A is:

    Z is a sequence of fresh variables renaming -

    Y 2 is the finite set of constraints

    For example, let A be such that

    and That is, the first variable

    is to be abstracted into a negative or a nonnegative value.

    Let G be p(0, [x 1 , x 2 , x 3 ]), x 1. Then the abstraction

    A(G) is a goal of the form p(0, [Z,x 2 , x 3 ]), x

    which can be simplified into p(0, [Z,x 2 , x 3 ]), x

    Note that the orginal goal had ground instances

    p(0, [1, 1,n]) for all n, while the abstracted goal has the instances

    p(0, [m,1,n]) for all n and all nonnegative m. Note

    that the second variable x 2 has not been abstracted even

    though it is tightly constrained to the first variable x 1 . Note

    further that the value of x 3 is unchanged, that is, the abstraction

    would allow any constraint on x 3 , had the example goal

    contained such a constraint, to be propagated.

    LEMMA 1. Let A be an abstraction and G a goal.

    The critical point is that the abstraction of a goal has the

    same format as the goal itself. Thus an abstract goal has the

    expressive power of a regular goal, while yet containing a

    notion of abstraction that is sufficient to produce a finite-state

    effect. Once again, this is facilitated by the ability to

    reason about an unbounded number of variables.

    Consider the "Bubble" program and its CTS in Figures

    7 and 8, which is a simplified skeleton of the bubble sort

    algorithm (without arrays). Consider the subprogram corresponding

    to start point 2 and whose target point is 6, that is,

    we are considering the inner loop. Further suppose that the

    following assertion had already been proven:

    bub(2, i, j, t, n) |=

    that is, the subprogram increments t by n - preserving

    both i and n, but not j. Consider now a proof sequence

    for the goal bub(0, i, j, t, n),n # 0, where we want to

    prove that at program point #8#,

    n)/2. The proof

    tree is depicted in Figure 6. The proof shows a combination

    of the use of intermittent abstraction and compositional

    proof:

    . At point (A), we abstract the goal bub(2,

    using the predicates i <

    i)/2. Call this abstraction A . Here the set

    of variables is hence both the variables

    correspond respectively to system variables

    #1# while (i < n-1) do

    #3# while (j < n-i-1) do


    Figure


    7. Program "Bubble"

    bub(0, i, j, t, n) # bub(1,

    bub(1, i, j, t, n) # bub(8, i, j, t, n), i # n-1.

    bub(1, i, j, t, n) # bub(2, i, j, t, n), i < n-1.

    bub(2, i, j, t, n) # bub(3,

    bub(3, i, j, t, n) # bub(6, i, j, t, n), j # n- i -1.

    bub(3, i, j, t, n) # bub(4, i, j, t, n), j < n- i -1.

    bub(4, i, j, t, n) # bub(5,

    bub(5, i, j, t, n) # bub(6, i, j, t, n), j # n- i -1.

    bub(5, i, j, t, n) # bub(4, i, j, t, n), j < n- i -1.

    bub(6, i, j, t, n) # bub(7,

    bub(7, i, j, t, n) # bub(8, i, j, t, n), i # n-1.

    bub(7, i, j, t, n) # bub(2, i, j, t, n), i < n-1.


    Figure


    8. CTS of "Bubble"

    and t are renamed to fresh variables i 2 , and t 2 . Mean-

    while, the variables j and n retain their original values.

    . After performing the above abstraction, we reuse the

    proof of the inner loop above. Here we immediately move

    to program point #6#, incrementing t with

    updating j to an unknown value. However, i and n retain

    their original values at #2#.

    . As the result of the intermittent abstraction above, we

    obtain a coinductive proof at (B).

    5. The Whole Algorithm

    We now summarize our proof method for an assertion

    Suppose the start program point of p is k and the start

    variables of p are -

    x. Then consider the start goal p(k, -

    and incrementally build a search tree. For each path in the

    tree constructed so far leading to a goal G :

    . if G is either subsumed or is coinductive, then consider

    this path closed, ie: not to be expanded further;

    . if G is a goal on which an abstraction A is defined,

    replace G by A(G);

    . if G is a target goal, and if the constraints on the primary

    variables -

    x 1 in G do not satisfy Yq, where q renames the

    target variables in Y into -

    Coinduction using (A)

    Satisfies

    Satisfies

    Proof composition

    Intermittent abstraction

    bub(0, i, j, t, n),n # 0


    Figure


    6. Compositional Proof

    THEOREM 2. If the above algorithm, applied to the assertion

    then the asertion holds.

    6. CLP Technology

    It is almost immediate that CTS is implementable in CLP.

    Given a CTS for p, we build a CLP program in the following

    way: (a) for every transition of the form (k, -

    we use the CLP rule the clause p(k, -

    ing that Y is in the constraint domain of the CLP implementation

    at hand); (b) for every terminal program point k, we

    use the CLP fact p(k, , . , , ), where the number of anonymous

    variables is the same as the number of variables in -

    x.

    We see later that the key implementation challenge for

    a CLP system is the incremental satisfiability problem.

    Roughly stated, this is the problem of successively determining

    that a monotonically increasing sequence of constraints

    (interpreted as a conjunction) is satisfiable.

    6.1 Exact Propagation is "CLP-Hard"

    Here we informally demonstrate that the incremental satisfiability

    problem is reducible to the problem of analyzing

    a straight line path in a program. We will consider here

    constraints in the form of linear diophantine equations, i.e.,

    multivariate polynomials over the integers. Without loss of

    generality, we assume each constraint is written in the form

    is an integer.

    Suppose we already have a sequence of constraints

    corresponding path in the program''s control

    flow.

    Suppose we add a new constraint Y

    Then, if one of these variables, say Y , is new, we add the

    assignment y := x - z where y is a new variable created to

    correspond to y. The remaining variables x and z are each

    either new, or are the corresponding variable to x and Z. If

    however all of x,Y and Z are not new, then add the statement

    if are the program

    variables corresponding to x, y, z respectively. Hereafter we

    pursue the then branch of this if statement.

    Similarly, suppose the new constraint were of the form

    y correspond to Y , and y is possibly new. Again,

    if x is new, we simply add the assignment x := n # y where

    x is newly created to correspond to x. Otherwise, add the

    statement if . to the path, and again, we

    now pursue the then branch of this if statement.

    Clearly an exact analysis of the path we have constructed

    leading to a successful traversal required, incrementally, the

    solving of the constraint sequence Y 0 , - , Y n .

    6.2 Key Elements of CLP Systems

    A CLP system attempts to find answers to an initial goal G

    by searching for valid substitutions of its variables. Depth-first

    search is used. Each path in the search tree in fact

    involves the solving of an incremental satisfiability problem.

    Along the way, unsatisfiability of the constraints at hand

    would entail backtracking.

    The key issue in CLP is the incremental satisfiability

    problem, as mentioned above. A standard approach is as

    follows. Given that the sequence of constraints Y 0 , . , Y i

    has been determined to be satisfiable, represent this fact

    in a solved form. Essentially, this means that when a new

    constraint Y i+1 is encountered, the solved form is efficiently

    combinable with Y i+1 in order to determine the satisfiability

    of the new conjunction of constraints.

    This method essentially requires a representation of the

    projection of a set of constraints onto certain variables. Con-

    sider, for example, the set x

    Assuming that the new constraint would

    only involve the variable x i (and this happens vastly of-

    ten), we desire a representation of x projection

    problem is well studied in CLP systems [13]. In the system

    CLP(R ) [14] for example, various adaptations of the

    Fourier-Motzkin algorithm were implemented for projection

    in Herbrand and linear arithmetic constraints.

    We finally mention another important optimization in

    CLP: tail recursion. This technique uses the same space in

    the procedure call stack for recursive calls. Amongst other

    bebefits, this technique allows for a potentially unbounded

    number of recursive calls. Tail recursion is particurly relevant

    in our context because the recursive calls arising from

    the CTS of programs are often tail-recursive.

    The CLP(R ) system that we use to implement our prototype

    has been engineered to handle constraints and auxiliary

    variables efficiently using the above techniques.

    7. Experiments

    We performed two kinds of experiments: the first set performs

    exact propagation. We then look at comparable abstract

    runs in the BLAST system, and (exact) runs in the

    system. These results are presented in Section

    7.1.

    In the second set of experiments, presented in Section 7.2,

    we compare intermittent predicate abstraction with normal

    predicate abstraction, again against the BLAST system.

    We used a Pentium 4 2.8 GHz system with 512 MBRAM

    running GNU/Linux 2.4.22.

    7.1 Exact Runs

    We start with an experiment which shows that concrete execution

    can potentially be less costly than abstract execution,

    we simply compare the timing of concrete execution using

    our CLP-based implementation and a predicate abstraction-based

    model checker. We also run a simple looping program,

    whose C code is shown in Figure 9. We first have BLAST

    generate all the 100 predicates it requires. We then re-run

    BLAST by providing these predicates. BLAST took 22.06

    seconds to explore the state space. On the same machine, and

    without any abstraction, our verification engine took only

    seconds. For comparison, SPIN model checker [12] executes

    the same program written in PROMELA in less than

    seconds.

    Now consider the synthetic program consisting of an initial

    assignment x := 0 followed by 1000 increments to x,

    with the objective of proving that 1000 at the end. Consider

    also another version where the program contains only

    a single loop which increments is counter x 1000 times. We

    input these two programs to our program verifier, without

    using abstraction, and to ESC/Java 2 as well. The results are

    shown in Table 1. For both our verifier and ESC/Java 2 we

    run both with x initialized to 0 and not initialized, hopefully

    forcing symbolic execution.


    Table


    1 shows that our verifier runs faster for the non-looping

    version. However, there is a noticeable slowdown in

    int main()

    { int i=0, j, x=0;

    while (i<7) {

    while (j<7) { x++; j++; }

    { ERROR: }


    Figure


    9. Program with Loop

    Time (in Seconds)

    CLP with Tabling ESC/Java 2

    Non-Looping 2.45 2.47 9.89 9.68

    Looping 22.05 21.95 1.00 1.00


    Table


    1. Timing Comparison with ESC/Java 2

    the looping version for our implementation. This is caused

    by the fact that in our implementation of coinductive tabling,

    subsumption check is done based on similarity of program

    point. Therefore, when a program point inside a loop is visited

    for the i-th time, there are i - 1 subsumption checks to

    be performed. This results in a total of about 500,000 subsumption

    checks for the looping program. In comparison,

    the non-looping version requires only 1,000 subsumption

    checks. However, our implementation is currently at a prototype

    stage and our tabling mechanism is not implemented in

    the most efficient way. For the looping version, ESC/Java 2

    employs a weakest precondition propagation calculus; since

    the program is very small, with a straightforward invariant

    (just the loop condition), the computation is very fast. Table

    also shows that there is almost no difference between

    having x initialized to 0 or not.

    7.2 Experiments Using Abstraction

    Next we show an example that demonstrates that the intermittent

    approach requires fewer predicates. Let us consider

    a second looping program written in C, shown in Figure 10.

    The program''s postcondition can be proven by providing an

    invariant x=i # i<50 exactly before the first statement of

    the loop body of the outer while loop. We specify as an abstraction

    domain the following predicates x=i, i<50, and respectively

    their negations x#=i, i#50 for that program point

    to our verifier. Using this information, the proof process finishes

    in less than 0.01 seconds. If we do not provide an abstract

    domain, the verification process finishes in 20.34 sec-

    onds. Here intermittent predicate abstraction requires fewer

    predicates: We also run the same program with BLAST and

    provide the predicates x=i and i<50 (BLAST would auto-

    int main()

    { int i=0, j, x=0;

    while (i<50) {

    while (j<10) { x++; j++; }

    while (x>i) { x-; }

    { ERROR: }


    Figure


    10. Second Program with Loop

    while (true) do


    Figure


    11. Bakery Algorithm Peudocode for Process i

    matically also consider their negations). BLAST finishes in

    1.33 seconds, and in addition, it also produces 23 other predicates

    through refinements. Running it again with all these

    predicates given, BLAST finishes in 0.28 seconds.

    Further, we also tried our proof method on a version

    of bakery mutual exclusion algorithm. We need abstraction

    since the bakery algorithm is an infinite-state program. The

    pseudocode for process i is shown in Figure 11. Here we

    would like to verify mutual exclusion, that is, no two processes

    are in the critical section (program point #2#) at the

    same time. Our version of bakery algorithm is a concurrent

    program with asynchronous composition of processes. It can

    be encoded as a sequential program with nondeterministic

    choice.

    We first encode the algorithm for 2, 3 and 4 processes

    in BLAST. Nondeterministic choice can be implemented in

    BLAST using the special variable BLAST NONDET which

    has a nondeterministic value. We show the BLAST code for

    2-process bakery algorithm in Figure 12. Within the code,

    we use program point annotations #pc# which should be considered

    as comments. Notice that the program points of the

    concurrent version are encoded using the integer variables

    pc1 and pc2.

    Further, we translate the BLAST sequential versions of

    the algorithm for 2, 3 and 4 processes into the CTS version

    shown in Figure 13 and also its corresponding CLP code, as

    an input to our prototype verifier.

    In our experiments, we attempt to verify mutual exclusion

    property, that is, no two processes can be in the critical section

    at the same time. Here we perform 3 sets of runs, each

    consisting of runs with 2, 3 and 4 processes. In all 3 sets,

    we use a basic set of predicates: x i =0, x i #0, pc i =0, pc i =1,

    int main()

    {

    #0# int pc1=0, pc2=0;

    unsigned int x1=0, x2=0;

    #1# while (1) {

    #2# if (pc1==1 || pc2==1) {

    #3# /* Abstraction point 1 */; }

    #4# if (pc1==0 || pc2==0) {

    #5# /* Abstraction point 2 */;

    else if (pc1==2 && pc2==2) {#6# ERROR: }

    #7# if ( BLAST NONDET) {

    #8# if (pc1==0) {

    else if (pc1==1 &&

    {

    else if (pc1==2) {

    } else {

    #12# if (pc2==0) {

    else if (pc2==1 &&

    {

    else if (pc2==2) {


    Figure


    12. Sequential 2-Process Bakery

    and N the number of processes,

    and also their negations.

    . Set 1: Use of predicate abstraction at every state with

    full predicate set. Here using our prototype system we

    perform ordinary predicate abstraction where we abstract

    at every state encountered during search. Here, in addition

    to the basic predicates, we also require the predicates

    shown in Table 2 (and their negations) to avoid producing

    spurious counterexample.

    . Set 2: Intermittent predicate abstraction with full

    predicate set. In the second set we use intermittent abstraction

    technique on our prototype implementation. We

    abstract only when for some process i, pc i =1 holds. In


    Figure


    12, this abstraction point is marked with the comment

    "Abstraction point 1." The set of predicates that we

    use here is the same as the predicates that we use in the

    first experiment above, otherwise spurious counterexample

    will be generated.

    . Set 3: Intermittent predicate abstraction with reduced

    predicate set. For the third set we also use intermittent

    abstraction technique on our tabled CLP system.

    Here we only abstract whenever there are N-1 processes

    at program point 0, which in the 2-process sequential version

    is the condition where either pc1=0 or pc2=0. This is

    bak(3, pc1, pc2,x1,x2) # bak(4, pc1, pc2,x1,x2).

    bak(5, pc1, pc2,x1,x2) # bak(7, pc1, pc2,x1,x2).

    2.

    bak(6, pc1, pc2,x1,x2) # bak(7, pc1, pc2,x1,x2).

    bak(7, pc1, pc2,x1,x2) # bak(8, pc1, pc2,x1,x2).

    bak(7, pc1, pc2,x1,x2) # bak(12, pc1, pc2,x1,x2).

    2.

    2.

    2.

    2.


    Figure


    13. CTS of Sequential 2-Process Bakery

    Bakery-2 x1<x2

    Bakery-3 x1<x2, x1<x3, x2<x3

    Bakery-4 x1<x2, x1<x3, x1<x4

    x2<x3, x2<x4, x3<x4


    Table


    2. Additional Predicates

    Time (in Seconds)

    CLP with Tabling BLAST

    Bakery-3 0.83 0.14 0.09 2.38

    Bakery-4 131.11 8.85 5.02 78.47


    Table


    3. Timing Comparison with BLAST

    marked with the comment "Astraction point 2" in Figure

    12.

    For each bakery algorithm with N processes, here we

    only need the basic predicates and their negations without

    the additional predicates shown in Table 2.

    We have also compared our results with BLAST. We supplied

    the same set of predicates that we used in the first and

    second sets to BLAST. Again, in BLAST we do not have to

    specify their negations explicitly. Interestingly, for 4-process

    bakery algortihm BLAST requires even more predicates to

    avoid refinement, which are x1=x3+1, x2=x3+1, x1=x2+1,

    1#x4, x1#x3, x2#x3 and x1#x2. We suspect this is due to

    the fact that precision in predicate abstraction-based state-space

    traversal depends on the power of the underlying theorem

    prover. We have BLAST generate these additional predicates

    it needs in a pre-run, and then run BLAST using them.

    Here since we do not run BLAST with refinement, lazy abstraction

    technique [11] has no effect, and BLAST uses all

    the supplied predicates to represent any abstract state.

    For these problems, using our intermittent abstraction

    with CLP tabling is also markedly faster than both full predicate

    abstraction with CLP and BLAST. We show our timing

    results in Table 3 (smallest recorded time of 3 runs each).

    The first set and BLAST both run with abstraction at

    every visited state. The timing difference between them and

    second and third sets shows that performing abstraction at

    every visited state is expensive. The third set shows further

    gain over the second when we understand some intricacies

    of the system.


    Acknowledgement


    We thank Ranjit Jhala for his help with BLAST.




    --R


    Automatic predicate abstraction of C programs.

    Polymorphic predicate abstraction.

    The Coq proof assistant reference manual-version v6

    Java applet correctness: A developer-oriented approach

    Modular verification of software components in C.


    ESC/Java2: Uniting ESC/Java and JML.

    Experience with predicate abstraction.

    Construction of abstract state graphs of infinite systems with PVS.

    HOL light: A tutorial introduction.

    Lazy ab- straction

    The SPIN Model Checker: Primer and Reference Manual.

    Projecting CLP(R

    The CLP(R

    The KRAKATOA tool for certification of JAVA/JAVACARD programs annotated in JML.

    Principles of Program Analysis.

    PVS: A prototype verification system.

    A proof technique for rely/guarantee properties.

    Model checking programs.

    --TR

    Constraint logic programming

    Methods and logics for proving programs

    based program analysis

    Modern compiler implementation in ML

    Simplification by Cooperating Decision Procedures

    Abstract interpretation

    Systematic design of program analysis frameworks

    A flexible approach to interprocedural data flow analysis and programs with recursive
    data structures

    On Proving Safety Properties by Integrating Static Analysis, Theorem Proving and
    Abstraction

    Program Analysis Using Mixed Term and Set Constraints

    Experiments in Theorem Proving and Model Checking for Protocol Verification

    Powerful Techniques for the Automatic Generation of Invariants

    Verifying Invariants Using theorem Proving

    PVS'
  sentences:
  - program analysis
  - constraint programming
  - RIS
pipeline_tag: sentence-similarity
library_name: sentence-transformers
metrics:
- pearson_cosine
- spearman_cosine
model-index:
- name: SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2
  results:
  - task:
      type: semantic-similarity
      name: Semantic Similarity
    dataset:
      name: Unknown
      type: unknown
    metrics:
    - type: pearson_cosine
      value: 0.7234989235627849
      name: Pearson Cosine
    - type: spearman_cosine
      value: 0.7302163776824807
      name: Spearman Cosine
---

# SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2). It maps sentences & paragraphs to a 384-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, text classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) <!-- at revision fa97f6e7cb1a59073dff9e6b13e2715cf7475ac9 -->
- **Maximum Sequence Length:** 256 tokens
- **Output Dimensionality:** 384 dimensions
- **Similarity Function:** Cosine Similarity
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/UKPLab/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'max_seq_length': 256, 'do_lower_case': False}) with Transformer model: BertModel 
  (1): Pooling({'word_embedding_dimension': 384, 'pooling_mode_cls_token': False, 'pooling_mode_mean_tokens': True, 'pooling_mode_max_tokens': False, 'pooling_mode_mean_sqrt_len_tokens': False, 'pooling_mode_weightedmean_tokens': False, 'pooling_mode_lasttoken': False, 'include_prompt': True})
  (2): Normalize()
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```

Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    '--T\nA framework for combining analysis and verification.\n--A\nWe present a general framework for combining program verification and program analysis. This framework enhances program analysis because it takes advantage of user assertions, and it enhances program verification because assertions can be refined using automatic program analysis. Both enhancements in general produce a better way of reasoning about programs than using verification techniques alone or analysis techniques alone. More importantly, the combination is better than simply running the verification and analysis in isolation and then combining the results at the last step. In other words, our framework explores synergistic interaction between verification and analysis.\nIn this paper, we start with a representation of a program, user assertions, and a given analyzer for the program. The framework we describe induces an algorithm which exploits the assertions and the analyzer to produce a generally more accurate analysis. Further, it has some important features:\n\nit is flexible: any number of assertions can be used anywhere;\nit is open: it can employ an arbitrary analyzer;\nit is modular: we reason with conditional correctness of assertions;\nit is incremental: it can be tuned for the accuracy/efficiency tradeoff.\n--B\nIntroduction\nabstraction [9] is a successful method of abstract\ninterpretation. The abstract domain, constructed from\na given finite set of predicates over program variables, is\nintuitive and easily, though not necessarily efficiently, computable\nwithin a traversal method of the program\'s control\nflow structure. More recently, the success of predicate abstraction\nhas been enhanced by a process of discovery of the\n[copyright notice will appear here]\nabstract domain, generally known as CEGAR or "counterex-\nample guided abstraction refinement".\nOne major disadvantage of predicate abstraction, as is\ntrue for many other realizations of abstract interpretation, is\nthat in principle, the process of abstraction is performed at\nevery step of the traversal phase. Indeed, the survey section\nin [19] states that "abstractions are often defined over small\nparts of the program", and that "abstractions for model-checking\noften over-approximate".\nWhile it is generally easy to optimize somewhat by performing\nabstraction here and there (eg: several consecutive\nasignments may be compressed and abstraction performed\naccording one composite assignment, such as in the BLAST\nsystem [11]), there has not been a systematic way of doing\nthis. Another disadvantage, arising partly because the abstract\ndescription is limited to a fixed number of variables,\nis that this ad-hoc method would not be compositional. For\nexample, [2] required an elaborate extension of predicate abstraction\nwhich essentially considers a second set of variables\n(called "symbolic constants"), in order to describe the\nbehaviour of a function, in the language of predicate abstrac-\ntion. This provided a limited form of compositionality.\nIn this paper, we present a general proof method of program\nreasoning based on predicate abstraction in which the\nprocess of abstraction is intermittent, that is, approximation\nis performed only at selected program points, if at all. There\nis no restriction of when abstraction is performed, even\nthough termination issues will usually restrict the choices.\nThe key advantages are that (a) the abstract domain required\nto ensure convergence of the algorithm can be minimized,\nand (b) the cost of performing abstractions, now being inter-\nmittent, is reduced.\nFor example, to reason that executing x :=\none needs to know that\nthe final assignment. Also, consider proving for the\nfollowing program snippet:\n#1# while (i < n) do\nA textbook Hoare-style loop invariant for the loop is\n2i. Having this proposition in predicate abstraction would,\nhowever, not suffice; one in fact needs to know that\nholds in between the two increments to c. Thus in general, a\nproper loop invariant is useful only if we could propagate its\ninformation exactly.\nA main challenge to having exact propagation is that reasoning\nwill be required about the strongest-postcondition operator\nassociated with an arbitrarily long program fragment.\nThis essentially means dealing with constraints over an unbounded\nnumber of variables describing the states between\nthe start and end of the program fragment at hand. The advantages\nin terms of efficiency, however, are significant: less\npredicates needed in the abstract domain, and also, less frequent\nexecution of the abstraction operation.\nAn important additional feature of our proof method is\nthat it is compositional. We represent a proof as a Hoare-style\ntriple which, for a given program fragment, relates the\ninput values of the variables to the output values. This is represented\nas a formula, and in general, such a formula must\ncontain auxiliary variables in addition to the program vari-\nables. This is because it is generally impossible to represent\nthe projection of a formula using a predefined set of vari-\nables, or equivalently, it is not possible to perform quantifier\nelimination. Consequently, in order to have unrestricted\ncomposition of such proofs, it is (again) necessary to deal\nwith an unbounded number of variables.\nThe latter part of this paper will introduce the technology\nof Constraint Logic Programming (CLP) as a basis for efficient\nimplementation. Briefly, the advantages of CLP are (a)\nhandles terms containing anonynous primary variables and\nconstraints on these variables and also an arbitrary number\nof auxiliary variables, (b) efficiently represents the projection\nof such terms, and (c) handles backtracking.\nIn summary, we show that our method provides a flexible\ncombination of abstraction and Hoare-style reasoning with\npredicate transformers and loop-invariants, that is composi-\ntional, and that its practical implementation is feasible.\n1.1 Further Related Work\nAn important category of tools that use program verification\ntechnology have been developed within the framework of\nthe Java Modelling Language (JML) project. JML allows\nto specify a Java method\'s pre- and post-conditions, and\nclass invariants. Examples of such program verification tools\nare: Jack [4], ESC/Java2 [7], and Krakatoa [15]. All these\ntools employ weakest precondition/strongest postcondition\ncalculi to generate proof obligations which reflect whether\nthe given post-conditions and class invariants hold at the\nend of a method, whenever the corresponding pre-conditions\nare valid at the procedure\'s entry point. The resulting proof\nobligations are subsequently discharged by theorem provers\nsuch as Simplify [7], Coq [3], PVS [17], or HOL light [10].\nWhile these systems perform exact propagation, they depend\non user-provided loop invariants, as opposed to an abstract\ndomain.\nRecently there have emerged systems based on abstract\ninterpretation, and in particular, on predicate abstraction.\nSome examples are BLAST [11], SLAM [1], MAGIC [5],\nand Murphi- [8], amongst others. While abstract interpretation\nis central, these systems employ a further technique of\nautomatically determining the abstract domain needed for\na given assertion. This technique is called CEGAR, see eg.\nthe description in [6], based on an iteratively refining the abstract\ndomain from the failure of the abstract domain in the\nprevious iteration. These systems do not perform exact propagation\nin a systematic way.\n2. Preliminaries\nApart from a program counter k, whose values are program\npoints, let there be n system variables -\ndomains respectively. In this paper, we shall\nuse just two example domains, that of integers, and that of\ninteger arrays. We assume the number of system variables is\nlarger than the number of variables required by any program\nfragment or procedure.\nDEFINITION 1 (States and Transitions). A system state (or\nsimply state) is of the form (k,d 1 , - , d n ) where pc is a\nprogram point and d i # D i , 1 # i # n, are values for the\nsystem variables. A transition is a pair of states.\nIn what follows, we define a language of first-order for-\nmulas. Let V denote an infinite set of variables, each of\nwhich has a type in D 1 , - , D n , let S denote a set of func-\ntors, and P denote a set of constraint symbols. A term\nis either a constant (0-ary functor) in S or of the form\nand each t i is a term,\nprimitive constraint is of the form f(t 1 , -\nwhere f is a m-ary constraint symbol and each t i is a term,\nA constraint is constructed from primitive constraints\nusing logical connectives in the usual manner. Where Y is a\nconstraint, we write Y( -\nX) to denote that Y possibly refers to\nvariables in -\nX , and we write -\nX) to denote the existential\nclosure of Y( -\naway from -\nX .\nAn substitution is a mapping which simultaneously replaces\neach variable in a term or constraint into some ex-\npression. Where e is a term or constraint, we write eq to\ndenote the result of applying q to e. A special kind of substitution\nis a renaming, which maps each variable in a given\nsequence, say -\ninto the corresponding variable in another\ngiven sequence, say -\nY . We write [ -\nY ] to denote such a\nmapping.\nAnother special kind of substitution is a grounding of an\nthis maps each variable in the expression into a\nvalue in its respective domain. Thus the effect of applying a\ngrounding substitution q to an expression e is to obtain a set\neq of its ground instances under q. We write to denote\nthe set of all possible groundings of e.\n3. Constraint Transition Systems\nA key concept is that a program fragment p operates on a\nsequence of anonymous variables, each corresponding to a\nsystem variable at various points in the computation of p.\nIn particular, we consider two sequences -\nn of anonymous variables to denote the system\nvalues before executing p and at the "target" point(s) of p,\nrespectively. Typically, but not always, the target point is the\nterminal point of p. Our proof obligation or assertion is then\nof the form\nwhere Y and Y 1 are constraints over the said variables, and\npossibly including new variables. Like the Hoare-triple, this\nstates that if p is executed in a state satisfying Y, then all\nstates at the target points (if any) satisfy Y 1 . Note that, unlike\nthe Hoare-triple, p may be nonterminating and Y 1 may refer\nto the states of a point that is reached infinitely often. We\nwill formalize all this below.\nFor example, let there be just one system variable x, let\np be <0> x let the target point be <1>.\nmeaning p is the successor\nfunction on x. Similarly, if p were the (perpetual) program\n<0> while (true) x\nif <1> were the target point, then {true}p{x\nthat is, any state (1,x) at point <1> satisfies #z(x\nThis shows, amongst other things, that the parity of x always\nremains unchanged.\nOur proof method accomodates concurrent programs of a\nfixed number of processes. Where we have n processes, we\nshall use as a program point, a sequence of n program points\nso that the i th program point is one which comes from the i th\nprocess,\nWe next represent the program fragment p as a transition\nsystem which can be executed symbolically. The following\ndefinition serves two main purposes. First, it is a high\nlevel representation of the operational semantics of p, and in\nfact, it represents the exact trace semantics of p. Second, it\nis an executable specification against which an assertion can\nbe checked.\nDEFINITION 2 (Constraint Transition System). A constraint\ntransition of p is a formula\nwhere k and k 1 are variables over program points, each of\nx and -\nx 1 is a sequence of variables representing a system\neven(5,\neven(5,\n\nFigure\n\n1. Even counts\nProcess 1:\nwhile (true) do\nProcess 2:\nwhile (true) do\n\nFigure\n\n2. Two Process Bakery\n\nFigure\n\n3. CTS of Two Process Bakery\nstate, and Y is a constraint over -\nx and -\npossibly some\nadditional auxiliary variables.\nA constraint transition system (CTS) of p is a finite set of\nconstraint transitions of p.\nConsider for example the program in Section 1; call it\neven.\n\nFigure\n\n1 contains a CTS for even.\nConsider another example: the Bakery algorithm with\ntwo processes in Figure 2. A CTS for this program, call it\nbak, is given in Figure 3. Note that we use the first and\nsecond arguments of the term bub to denote the program\npoints of the first and second process respectively.\nClearly the variables in a constraint transition may be re-named\nfreely because their scope is local to the transition.\nWe thus say that a constraint transition is a variant of another\nif one is identical to the other when a renaming subsitution is\nperformed. Further, we may simplify a constraint transition\nby renaming any one of its variables x by an expression y\nprovided that all groundings of the constraint tran-\nsition. For example, we may simply state the last constraint\ntransition in Figure 3 into\nby replacing the variable y 1 in the original transition with 0.\nThe above formulation of program transitions is familiar\nin the literature for the purpose of defining a set of transi-\ntions. What is new, however, is how we use a CTS to define\na symbolic transition sequences, and thereon, the notion of a\nproof.\nBy similarity with logic programming, we use the term\ngoal to deonote a literal that can be subjected to an unfolding\nprocess in order to infer a logical consequence.\nDEFINITION 3 (Goal). A query or goal of a CTS is of the\nwhere k is a program point, Y is a sequence of variables\nover system states, and Y is a constraint over some or all\nof the variables -\nx, and possibly some additional variables.\nThe variables -\nx are called the primary variables of this goal,\nwhile any additional variable in Y is called an auxiliary\nvariable of the goal.\nThus a goal is just like the conclusion of a constraint\ntransition. We say the goal is a start goal if k is the start\nprogram point. Similarly, a goal is a target goal is k is the\ntarget program point. Running a start goal is tantamount to\nasking the question: which values of -\nx which satisfy -\nwill lead to a goal at the target point(s)? The idea is that we\nsuccessively reduce one goal to another until the resulting\ngoal is at a target point, and then inspect the results.\nNext we define it means for a CTS to prove a goal.\nDEFINITION 4 (Proof Step, Sequence and Tree). Let there\nbe a CTS for p, and let\nx),Y be a goal for this. A\nproof step from G is obtained via a variant p(k, -\nof a transition in the CTS in which all the variables are fresh.\nThe result is a goal G # of the form\ny, Y 1\nproviding the constraints Y, -\ny, Y 1 are satisfiable.\nA proof sequence is a finite or infinite sequence of proof\nsteps. A proof tree is defined from proof sequences in the\nobvious way. A tree is complete if every internal node representing\na goal G is succeeded by nodes representing every\ngoal obtainable in a proof step from G .\n\nFigure\n\n5. Proof Tree of Even Counts Program\nConsider again the CTS in Figure 1, and we wish to prove\nThere is in fact only one proof sequence\nfrom the start goal\nor equivalently, even(0, i, 1,0). This proof sequence is shown\nin\n\nFigure\n\n5, and note that the counter,represented in the last\ngoal by the variable c 2 , has the value 2.\nHereafter we shall consider that a program and its CTS\nare synonymous. Given a program p, we say that\nx are the\nstart variables of p to denote that -\nx are the variables in the\nfirst constraint transition of p.\nDEFINITION 5 (Assertion). Let p be a program with start\nvariables -\nx, and let Y be a constraint. Let -\nx t denotes a sequence\nof variables representing system states not appearing\nin p or Y. (These represent the target values of the system\nAn assertion for p wrt to -\nx t is of the form\nIn particular, when k is the start program point, we may\nabberviate the assertion using the notation:\nIt is intuitively clear what it means for an assertion to\nhold. That is, execution from every instance q of p(k, -\ncannot lead to a target state where the property Y 1 ( -\nviolated.\nIn the example above, we could prove the assertion\nit is understood that the final\nvariable c t corresponds to the start variable c. Note that the\nlast occurrence of n in the assertion means that we are comparing\nc t with the initial and not final value of n (though in\nthis example, the two are in fact the same).\nWe now state the essential property of proof sequences:\nTHEOREM 1. Let a CTS for p have the start point k and target\nx and -\nx 1 each be sequences of variables\n\nFigure\n\n4. Proof Tree of 2-Process Bakery Algorithm (Partially Shown)\nover system states. The assertion {Y( -\nholds if for any goal of the form p(k t , -\nappearing\nin a proof sequence from the goal p(k, -\nx), the following\nholds:\nThe above theorem provides the basis of a search method,\nand what remains is to provide a means to ensure termination\nof the search. Toward this end, we next define the concepts\nof subsumption and coinduction and which allow the\n(successful) termination of proof sequences. However, these\nare generally insufficient. In the next section, we present our\nversion of abstraction whose purpose is to transform a proof\nsequence so that it is applicable to the termination criteria of\nsubsumption and coinduction.\n3.1 Subsumption\nConsider a finite and complete proof tree from some start\ngoal. A goal G in the tree is subsumed if there is a different\npath in the tree containing a goal G # such that [[G\nThe principle here is simply memoization: one may terminate\nthe expansion of a proof sequence while constructing\na proof tree when encountering a subsumed goal.\n3.2 Coinduction\nThe principle here is that, within one proof sequence, the\nproof obligation associated with the final goal may assume\nthat the proof obligation of an ancestor goal has already\nbeen met. This can be formally explained as a principle of\ncoinduction (see eg: Appendix B of [16]). Importantly, this\nsimple form of coinduction does not require a base case nor\na well-founded ordering.\nWe shall simply demonstrate this principle by example.\nSuppose we had the transition p(0,x) # p(0,x #\nand we wished to prove the assertion p(0,x) |= even(x t\n-x),\nthat is, the difference between x and its final value is even.\nConsider the derivation step:\nWe may use, in the latter goal, the fact that the earlier goal\nsatisfies the assertion. That is, we may reduce the obligaton\nof the latter goal to\nIt is now a simple matter of inferring whether this formula\nholds.\nIn general practice, the application of coinduction testing\nis largely equivalent to testing if one goal is simply an instance\nof another.\n3.3 Compostionality\nIt is intuitively clear that since our proof obligation relates\nthe start and final values of a program, or equivalently, it\nobeys the "assume-guarantee" paradigm [18], that the proof\nmethod is sequentially compositional. We thus omit a formal\ntreatment of CTS where programs directly invoke other\nprograms. Instead, in the next section, we provide a simple\nexample.\n4. Abstraction\nIn the literature on predicate abstraction, the abstract description\nis a specialized data structure (monomial?), and\nthe abstraction operation serves to propagate such a structure\nthough a small program fragment (a contiguous group\nof assignments, or a test), and then obtaining another struc-\nture. The strength of this method is in the simplicity of using\na finite set of predicates over the fixed number of program\nvariables as a basis for the abstract description.\nWe choose to follow this method. However, our abstract\ndescription shall not be a distinguished data structure. In\nour abstract description of a goal is itself a goal.\nDEFINITION 6 (Abstraction). An abstraction A is applied\nto a goal. It is specified by a program point pc(A), a sequence\nof variables var(A) corresponding to a subset of\nthe system variables, and finally, a finite set of constraints\npred(A) over var(A), called the "predicates" of A .\nLet A be an abstraction and G be a goal p(k, -\nx),Y where\nx denote the subsequence of -\nx corresponding\nto the system variables var(A). Let -\nx denote the remaining\nsubsequence of -\nx. Without losing generality, we assume\nthat -\nx 1 is an initial subsequence of -\nx, that is, -\nx.\nThen the abstraction A(G) of G by A is:\nZ is a sequence of fresh variables renaming -\nY 2 is the finite set of constraints\nFor example, let A be such that\nand That is, the first variable\nis to be abstracted into a negative or a nonnegative value.\nLet G be p(0, [x 1 , x 2 , x 3 ]), x 1. Then the abstraction\nA(G) is a goal of the form p(0, [Z,x 2 , x 3 ]), x\nwhich can be simplified into p(0, [Z,x 2 , x 3 ]), x\nNote that the orginal goal had ground instances\np(0, [1, 1,n]) for all n, while the abstracted goal has the instances\np(0, [m,1,n]) for all n and all nonnegative m. Note\nthat the second variable x 2 has not been abstracted even\nthough it is tightly constrained to the first variable x 1 . Note\nfurther that the value of x 3 is unchanged, that is, the abstraction\nwould allow any constraint on x 3 , had the example goal\ncontained such a constraint, to be propagated.\nLEMMA 1. Let A be an abstraction and G a goal.\nThe critical point is that the abstraction of a goal has the\nsame format as the goal itself. Thus an abstract goal has the\nexpressive power of a regular goal, while yet containing a\nnotion of abstraction that is sufficient to produce a finite-state\neffect. Once again, this is facilitated by the ability to\nreason about an unbounded number of variables.\nConsider the "Bubble" program and its CTS in Figures\n7 and 8, which is a simplified skeleton of the bubble sort\nalgorithm (without arrays). Consider the subprogram corresponding\nto start point 2 and whose target point is 6, that is,\nwe are considering the inner loop. Further suppose that the\nfollowing assertion had already been proven:\nbub(2, i, j, t, n) |=\nthat is, the subprogram increments t by n - preserving\nboth i and n, but not j. Consider now a proof sequence\nfor the goal bub(0, i, j, t, n),n # 0, where we want to\nprove that at program point #8#,\nn)/2. The proof\ntree is depicted in Figure 6. The proof shows a combination\nof the use of intermittent abstraction and compositional\nproof:\n. At point (A), we abstract the goal bub(2,\nusing the predicates i <\ni)/2. Call this abstraction A . Here the set\nof variables is hence both the variables\ncorrespond respectively to system variables\n#1# while (i < n-1) do\n#3# while (j < n-i-1) do\n\nFigure\n\n7. Program "Bubble"\nbub(0, i, j, t, n) # bub(1,\nbub(1, i, j, t, n) # bub(8, i, j, t, n), i # n-1.\nbub(1, i, j, t, n) # bub(2, i, j, t, n), i < n-1.\nbub(2, i, j, t, n) # bub(3,\nbub(3, i, j, t, n) # bub(6, i, j, t, n), j # n- i -1.\nbub(3, i, j, t, n) # bub(4, i, j, t, n), j < n- i -1.\nbub(4, i, j, t, n) # bub(5,\nbub(5, i, j, t, n) # bub(6, i, j, t, n), j # n- i -1.\nbub(5, i, j, t, n) # bub(4, i, j, t, n), j < n- i -1.\nbub(6, i, j, t, n) # bub(7,\nbub(7, i, j, t, n) # bub(8, i, j, t, n), i # n-1.\nbub(7, i, j, t, n) # bub(2, i, j, t, n), i < n-1.\n\nFigure\n\n8. CTS of "Bubble"\nand t are renamed to fresh variables i 2 , and t 2 . Mean-\nwhile, the variables j and n retain their original values.\n. After performing the above abstraction, we reuse the\nproof of the inner loop above. Here we immediately move\nto program point #6#, incrementing t with\nupdating j to an unknown value. However, i and n retain\ntheir original values at #2#.\n. As the result of the intermittent abstraction above, we\nobtain a coinductive proof at (B).\n5. The Whole Algorithm\nWe now summarize our proof method for an assertion\nSuppose the start program point of p is k and the start\nvariables of p are -\nx. Then consider the start goal p(k, -\nand incrementally build a search tree. For each path in the\ntree constructed so far leading to a goal G :\n. if G is either subsumed or is coinductive, then consider\nthis path closed, ie: not to be expanded further;\n. if G is a goal on which an abstraction A is defined,\nreplace G by A(G);\n. if G is a target goal, and if the constraints on the primary\nvariables -\nx 1 in G do not satisfy Yq, where q renames the\ntarget variables in Y into -\nCoinduction using (A)\nSatisfies\nSatisfies\nProof composition\nIntermittent abstraction\nbub(0, i, j, t, n),n # 0\n\nFigure\n\n6. Compositional Proof\nTHEOREM 2. If the above algorithm, applied to the assertion\nthen the asertion holds.\n6. CLP Technology\nIt is almost immediate that CTS is implementable in CLP.\nGiven a CTS for p, we build a CLP program in the following\nway: (a) for every transition of the form (k, -\nwe use the CLP rule the clause p(k, -\ning that Y is in the constraint domain of the CLP implementation\nat hand); (b) for every terminal program point k, we\nuse the CLP fact p(k, , . , , ), where the number of anonymous\nvariables is the same as the number of variables in -\nx.\nWe see later that the key implementation challenge for\na CLP system is the incremental satisfiability problem.\nRoughly stated, this is the problem of successively determining\nthat a monotonically increasing sequence of constraints\n(interpreted as a conjunction) is satisfiable.\n6.1 Exact Propagation is "CLP-Hard"\nHere we informally demonstrate that the incremental satisfiability\nproblem is reducible to the problem of analyzing\na straight line path in a program. We will consider here\nconstraints in the form of linear diophantine equations, i.e.,\nmultivariate polynomials over the integers. Without loss of\ngenerality, we assume each constraint is written in the form\nis an integer.\nSuppose we already have a sequence of constraints\ncorresponding path in the program\'s control\nflow.\nSuppose we add a new constraint Y\nThen, if one of these variables, say Y , is new, we add the\nassignment y := x - z where y is a new variable created to\ncorrespond to y. The remaining variables x and z are each\neither new, or are the corresponding variable to x and Z. If\nhowever all of x,Y and Z are not new, then add the statement\nif are the program\nvariables corresponding to x, y, z respectively. Hereafter we\npursue the then branch of this if statement.\nSimilarly, suppose the new constraint were of the form\ny correspond to Y , and y is possibly new. Again,\nif x is new, we simply add the assignment x := n # y where\nx is newly created to correspond to x. Otherwise, add the\nstatement if . to the path, and again, we\nnow pursue the then branch of this if statement.\nClearly an exact analysis of the path we have constructed\nleading to a successful traversal required, incrementally, the\nsolving of the constraint sequence Y 0 , - , Y n .\n6.2 Key Elements of CLP Systems\nA CLP system attempts to find answers to an initial goal G\nby searching for valid substitutions of its variables. Depth-first\nsearch is used. Each path in the search tree in fact\ninvolves the solving of an incremental satisfiability problem.\nAlong the way, unsatisfiability of the constraints at hand\nwould entail backtracking.\nThe key issue in CLP is the incremental satisfiability\nproblem, as mentioned above. A standard approach is as\nfollows. Given that the sequence of constraints Y 0 , . , Y i\nhas been determined to be satisfiable, represent this fact\nin a solved form. Essentially, this means that when a new\nconstraint Y i+1 is encountered, the solved form is efficiently\ncombinable with Y i+1 in order to determine the satisfiability\nof the new conjunction of constraints.\nThis method essentially requires a representation of the\nprojection of a set of constraints onto certain variables. Con-\nsider, for example, the set x\nAssuming that the new constraint would\nonly involve the variable x i (and this happens vastly of-\nten), we desire a representation of x projection\nproblem is well studied in CLP systems [13]. In the system\nCLP(R ) [14] for example, various adaptations of the\nFourier-Motzkin algorithm were implemented for projection\nin Herbrand and linear arithmetic constraints.\nWe finally mention another important optimization in\nCLP: tail recursion. This technique uses the same space in\nthe procedure call stack for recursive calls. Amongst other\nbebefits, this technique allows for a potentially unbounded\nnumber of recursive calls. Tail recursion is particurly relevant\nin our context because the recursive calls arising from\nthe CTS of programs are often tail-recursive.\nThe CLP(R ) system that we use to implement our prototype\nhas been engineered to handle constraints and auxiliary\nvariables efficiently using the above techniques.\n7. Experiments\nWe performed two kinds of experiments: the first set performs\nexact propagation. We then look at comparable abstract\nruns in the BLAST system, and (exact) runs in the\nsystem. These results are presented in Section\n7.1.\nIn the second set of experiments, presented in Section 7.2,\nwe compare intermittent predicate abstraction with normal\npredicate abstraction, again against the BLAST system.\nWe used a Pentium 4 2.8 GHz system with 512 MBRAM\nrunning GNU/Linux 2.4.22.\n7.1 Exact Runs\nWe start with an experiment which shows that concrete execution\ncan potentially be less costly than abstract execution,\nwe simply compare the timing of concrete execution using\nour CLP-based implementation and a predicate abstraction-based\nmodel checker. We also run a simple looping program,\nwhose C code is shown in Figure 9. We first have BLAST\ngenerate all the 100 predicates it requires. We then re-run\nBLAST by providing these predicates. BLAST took 22.06\nseconds to explore the state space. On the same machine, and\nwithout any abstraction, our verification engine took only\nseconds. For comparison, SPIN model checker [12] executes\nthe same program written in PROMELA in less than\nseconds.\nNow consider the synthetic program consisting of an initial\nassignment x := 0 followed by 1000 increments to x,\nwith the objective of proving that 1000 at the end. Consider\nalso another version where the program contains only\na single loop which increments is counter x 1000 times. We\ninput these two programs to our program verifier, without\nusing abstraction, and to ESC/Java 2 as well. The results are\nshown in Table 1. For both our verifier and ESC/Java 2 we\nrun both with x initialized to 0 and not initialized, hopefully\nforcing symbolic execution.\n\nTable\n\n1 shows that our verifier runs faster for the non-looping\nversion. However, there is a noticeable slowdown in\nint main()\n{ int i=0, j, x=0;\nwhile (i<7) {\nwhile (j<7) { x++; j++; }\n{ ERROR: }\n\nFigure\n\n9. Program with Loop\nTime (in Seconds)\nCLP with Tabling ESC/Java 2\nNon-Looping 2.45 2.47 9.89 9.68\nLooping 22.05 21.95 1.00 1.00\n\nTable\n\n1. Timing Comparison with ESC/Java 2\nthe looping version for our implementation. This is caused\nby the fact that in our implementation of coinductive tabling,\nsubsumption check is done based on similarity of program\npoint. Therefore, when a program point inside a loop is visited\nfor the i-th time, there are i - 1 subsumption checks to\nbe performed. This results in a total of about 500,000 subsumption\nchecks for the looping program. In comparison,\nthe non-looping version requires only 1,000 subsumption\nchecks. However, our implementation is currently at a prototype\nstage and our tabling mechanism is not implemented in\nthe most efficient way. For the looping version, ESC/Java 2\nemploys a weakest precondition propagation calculus; since\nthe program is very small, with a straightforward invariant\n(just the loop condition), the computation is very fast. Table\nalso shows that there is almost no difference between\nhaving x initialized to 0 or not.\n7.2 Experiments Using Abstraction\nNext we show an example that demonstrates that the intermittent\napproach requires fewer predicates. Let us consider\na second looping program written in C, shown in Figure 10.\nThe program\'s postcondition can be proven by providing an\ninvariant x=i # i<50 exactly before the first statement of\nthe loop body of the outer while loop. We specify as an abstraction\ndomain the following predicates x=i, i<50, and respectively\ntheir negations x#=i, i#50 for that program point\nto our verifier. Using this information, the proof process finishes\nin less than 0.01 seconds. If we do not provide an abstract\ndomain, the verification process finishes in 20.34 sec-\nonds. Here intermittent predicate abstraction requires fewer\npredicates: We also run the same program with BLAST and\nprovide the predicates x=i and i<50 (BLAST would auto-\nint main()\n{ int i=0, j, x=0;\nwhile (i<50) {\nwhile (j<10) { x++; j++; }\nwhile (x>i) { x-; }\n{ ERROR: }\n\nFigure\n\n10. Second Program with Loop\nwhile (true) do\n\nFigure\n\n11. Bakery Algorithm Peudocode for Process i\nmatically also consider their negations). BLAST finishes in\n1.33 seconds, and in addition, it also produces 23 other predicates\nthrough refinements. Running it again with all these\npredicates given, BLAST finishes in 0.28 seconds.\nFurther, we also tried our proof method on a version\nof bakery mutual exclusion algorithm. We need abstraction\nsince the bakery algorithm is an infinite-state program. The\npseudocode for process i is shown in Figure 11. Here we\nwould like to verify mutual exclusion, that is, no two processes\nare in the critical section (program point #2#) at the\nsame time. Our version of bakery algorithm is a concurrent\nprogram with asynchronous composition of processes. It can\nbe encoded as a sequential program with nondeterministic\nchoice.\nWe first encode the algorithm for 2, 3 and 4 processes\nin BLAST. Nondeterministic choice can be implemented in\nBLAST using the special variable BLAST NONDET which\nhas a nondeterministic value. We show the BLAST code for\n2-process bakery algorithm in Figure 12. Within the code,\nwe use program point annotations #pc# which should be considered\nas comments. Notice that the program points of the\nconcurrent version are encoded using the integer variables\npc1 and pc2.\nFurther, we translate the BLAST sequential versions of\nthe algorithm for 2, 3 and 4 processes into the CTS version\nshown in Figure 13 and also its corresponding CLP code, as\nan input to our prototype verifier.\nIn our experiments, we attempt to verify mutual exclusion\nproperty, that is, no two processes can be in the critical section\nat the same time. Here we perform 3 sets of runs, each\nconsisting of runs with 2, 3 and 4 processes. In all 3 sets,\nwe use a basic set of predicates: x i =0, x i #0, pc i =0, pc i =1,\nint main()\n{\n#0# int pc1=0, pc2=0;\nunsigned int x1=0, x2=0;\n#1# while (1) {\n#2# if (pc1==1 || pc2==1) {\n#3# /* Abstraction point 1 */; }\n#4# if (pc1==0 || pc2==0) {\n#5# /* Abstraction point 2 */;\nelse if (pc1==2 && pc2==2) {#6# ERROR: }\n#7# if ( BLAST NONDET) {\n#8# if (pc1==0) {\nelse if (pc1==1 &&\n{\nelse if (pc1==2) {\n} else {\n#12# if (pc2==0) {\nelse if (pc2==1 &&\n{\nelse if (pc2==2) {\n\nFigure\n\n12. Sequential 2-Process Bakery\nand N the number of processes,\nand also their negations.\n. Set 1: Use of predicate abstraction at every state with\nfull predicate set. Here using our prototype system we\nperform ordinary predicate abstraction where we abstract\nat every state encountered during search. Here, in addition\nto the basic predicates, we also require the predicates\nshown in Table 2 (and their negations) to avoid producing\nspurious counterexample.\n. Set 2: Intermittent predicate abstraction with full\npredicate set. In the second set we use intermittent abstraction\ntechnique on our prototype implementation. We\nabstract only when for some process i, pc i =1 holds. In\n\nFigure\n\n12, this abstraction point is marked with the comment\n"Abstraction point 1." The set of predicates that we\nuse here is the same as the predicates that we use in the\nfirst experiment above, otherwise spurious counterexample\nwill be generated.\n. Set 3: Intermittent predicate abstraction with reduced\npredicate set. For the third set we also use intermittent\nabstraction technique on our tabled CLP system.\nHere we only abstract whenever there are N-1 processes\nat program point 0, which in the 2-process sequential version\nis the condition where either pc1=0 or pc2=0. This is\nbak(3, pc1, pc2,x1,x2) # bak(4, pc1, pc2,x1,x2).\nbak(5, pc1, pc2,x1,x2) # bak(7, pc1, pc2,x1,x2).\n2.\nbak(6, pc1, pc2,x1,x2) # bak(7, pc1, pc2,x1,x2).\nbak(7, pc1, pc2,x1,x2) # bak(8, pc1, pc2,x1,x2).\nbak(7, pc1, pc2,x1,x2) # bak(12, pc1, pc2,x1,x2).\n2.\n2.\n2.\n2.\n\nFigure\n\n13. CTS of Sequential 2-Process Bakery\nBakery-2 x1<x2\nBakery-3 x1<x2, x1<x3, x2<x3\nBakery-4 x1<x2, x1<x3, x1<x4\nx2<x3, x2<x4, x3<x4\n\nTable\n\n2. Additional Predicates\nTime (in Seconds)\nCLP with Tabling BLAST\nBakery-3 0.83 0.14 0.09 2.38\nBakery-4 131.11 8.85 5.02 78.47\n\nTable\n\n3. Timing Comparison with BLAST\nmarked with the comment "Astraction point 2" in Figure\n12.\nFor each bakery algorithm with N processes, here we\nonly need the basic predicates and their negations without\nthe additional predicates shown in Table 2.\nWe have also compared our results with BLAST. We supplied\nthe same set of predicates that we used in the first and\nsecond sets to BLAST. Again, in BLAST we do not have to\nspecify their negations explicitly. Interestingly, for 4-process\nbakery algortihm BLAST requires even more predicates to\navoid refinement, which are x1=x3+1, x2=x3+1, x1=x2+1,\n1#x4, x1#x3, x2#x3 and x1#x2. We suspect this is due to\nthe fact that precision in predicate abstraction-based state-space\ntraversal depends on the power of the underlying theorem\nprover. We have BLAST generate these additional predicates\nit needs in a pre-run, and then run BLAST using them.\nHere since we do not run BLAST with refinement, lazy abstraction\ntechnique [11] has no effect, and BLAST uses all\nthe supplied predicates to represent any abstract state.\nFor these problems, using our intermittent abstraction\nwith CLP tabling is also markedly faster than both full predicate\nabstraction with CLP and BLAST. We show our timing\nresults in Table 3 (smallest recorded time of 3 runs each).\nThe first set and BLAST both run with abstraction at\nevery visited state. The timing difference between them and\nsecond and third sets shows that performing abstraction at\nevery visited state is expensive. The third set shows further\ngain over the second when we understand some intricacies\nof the system.\n\nAcknowledgement\n\nWe thank Ranjit Jhala for his help with BLAST.\n\n\n\n--R\n\nAutomatic predicate abstraction of C programs.\nPolymorphic predicate abstraction.\nThe Coq proof assistant reference manual-version v6\nJava applet correctness: A developer-oriented approach\nModular verification of software components in C.\n\nESC/Java2: Uniting ESC/Java and JML.\nExperience with predicate abstraction.\nConstruction of abstract state graphs of infinite systems with PVS.\nHOL light: A tutorial introduction.\nLazy ab- straction\nThe SPIN Model Checker: Primer and Reference Manual.\nProjecting CLP(R\nThe CLP(R\nThe KRAKATOA tool for certification of JAVA/JAVACARD programs annotated in JML.\nPrinciples of Program Analysis.\nPVS: A prototype verification system.\nA proof technique for rely/guarantee properties.\nModel checking programs.\n--TR\nConstraint logic programming\nMethods and logics for proving programs\nbased program analysis\nModern compiler implementation in ML\nSimplification by Cooperating Decision Procedures\nAbstract interpretation\nSystematic design of program analysis frameworks\nA flexible approach to interprocedural data flow analysis and programs with recursive data structures\nOn Proving Safety Properties by Integrating Static Analysis, Theorem Proving and Abstraction\nProgram Analysis Using Mixed Term and Set Constraints\nExperiments in Theorem Proving and Model Checking for Protocol Verification\nPowerful Techniques for the Automatic Generation of Invariants\nVerifying Invariants Using theorem Proving\nPVS',
    'program analysis',
    'RIS',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 384]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [3, 3]
```

<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

## Evaluation

### Metrics

#### Semantic Similarity

* Evaluated with [<code>EmbeddingSimilarityEvaluator</code>](https://sbert.net/docs/package_reference/sentence_transformer/evaluation.html#sentence_transformers.evaluation.EmbeddingSimilarityEvaluator)

| Metric              | Value      |
|:--------------------|:-----------|
| pearson_cosine      | 0.7235     |
| **spearman_cosine** | **0.7302** |

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset

* Size: 4,031 training samples
* Columns: <code>sentence_0</code>, <code>sentence_1</code>, and <code>label</code>
* Approximate statistics based on the first 1000 samples:
  |         | sentence_0                                                                           | sentence_1                                                                       | label                                                          |
  |:--------|:-------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|:---------------------------------------------------------------|
  | type    | string                                                                               | string                                                                           | float                                                          |
  | details | <ul><li>min: 256 tokens</li><li>mean: 256.0 tokens</li><li>max: 256 tokens</li></ul> | <ul><li>min: 3 tokens</li><li>mean: 4.89 tokens</li><li>max: 13 tokens</li></ul> | <ul><li>min: 0.0</li><li>mean: 0.53</li><li>max: 1.0</li></ul> |
* Samples:
  | sentence_0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | sentence_1                                       | label            |
  |:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------------------------------------------|:-----------------|
  | <code>--T<br>Practical Algorithms for Selection on Coarse-Grained Parallel Computers.<br>--A<br>AbstractIn this paper, we consider the problem of selection on coarse-grained distributed memory parallel computers. We discuss several deterministic and randomized algorithms for parallel selection. We also consider several algorithms for load balancing needed to keep a balanced distribution of data across processors during the execution of the selection algorithms. We have carried out detailed implementations of all the algorithms discussed on the CM-5 and report on the experimental results. The results clearly demonstrate the role of randomization in reducing communication overhead.<br>--B<br>better in practice than its deterministic counterpart due to the low constant associated with the<br>algorithm.<br>Parallel selection algorithms are useful in such practical applications as dynamic distribution<br>of multidimensional data sets, parallel graph partitioning and parallel construction of multidimensional<br>binary searc...</code>                                  | <code>parallel algorithms</code>                 | <code>1.0</code> |
  | <code>--T<br>The Constraint Language for Lambda Structures.<br>--A<br>This paper presents the Constraint Language for Lambda Structures<br>(CLLS), a first-order language for semantic underspecification that<br>conservatively extends dominance constraints. It is interpreted over<br>lambda structures, tree-like structures that encode<br>-terms. Based on<br>CLLS, we present an underspecified, uniform analysis of scope,<br>ellipsis, anaphora, and their interactions. CLLS solves a variable<br>capturing problem that is omnipresent in scope underspecification and<br>can be processed efficiently.<br>--B<br>Introduction<br>Underspecication is a recent approach to the issue of combinatorial<br>explosion caused by ambiguity. Its key idea is to derive a single, compact<br>description of all readings instead of the (exponential number<br>of) readings themselves. For as long as possible, later processing steps<br>operate on these descriptions; readings are only enumerated by need.<br>One type of ambiguity for which underspecication has been investigated<br>particu...</code> | <code>anaphora</code>                            | <code>1.0</code> |
  | <code>--T<br>Approximating Bayesian Belief Networks by Arc Removal.<br>--A<br>AbstractI propose a general framework for approximating Bayesian belief networks through model simplification by arc removal. Given an upper bound on the absolute error allowed on the prior and posterior probability distributions of the approximated network, a subset of arcs is removed, thereby speeding up probabilistic inference.<br>--B<br>Introduction<br>Today, more and more applications based on the Bayesian belief network 1 formalism are<br>emerging for reasoning and decision making in problem domains with inherent uncertainty.<br>Current applications range from medical diagnosis and prognosis [1], computer vision [10], to<br>information retrieval [2]. As applications grow larger, the belief networks involved increase<br>in size. And as the topology of the network becomes more dense, the run-time complexity of<br>probabilistic inference increases dramatically, reaching a state where real-time decision making<br>eventually becomes prohibitive; exa...</code>                         | <code>approximate probabilistic inference</code> | <code>1.0</code> |
* Loss: [<code>CosineSimilarityLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#cosinesimilarityloss) with these parameters:
  ```json
  {
      "loss_fct": "torch.nn.modules.loss.MSELoss"
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `eval_strategy`: steps
- `multi_dataset_batch_sampler`: round_robin

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `overwrite_output_dir`: False
- `do_predict`: False
- `eval_strategy`: steps
- `prediction_loss_only`: True
- `per_device_train_batch_size`: 8
- `per_device_eval_batch_size`: 8
- `per_gpu_train_batch_size`: None
- `per_gpu_eval_batch_size`: None
- `gradient_accumulation_steps`: 1
- `eval_accumulation_steps`: None
- `torch_empty_cache_steps`: None
- `learning_rate`: 5e-05
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `max_grad_norm`: 1
- `num_train_epochs`: 3
- `max_steps`: -1
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: {}
- `warmup_ratio`: 0.0
- `warmup_steps`: 0
- `log_level`: passive
- `log_level_replica`: warning
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `save_safetensors`: True
- `save_on_each_node`: False
- `save_only_model`: False
- `restore_callback_states_from_checkpoint`: False
- `no_cuda`: False
- `use_cpu`: False
- `use_mps_device`: False
- `seed`: 42
- `data_seed`: None
- `jit_mode_eval`: False
- `use_ipex`: False
- `bf16`: False
- `fp16`: False
- `fp16_opt_level`: O1
- `half_precision_backend`: auto
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `local_rank`: 0
- `ddp_backend`: None
- `tpu_num_cores`: None
- `tpu_metrics_debug`: False
- `debug`: []
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_prefetch_factor`: None
- `past_index`: -1
- `disable_tqdm`: False
- `remove_unused_columns`: True
- `label_names`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `fsdp`: []
- `fsdp_min_num_params`: 0
- `fsdp_config`: {'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False}
- `fsdp_transformer_layer_cls_to_wrap`: None
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `deepspeed`: None
- `label_smoothing_factor`: 0.0
- `optim`: adamw_torch
- `optim_args`: None
- `adafactor`: False
- `group_by_length`: False
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `skip_memory_metrics`: True
- `use_legacy_prediction_loop`: False
- `push_to_hub`: False
- `resume_from_checkpoint`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_private_repo`: None
- `hub_always_push`: False
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `include_inputs_for_metrics`: False
- `include_for_metrics`: []
- `eval_do_concat_batches`: True
- `fp16_backend`: auto
- `push_to_hub_model_id`: None
- `push_to_hub_organization`: None
- `mp_parameters`: 
- `auto_find_batch_size`: False
- `full_determinism`: False
- `torchdynamo`: None
- `ray_scope`: last
- `ddp_timeout`: 1800
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `dispatch_batches`: None
- `split_batches`: None
- `include_tokens_per_second`: False
- `include_num_input_tokens_seen`: False
- `neftune_noise_alpha`: None
- `optim_target_modules`: None
- `batch_eval_metrics`: False
- `eval_on_start`: False
- `use_liger_kernel`: False
- `eval_use_gather_object`: False
- `average_tokens_across_devices`: False
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: round_robin

</details>

### Training Logs
| Epoch  | Step | spearman_cosine |
|:------:|:----:|:---------------:|
| 0.1984 | 100  | 0.7302          |


### Framework Versions
- Python: 3.11.11
- Sentence Transformers: 3.4.1
- Transformers: 4.48.2
- PyTorch: 2.5.1+cu124
- Accelerate: 1.3.0
- Datasets: 3.2.0
- Tokenizers: 0.21.0

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->